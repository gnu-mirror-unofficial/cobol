void output_grammar (void);
void output_states (void);
void output_summary (void);
