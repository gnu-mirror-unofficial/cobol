extern void generate (void);
