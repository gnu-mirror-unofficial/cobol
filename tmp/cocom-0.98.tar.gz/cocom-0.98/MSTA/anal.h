extern void analyze_description (void);
