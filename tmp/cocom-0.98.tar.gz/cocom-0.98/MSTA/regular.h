int regular_arcs_are_equivalent (IR_node_t arc1, IR_node_t arc2);
void make_regular_optimization (void);
