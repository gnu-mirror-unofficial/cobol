void evaluate_minimal_derived_string_length (void);
void evaluate_nonterminals_relation_FIRST (void);
void set_FIRST_of_rule_tails (void);
context_t FIRST_of_tail (IR_node_t right_hand_side_element, context_t context,
                         int context_length);
