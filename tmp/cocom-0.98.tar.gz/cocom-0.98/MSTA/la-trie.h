void create_LR_set_look_ahead_trie (void);
void initiate_LR_set_look_ahead_tries (void);
void finish_LR_set_look_ahead_tries (void);
int get_max_look_ahead_string_length (void);
