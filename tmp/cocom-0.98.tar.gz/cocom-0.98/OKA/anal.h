/*
   FILE NAME:   anal.h

   TITLE:       Include file of semantic analyzer of OKA (pipeline hazards
                description translator)

   DESCRIPTION: This header file contains ANSI C prototype definition of
                only one external function.

*/

extern void analyze_description (void);
