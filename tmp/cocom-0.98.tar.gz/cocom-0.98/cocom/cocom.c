#include <stdio.h>

void main ()
{
  printf ("Cocom consits of ammunition, sprut, nona, oka, shilka, msta\n");
}
