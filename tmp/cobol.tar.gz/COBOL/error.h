#ifndef INCLUDED_ERROR_H
#define INCLUDED_ERROR_H

#define TRUE  1
#define FALSE 0

void lex_error();

#endif /* INCLUDED_ERROR_H */
