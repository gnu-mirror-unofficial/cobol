#include <stdio.h>
#include "record_description.h"

RecordDescription::RecordDescription() {
	fprintf(stderr, "rec desc constructor\n");
}
