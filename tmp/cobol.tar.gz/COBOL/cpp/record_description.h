/* test calling cpp from msta generated code */

class RecordDescription {
private:
	int level;
public:
	RecordDescription();
};
