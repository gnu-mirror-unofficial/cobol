#include <stdio.h>
#include "error.h"

extern int yydebug;
extern char* yytext;
extern FILE* yyin;

void lex_error() {
	if (yytext != NULL) {
		fprintf(stderr, "cobol: Lex error, unknown char %x = '%c'\n",
				yytext[0], yytext[0]);
	}
	else {
		fprintf(stderr, "cobol: generic lex error\n");
	}
}

int main() {

/*
	yydebug = 1;
*/
	yyparse();

	return 0;
}
