/*
 *  Implimentation of a symtable 
 *  Cobol to C translator.
 *
 *  Includes structure definatiosn and functions.
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifdef MALLOC_DEBUG
#include "dmalloc.h"
#endif

/*#define NDEBUG
 */

#include <assert.h>

#ifndef  HASHTABLE_DEFINITION
#define  HASHTABLE_DEFINITION
	#ifndef  INCLUDED_SYMTABLE_H
	#include "symtable.h"
	#endif 
#endif

static int SymHash( char * );
static int SymLookupWithHash(	char* in_string, 
				int in_HashValue,
				Entry** out_entry ); 
/* SymTableInit -
 * Initalize the global  symtable for hashing.
 *
 *  Accepts an array, for the gHashTable 
 *  Entry*  gHashTable[TABLESIZE];
 */

int SymTableInit( void ) {

	int i;
	
        for( i = 0; i < SYMTABLESIZE; i++ )
                gHashTable[i]=NULL;

	i = atexit(SymTableCleanUp);

	return i;

}

void SymTableCleanUp( void ) {     

	int i;
        Entry* temp;
 
        for ( i =0; i < SYMTABLESIZE; i++ ){
                if ( gHashTable[i] == NULL)
                        continue;
                temp = gHashTable[i];
                while( temp != NULL ) {
                        gHashTable[i] = temp -> next;
                        SymEntryDelete( temp);  /* free the Entry struct */
                        temp = gHashTable[i];
                }
        }

	return ;
}


int SymEntryNew(Entry** newentry) {

	/* Never Pass in a non-null pointer */
	assert( (*newentry) == NULL );
		
	*newentry = (Entry*) malloc ( sizeof(Entry) );
	if ( (*newentry) == NULL ) {
		fprintf(stderr,"Failed Malloc: SymEntryNew");
		return 9;
	}

	(*newentry)->name = NULL;
	(*newentry)->type = 'E';
 
	(*newentry)->length = 0;
        (*newentry)->fill = '!';
        (*newentry)->num = NULL;
        (*newentry)->str = NULL;
        (*newentry)->file = NULL;
        (*newentry)->next = NULL;

	return 0;
}

int SymEntryDelete(Entry* newentry) {

	/* Never Free a Null ptr */
	assert( newentry != NULL );
 
	/* Free any type specifc struct, if they exist */
	if ( newentry->str != NULL ) {
		SymStringDelete(newentry->str); 
	}
	if ( newentry->num != NULL ) {
		SymNumberDelete(newentry->num);
	}
	if ( newentry->file != NULL ) {
		SymFileDelete(newentry->file);
	}
	
	/* Free Variable name */
	if ( newentry->name != NULL ) {
		free(newentry->name); 
	}

	/* Free main struct */
	free(newentry);

	return 0;
}
				

int SymNumberNew(Number** newnumber) {

	/* Never Pass in a non-null pointer */
	assert( (*newnumber) == NULL );
		
	(*newnumber) = (Number*) malloc ( sizeof(Number) );
	if ( (*newnumber) == NULL ) {
		fprintf(stderr,"Failed Malloc: SymNumberNew");
		return 9;
	}

	(*newnumber)->init = 0;
	(*newnumber)->point = 0;

	return 0;
}

int SymNumberDelete(Number*newnumber) {

	/* Never Free a Null ptr */
	assert( newnumber != NULL );

	free(newnumber);

	return 0;
}

int SymStringNew(String** newstring ){

	/* Never Pass in a non-null pointer */
	assert( (*newstring) == NULL );
		
	(*newstring) = (String*) malloc ( sizeof(String) );
	if ( (*newstring) == NULL ) {
		fprintf(stderr,"Failed Malloc: SymStringNew");
		return 9;
	}

	(*newstring)->init= NULL;
	(*newstring)->align='N';

	return 0;
}

int SymStringDelete(String* newstring) {

	/* Never Free a Null ptr */
	assert( newstring != NULL ); 

	if ( newstring->init != NULL ) { /* Free the init string if exist */
		free(newstring->init);
	}

	free( newstring );

	return 0;
}
/*
 * Delete File struct 
 */
int SymFileNew(File** newfile ) {
	
	assert( (*newfile) == NULL );

	(*newfile) = (File*) malloc( sizeof(File) );
	if ( (*newfile) == NULL ) {
		fprintf(stderr, "Failed Malloc: SymFileNew.\n");
		return 9;
	}
	(*newfile)->hostfilename	= NULL;
	(*newfile)->progfilename 	= NULL;
	(*newfile)->organization	= SEQUENTIAL;
	(*newfile)->accessmode		= SEQUENTIAL;
	(*newfile)->primarykey		= NULL;

	return 0;
}
int SymFileDelete(File* newfile ) {

	assert (newfile != NULL );

	if ( newfile->hostfilename != NULL )
		free(newfile->hostfilename );
	if (newfile->progfilename != NULL )
		free(newfile->progfilename);
	if ( newfile->primarykey != NULL )
		free(newfile->primarykey );
	free(newfile);

	return 0;
}
/*

*/

/* Insert Entry Struct into Table 
 * SymInsert: Insert a symbol and an Entry struct value into the symbol table.
 *
 *              This is a helper function for use with the hash table.
 *              It checks to see if the symbol already exists, if so
 *              it sets the value of that entry to the value passed in.
 *              If an entry doesn't exist, it creates a new entry record.
 *              then attached the record at the correct hash value.
 *                   If multply entries for a given hash value then,
 *                   attach at the front of the linked list.
 *
 */
int SymInsert( Entry* newentry ){

        int hvalue,rc;
	Entry *tmpEntry = NULL;
	
	if ( newentry == NULL ) { /* Bad Entry struct return */
		return 9;
	} 

	/* hash string value */
        hvalue = SymHash( newentry->name );
 
	rc = SymLookupWithHash( newentry->name, hvalue, &tmpEntry );

	if ( rc != 0 ) { 		/* SymLookup failed, insert new node */ 
					/* Attach the entry to the table */
                newentry->next= gHashTable[hvalue];  
                gHashTable[hvalue] = newentry;
 
		return 0;
        }

	/* SymEntry existed or other error */

	return 1;
}

/* Lookup the char* string, and assign the entry
 * to the passed in ptr .
 */
int SymLookup(char * in_string, Entry** out_entry) {
 
        int hvalue, rc;

	assert( (*out_entry) == NULL );

        hvalue = SymHash( in_string );
 
        rc = SymLookupWithHash( in_string, hvalue, out_entry );
 
	/* If the entry_exists */
        if ( (rc == 0) && ((*out_entry) != NULL) )
                return 0;

	return 1;
}

/*
 * Lookup with a predetermined hashvalue 
 *
 */

static int SymLookupWithHash(	char * in_string,	
				int in_HashValue, 
				Entry** out_entry ) 
{
 
	Entry *e;
	int found_it = 1;
	/* get entry at hashvalue */
	e = gHashTable[in_HashValue];
 
        while( e != NULL ) {
                if ( strcmp( e->name, in_string ) == 0 ){
			(*out_entry) = e;
			found_it = 0;
                        break;
		}
                e = e->next;
        }
 

	return found_it;

	

}
/*
 *  SymHash: Returns a hash value for a symbol
 *
 *      This is an implimentation of a hash function used by
 *      P.J. Weinberger for the symbol table in his C compiler
 *
 *      The hash value is computed by starting with a hash value of zero.
 *      For each character, in a passed in str, shift the hash value
 *      4 bits to the left.  Add in the value of the character. 
 *      If any of the four high order bits  of the hash value are  1, 
 *      then take those 4 bits and shift them to the low order bits of a 
 *      new value, then xor them back onto the hash value.
 *      Then reset any of the four high order bits from 1 to 0. 
 *      Continue for all characters in the string.
 *      Then you have your hash value for the string.
 */
 
static int SymHash( char * s) {
 
        char *p;
        unsigned g, h =0;
        
        for( p = s; *p != '\0'; p = p + 1) {
                h = ( h << 4 ) + (*p);
                if ( (g = h&0xf0000000) ){
                        h = h ^ ( g >> 24 );
                        h = h ^ g;
                }
        }
 
        return h % SYMTABLESIZE;
}
