#!/bin/sh
PROG=cobol
DIR=`dirname $0`
PP=${DIR}/cobpp
PPARGS=
TRAN=${DIR}/cobol2c
PPStop=0
TStop=0
CC=gcc
CFLAGS="-Wall -I."
INFILENAME=
OUTFILENAME=cobout
ECHO=echo
DEBUG=no;
VERSION="0.50 alpha"
SDE=echo
SDE=


VERCALL () { $ECHO "Version: $1 "; exit 0 ;}
Usage () { $ECHO "Usage: $PROG {options} fn"; exit 1;}
Help () { $ECHO "Usage: $PROG {options} fn"; 
                $ECHO "Options	::";
                $ECHO "-E	:: Preprocess only and write to stdout";
                $ECHO "-g	:: Turn on Debugging of cobol pgm"; 
                $ECHO "-c	:: Translate & preprocess only";
                $ECHO "-o fn	:: Output filename named: fn";
                $ECHO "		:: Default filenames:       ";
                $ECHO "		:: generate code 	- cobout.c,cobout.h";
                $ECHO "		:: generate executable 	- cobout";
                $ECHO "-free	:: Source code in free format";
                $ECHO "-fixed	:: Source code in fixed column format";
                $ECHO "-t n	:: Expand tabs to n spaces.0 error on tabs";
                $ECHO "-h :: help";
                $ECHO "-v :: The Version number";
                $ECHO " ";
                exit 0;}
NoOp () { $ECHO "Error: Option $1 not implemented." ; exit 1 ;}

## attempt to parse out options.
while true
do
case "$1" in
-E ) PPStop=1 ; shift ;;
-c ) TStop=1; shift;;
-g ) PPARGS="$PPARGS -d" ; shift ;;
-h* ) Help ;;
-v* ) VERCALL "$VERSION" ;;
-o ) shift; OUTFILENAME=$1; shift ;;
-free* ) PPARGS="$PPARGS --free-format" ; shift ;;
-fixed* ) PPARGS="$PPARGS --fixed-format" ; shift ;;
-t ) shift; PPARGS="$PPARGS -t $1";shift ;;

-* ) $ECHO "Error: Invaild Option($1).";
     $ECHO "$PROG -h for proper usage.";exit 1 ;;
?* ) INFILENAME=$1; break ;;
* ) $ECHO "No input file."; Usage; exit 2 ;;
esac
done


#
# Check to see that fiel exists
#
if [ ! -r ${INFILENAME} ]; then
	$ECHO "File: $INFILENAME doesn't exist."
	exit 9;
fi

#
# Run preprocessor only
#  write to stdou by default otherwise given output file
#  with a .bii extention
#
if [ "x$PPStop" = "x1" ]; then
	if [ "x$OUTFILENAME" != "xcobout" ]; then
		${PP} ${PPARGS} ${INFILENAME} > ${OUTFILENAME}.bii
	else
		${PP} ${PPARGS} ${INFILENAME}
	fi
	
	exit 0;
fi



	
#
# Run cobol2c translator only
#
if [ "x$TStop" = "x1" ]; then
	BN=`basename $OUTFILENAME .cbl`
	${PP} ${PPARGS} ${INFILENAME} > ${OUTFILENAME}.bii
	${TRAN} ${OUTFILENAME}.bii
# Don't remove temp files
#	rm ${OUTFILENAME}.bii
	exit 0;
fi

# do complete build
# Preprocess, translate, and compile
#
####${PP} ${PPARGS} ${INFILENAME} | ${TRAN}

${PP} ${PPARGS} ${INFILENAME} > ${OUTFILENAME}.bii
${TRAN} ${OUTFILENAME}.bii
${CC} ${CFLAGS} ${OUTFILENAME}.c -o ${OUTFILENAME} -lm 

####
#### Don't remove temp files.
#rm ${OUTFILENAME}.bii
#rm ${OUTFILENAME}.c  ${OUTFILENAME}.h 


