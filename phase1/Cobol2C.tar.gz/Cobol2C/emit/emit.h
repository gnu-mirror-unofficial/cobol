#ifndef INCLUDED_EMIT_H
#define INCLUDED_EMIT_H
/*
 *
 *  Header file for all emit functions and related code
 *
 *  Chad Slaughter 
 *  11/15/97
 *
 *  declarations and function prototypes are here
 */

/*
 * emit Global struct
 */
#ifndef INCLUDED_SYMTABLE_H
typedef struct s_Entry Entry;
struct s_Entry;
#endif
#include <stdio.h>

struct s_emitEnv{

	FILE* header;
	FILE* source;

};

typedef struct s_emitEnv  emitEnv;

#ifdef EMIT_GLOBAL_DEF
emitEnv gEmitEnv;
#else
extern emitEnv gEmitEnv;
#endif



/* function prototypes */
/* init and cleanup  for emit functions*/
int EmitInit(char* string);
void emitCleanUp(void) ;

/* accept verb */
int emit_accept( char*  );
int emit_accept_dow( char* );
int emit_accept_time( char* );
int emit_accept_date( char* );
int emit_accept_day( char* );

/* display verb */
int emit_display_ident( char* );
int emit_display_literal( char* );
int emit_display_advance( int ); 

/* stop verb */
int emit_stop_run( void );

/* variable declarations */
int emit_variable( char * ); /* handle fqn, and simple n */
int emit_variable_filler( Entry * ); 

int emit_var_struct_begin( char * );
int emit_var_struct_end( char * );


/* if, else verb */
int emit_if_start( void );
int emit_if_block( void );
int emit_if_next_sentence( void );
int emit_if_end( void );

int emit_else_start( void );
int emit_else_next_sentence( void );
int emit_else_end( void );

/* conditional clause */

int emit_conditional(char * );

/* move verb */

int emit_move_literalToNumber(char *, char *); /* src, dest */
int emit_move_literalToString(char*, char *, int );/* src, dest,lengthdest */
int emit_move_NumberToString(char*, char *, int);/* src, dest,lengthdest */
int emit_move_StringToString(char*, char*,int );/* src, dest,lengthdest */
int emit_move_NumberToNumber(char*, char* );/* src, dest */


/* copy verb */
int emit_copy( char * );


/*
 * perform verb 
 */

int emit_perform_start( void );
int emit_perform_end( char * );	
/* Perform iterative loop (name: literal(1) or identifier(0) */
int emit_perform_times(char* , int);
int emit_perform_loop_before( void );
int emit_perform_loop_after( void );
int emit_perform_loop_end( void ); /* end loop condition emittion */

/*
 * Paragraphs
 */

int emit_paragraph_start( char * );
int emit_paragraph_end( void );
int emit_paragraph( char * );

/*
 * Compute 
 *	char* variableName, 
 *	char* arithmetic Expr, 
 *	int roundFlag(0=no,1=yes)
 */

int emit_compute(char*, char *, int);


#endif /* INCLUDED_EMIT_H */
