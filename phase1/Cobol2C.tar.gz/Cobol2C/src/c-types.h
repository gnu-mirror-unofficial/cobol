#ifndef INCLUDED_C_TYPES_H
#define INCLUDED_C_TYPES_H
/**
  VerifyEmitMove(): IN: dest
	Valid:	string to string ident
		numeric to string ident
		numeric to numeric ident
		string ident to string ident
		numeric ident to string ident
		numeric ident to numeric ident
	Note: "source" type is stored in the flag, TerminalType
	'S' String, 'N' Numeric
	Verify and call correct emit function for statement.
 */
void VerifyEmitMove(char *name) ;

#endif /* INCLUDED_C_TYPES_H */
