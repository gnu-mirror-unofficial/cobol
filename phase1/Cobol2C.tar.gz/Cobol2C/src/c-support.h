#ifndef INCLUDED_C_SUPPORT_H
#define INCLUDED_C_SUPPORT_H
/**
  CheckFlag(): IN: flag variable to be checked and modified, 
		flag we're checking and setting,
		name of clause ( for err reporting )
 */
void CheckFlag( int* flag_var, int flag_value, char *s ) ;

/**
  SetFlag(): IN: flag variable to set
 */
void SetFlag( int* flag_var, int flag_value ) ;

/**
  ClearFlag()
	Clear a single flag.
 */
void ClearFlag( int* flag_var, int flag_value ) ;

/**
  ResetFlag(): IN: flag variable to be reset
 */
void ResetFlag( int* flag_var ) ;

/**
  VerifyIdent()
        Lookup identifier in the table.
        Die if it's not there.
 */
void VerifyIdent(char *name) ;

/**
  VerifyFile(): IN: fname on disk
 */
void VerifyFile( char *fname ) ;

/**
  CheckIdentLen(): IN: string to be checked
	If string is greater than MAXIDENTLENGTH, error out.
 */
void CheckIdentLen(char *s) ;

/**
  VerifyIdentType(): IN: name, ident to lookup  type to verify
	Return: 0 on success, 1 if different
 */
int VerifyIdentType(char *name, char type) ;

/**
  VerifyInteger(): IN: number in string format
	Verify that Numeric is an integer 
 */
void VerifyInteger() ;

/**
  VerifyLevelNum(): GLOBAL: DDLevel
	Verify that number is a valid level number 
	Note: allowing 66,77,88 as valid levels 
 */
void VerifyLevelNum() ;

/**
  GetSymbolType(): IN: name of symbol to be looked up
	Return the type according to the returned Entry.
 */
char GetSymbolType(char *name) ;

/**
  DetermineType(): GLOBAL: PictureDefn
	Determine if the picture indicates a string or a number.
	Note: Considered String if picture has any strictly 
			non-numeric chars, like B or X.
	RETURNS: 'S' if string, 'N' if Number
 */
char DetermineType() ;

/**
  ExpandReps(): IN: Number of repitions to do
		GLOBAL: pc (picture count, current length of picture defn)
	Note: expand X(3) to XXX etc. in PictureDefn 
 */
void ExpandReps(int reps) ;

/**
  ParsePicture(): IN: String containing the unprocessed picture definition
	parse the picture defn, expanding if necessary
 */
void ParsePicture(char *pdef) ;

#endif
