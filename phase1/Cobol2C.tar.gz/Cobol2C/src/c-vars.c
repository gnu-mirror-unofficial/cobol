/*
 * Author: Laura Tweedy (tweedy@umr.edu)
 *
 * File: c-vars.c
 *
 * Purpose: These are the functions which are major grammar 
 *	actions and their support code.
 *
 * Notes:
 *
 * Date: Sun Nov 30 20:52:06 CST 1997
 */
/******************************************************/

/* stack and symtable .h's included from c-global.h */
#define VERB_GLOBALS
#define DDTEMP_S
#define FDTEMP_S
#include "c-global.h"
#include "c-vars.h"
#include "queue.h"
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>

#define TMPFILE "__cbl.tmp"

/*****GLOBALS*****/
Entry *e = NULL;		/* the working entry */
char  fqn[MAXFQNLENGTH];	/* fully qualified record name */
int   rv = 0;
int   CharCount = 0;
char  *ExprString;		/* the expression string */
Queue *expr_q = NULL;
FILE  *exprfile;


/************************SYMBOL TABLE*************************/
/**
  InsertNewEntry(): GLOBAL: e, the working Entry
	Does NOT reset e to NULL, because I need it after I insert it
		in some functions.
 */
void InsertNewEntry() {
	char fqn_s[MAXFQNLENGTH];
	char *tmp;

	rv = 0;
	strcpy(fqn_s, fqn);
	strcat(fqn_s, e->name);
	tmp = realloc(e->name, (strlen(fqn_s) + 1) * sizeof(char) );
	/* fuck you, chad */
	if (tmp != NULL)
		e->name = tmp;
	strcpy(e->name, fqn_s);

	rv = SymInsert(e);
	if (rv != 0)
		ErrRedefVar(e->name);
}

/****************************************/
/**
  MakeNewEntry()
	Prepare a new "Entry" type
 */
void MakeNewEntry(char *s) {
	#ifdef DEBUG
		assert(s != NULL);
	#endif
	rv = 0;

	rv = SymEntryNew(&e);
	if (rv != 0) 
		ErrInternal("Error allocating new symbol table entry");

	e->name = (char *) malloc( (strlen(s) + 1) * sizeof(char) );
	strcpy(e->name, s);
		/* dont count the decimal in the length of the picture */
	if (strchr(PictureDefn, '.') != NULL)
		e->length = strlen(PictureDefn) - 1;
	else
		e->length = strlen(PictureDefn);
}

/****************************************/
/**
  MakeNewString()
	Make a new "String" type for symbol table
 */
void MakeNewString() {
	String *s=NULL;
	
	rv = 0;
	rv = SymStringNew(&s);
	if (rv != 0) 
		ErrInternal("Error allocating symbol table entry");
	e->type = 'S';
	e->str = s;
	e->str->init = (char *) malloc((strlen(PictureDefn)+1) * sizeof(char));
	strcpy(e->str->init, "");
}
/****************************************/
/**
  MakeNewNumber()
	Make a new "Number" type for symbol table
 */
void MakeNewNumber() {
	char *p=NULL;
	Number *n=NULL;

	rv = 0;
	rv = SymNumberNew(&n);
	if (rv != 0)
		ErrInternal("Error allocating symbol table entry");
	e->type = 'N';
	p = strchr(PictureDefn, '.');
	if (p != NULL)
		n->point = strlen(p)-1;
	else
		n->point = 0;
		e->num = n;
}

/**************************RECORD/DATA STRUCTURES, MEMBERS**********/
/**
  FlushStack()
	Call emit code to close all remaining structures
 */
void FlushStack() {
	int i;
	char s[MAXIDENTLENGTH];

	while ( !StackIsEmpty() ) {
		FQNStackPop(s, i);
		emit_var_struct_end(s);
#ifdef MASSIVE_DEBUG
		fprintf(stderr, "Flush, CLOSE STRUCT %s \n",s);
#endif
	}
	strcpy(fqn, "");
}

/**
  FQNStackPush()
	stack push, maintaining fully qualified name
 */
void FQNStackPush(char *name, int level) {
	StackPush(name, level);
	strcat(fqn, name);
	strcat(fqn, ".");
}
/**
  FQNStackPop()
	Stack pop, maintaining fully qualified name
 */
void FQNStackPop(char *name, int level) {
	char *p;

	StackPop(name, &level);
	p = (char *) strrchr(fqn, '.');
	if (p != NULL)
		*p = '\0';
	p = (char *) strrchr(fqn, '.');
	if (p != NULL)
		*(p+1) = '\0';
	else
		strcpy(fqn, "");
}
/**
  StructHandler()
	Handle emit structure begins and ends and stack operations
	for group items.
 */
void StructHandler(char *name, int level) {
	int i;
	char s[MAXIDENTLENGTH];

	if (name == NULL)
		ErrInternal("Name of struct is null");

	if ( !StackIsEmpty() ) StackPeek(s, &i); else i = 0;
	if ( level > i ) {
		emit_var_struct_begin(name);
#ifdef MASSIVE_DEBUG
		fprintf(stderr, "BEGIN STRUCT %s\n", name);
#endif
		FQNStackPush(name, level);
	}
	if ( level <= i ) {
		FQNStackPop(s, i);
		emit_var_struct_end(s);
#ifdef MASSIVE_DEBUG
		printf("CLOSE STRUCT %s\n", s);
		printf("BEGIN STRUCT %s\n", name);
#endif
		emit_var_struct_begin(name);
		FQNStackPush(name, level);
	}
}

/**
  VariableHandler()
	Emit code for and handle stack operations with actual
	data members.
 */
void VariableHandler(char *name, int level) {
	int i;
	char s[MAXIDENTLENGTH];
	char fqn_s[MAXFQNLENGTH];
	char *tmp;

	if (name == NULL)
		ErrInternal("Name of variable is NULL");

	/* initialize the values in the e Entry */
	InitVariable();

		/* determine if we need to pop */
	rv = 0;
	if ( !StackIsEmpty() ) StackPeek(s, &i); else i = 0;
	if ( level <= i ) {
		FQNStackPop(s, i);
		emit_var_struct_end(s);
#ifdef MASSIVE_DEBUG
		printf("CLOSE STRUCT %s\n", s);
#endif
	}
		/* make fully qualified name to pass */
	if (fqn != NULL)
		strcpy(fqn_s, fqn);

		/* emit filler member */
	if ( strcmp(DDIdent, "") == 0 ) {
		if (e->name == NULL)
			ErrInternal("Entry name is NULL");
		tmp = realloc(e->name, strlen(fqn_s) + strlen(e->name) + 1);
		if (tmp != NULL) {
			strcat(fqn_s, "filler");
			strcpy(tmp, fqn_s);
			e->name = tmp;
		}
		rv = emit_variable_filler(e);
#ifdef MASSIVE_DEBUG
		if (e->type == 'S')
			fprintf(stderr, "FILLER VALUE >%s<\n", e->str->init);
		printf("FILLER PRINTING\n");
#endif
	}
	else {
		/* insert and emit regular member */
		InsertNewEntry();
		strcat(fqn_s, name);
		rv = emit_variable(fqn_s);
	}
	if (rv != 0)
		ErrEmit();
	e = NULL;
}

/**
  InitVariable(): GLOBAL: e
	Fills e with value obtained from "value" clause
 */
void InitVariable() {
	if ( data_descr_flags & DD_VALUE ) {
		if (e->type == 'S') {
			if (e->str->init == NULL)
				e->str->init = (char *) malloc(e->length);
			if ( data_descr_flags & DD_ZEROES )
				InitFill('0');
			else if ( data_descr_flags & DD_SPACES )
				InitFill(' ');
			else strcpy(e->str->init, DDValue_s);
		}
		if (e->type == 'N') {
			if ( data_descr_flags & DD_ZEROES )
				e->num->init = 0;
			else if ( data_descr_flags & DD_SPACES )
				ErrWrongType("Numeric", "String");
			else e->num->init = DDValue_n;
		}
	}
}

/**
  InitFill(): GLOBAL: e->str
	Fills string with an initial value.  Used with "value spaces"
	and "value zeroes".
 */
void InitFill(char c) {
	int i;

	for (i=0; i<=e->length - 1; i++)
		e->str->init[i] = c;
	e->str->init[e->length] = '\0';
}
/**
  ResetGlobal(): GLOBAL: DDIdent, DDLevel, DDValue_s, DDValue_n
	Reset to "" or 0.  Called after each data descr entry is
	processed
 */
void ResetGlobals() {
	strcpy(DDIdent, "");
	strcpy(DDValue_s, "");
	DDLevel = 0;
	DDValue_n = 0;
}
/**
  ResetFQN()
	Make fully qualified name the null string.
	Just to make sure it's really empty.
 */
void ResetFQN() {
	memset(fqn, 0, MAXFQNLENGTH);
}

/**
  RecordDescrActions()
	All actions which take place as a result of a record description
	line.
 */
void RecordDescrActions() {
	/* only invalid: flags set, but no picture clause */
	if ( (data_descr_flags & DD_PICTURE) == 0 
	   && (data_descr_flags != 0) ) 
			ErrUnfinishedRecord("Missing Picture");

	if (strcmp(DDIdent, "") == 0)
		MakeNewEntry("filler");
	else
		MakeNewEntry(DDIdent);

	e->type = DetermineType();

	if (e->type == 'S')
		MakeNewString();
	else
		MakeNewNumber();

	/* specific flags to set in structure */
	if ( data_descr_flags & DD_JUST )
		if (e->type == 'S') 
			e->str->align = 'R';
		else {} /* ?? valid ?? */

	if ( data_descr_flags & DD_PICTURE ) {
		VariableHandler(DDIdent, DDLevel); /* will handle filler */
		if (e != NULL)
			SymEntryDelete(e);
		e = NULL;
	}

	if ( data_descr_flags == 0 ) {
		StructHandler(DDIdent, DDLevel);
		SymEntryDelete(e);
		e = NULL;
	}
}

/***************/
/**
  MakeNewParagraph()
	Enter paragraph name into the symbol table
 */
void MakeNewParagraph(char *name) {
	MakeNewEntry(name);
	e->type = 'P';
	InsertNewEntry();
	e = NULL;
}
/**
  VerifyParagraph()
	Lookup name in symbol table and make sure it's a paragraph.
 */
void VerifyParagraph(char *name) {
	Entry *oldentry;

	rv = 0;
	if (rv != 0)
		ErrUndefVar(name);
	if (oldentry->type != 'P')
		ErrWrongType("Identifier", "Paragraph"); 
}

/**************************FD FUNCTIONS************************/
/**
  MakeNewFD(): IN: variable name for FD
		GLOBAL: e
 */
void MakeNewFD(char *name) {
	File  *f=NULL;

	#ifdef DEBUG
		assert(name != NULL);
	#endif
	rv = 0;
	rv = SymFileNew(&f);
	if (rv != 0) 
		ErrInternal("Error allocating new symbol table entry");

	f->progfilename = (char *) malloc( (strlen(name) +1) * sizeof(char) );
	strcpy(f->progfilename, name);
	e->type = 'F';
	e->file = f;

}
/**
  VerifyFD(): IN: variable name for FD
 */
void VerifyFD(char *name) {
	Entry *oldentry = NULL;

	#ifdef DEBUG
		assert(name != NULL);
	#endif
	rv = 0;
	rv = SymLookup(name, &oldentry);
	if (rv != 0) {
		ErrUndefFD(name); /* entry does NOT exist */
	}
}

/**
  FileControlActions(): 
	Actions to take upon matching a SELECT statement
 */
void FileControlActions() {
	MakeNewEntry(FDIdent);
	MakeNewFD(FDIdent);
	InsertNewEntry();
	e = NULL;

	strcpy(FDIdent, "");
}

/***********************INFO AND INITIALIZATION*************************/

/**
  PrintInfoHeader(): Gratuitously give credit to me and chad.
 */
void PrintInfoHeader() {
	fprintf(stderr, "\nCobol to C Translator -- v1.0\n");
	fprintf(stderr, "\n");
}

/**
  InitializeAll()
	Initialize stack, symbol table, and list.
 */
void InitializeAll(char *pgmname) {
	int rv = 0;

	rv = SymTableInit();
	if (rv != 0)
		ErrInternal("Could not initialize symbol table");

	StackInit();

	if (!gFileEnv.UseFileName)
		strcpy(gFileEnv.filename, pgmname);

	rv = EmitInit(gFileEnv.filename);
	if (rv != 0)
		ErrInternal("Could not initialize emit code");

	rv = QueueNew(&expr_q);
	if (rv != 0)
		ErrInternal("Could not initialize queue");
	ArgQCreate();

	ExprStringInit();

	fprintf(stderr, "Cobol Output File: %s.c %s.h\n\n", 
		gFileEnv.filename, gFileEnv.filename);
}

/**
  ArgQCreate()
	Create the queues for holding argument lists.
 */
void ArgQCreate() {

	rv = 0;
	rv = QueueNew(&arg1);
	if (rv != 0)
		ErrInternal("Error create queue");
	rv = QueueNew(&arg2);
	if (rv != 0)
		ErrInternal("Error creating queue");
	rv = QueueNew(&giving);
	if (rv != 0)
		ErrInternal("Error creating queue");
}

/*********************ADD VERB*************************/

/**
  VerbAddActions()
	Go thru the queues of identifiers and emit the correct C code.
 */
void VerbAddActions() {
	int len1, len2, lengive;

	len1 = QueueSize(arg1);
	len2 = QueueSize(arg2);
	lengive = QueueSize(giving);

	if (len1 < len2 && len1 != 1)
		ErrArgCount("ADD", "unmatched number of");

	if (len1 < len2) {}

}


/**
  Enqueue()
	Create a new queue entry and enqueue it in the correct queue.
 */
void Enqueue(Queue *q, char *name) {
	QueueEntry *qentry = NULL;

	assert(name != NULL);

	MakeQEntry(&qentry, name);

	rv = 0;
	rv = QueueEnqueue(q, qentry);
	if (rv != 0)
		ErrInternal("Could not enqueue");
}
	

/**
  MakeQEntry()
	Make a new QueueEntry container at the pointer passed in.
	Make queue entry-> name = name
 */
void MakeQEntry(QueueEntry **q, char *name) {
	assert(name != NULL);
	assert((*q) == NULL);

	rv = 0;
	rv = QueueEntryNew( q );
	if (rv != 0)
		ErrInternal("Error creating Queue entry");

	(*q)->name = (char *) malloc( (strlen(name) + 1) * sizeof(char));
	if ((*q)->name == NULL)
		ErrInternal("Error creating string");
	strcpy((*q)->name, name);

	if (verb_flags & VERB_ROUNDED)
		(*q)->rounded = 1;
	else
		(*q)->rounded = 0;
}

/**********************ARITHMETIC EXPR*******************/

/**
  ExprInit()
	remove the old temporary file and open a new one for writing.
 */
void ExprInit() {
	unlink(TMPFILE);
	exprfile = fopen(TMPFILE, "w");
}


/**
  ExprStringInit()
	register the ExprStringDelete with atexit
 */
void ExprStringInit() {
	assert(ExprString == NULL);

	rv = 0;
	rv = atexit(ExprStringDelete);
	if (rv != 0)
		ErrInternal("Error registering ExprStringDelete with atexit");
}

/**
  ExprStringDelete
	Free the global var ExprString
 */
void ExprStringDelete() {
	if (ExprString != NULL) {
		free(ExprString);
		ExprString = NULL;
	}
}

/**
  ExprStringAdd()
	Cat text to end of ExprString.
 */
void ExprStringAdd(char *add) {
	int newlen = 0;
	assert(add != NULL);

	if (ExprString != NULL) {
		newlen = strlen(ExprString) + strlen(add) + 1;
		ExprString = (char *) realloc(ExprString, newlen);
	}
	else {
		newlen = strlen(add) + 1;
		ExprString = (char *) malloc(newlen * sizeof(char));
		memset(ExprString, 0, newlen);
	}

	CharCount += newlen;
	strcat(ExprString, add);
}

/**
  ExprPow()
	Handle printing of extra notation needed for prefix operators.
	print the given string to the tmp expr file.
	Usually "pow(", ",", and ")", in that order. :)
 */
void ExprPow(char *s) {
	fprintf(exprfile, "%s", s);
	CharCount += strlen(s);
}

/**
  ExprPrint()
	Removes unmatched leading ('s, does not print single )
 */
void ExprPrint() {
        /*int len = 0;*/
	if (ExprString == NULL)
		return;

fprintf(exprfile, "%s", ExprString);
/*
	len = strlen(ExprString) - 1;
	CharCount += len;
	if (ExprString[0] == '(') {
		if ( ExprString[len] == ')')
			ExprString[len]='\0';
			fprintf(exprfile, "%s", ExprString+1);
		}
		else if (ExprString[0] != ')')
			fprintf(exprfile, "%s", ExprString);
	}
*/
	ExprStringDelete();         
}

/**
  ExprFlush()
	Flush part of a conditional upon seeing a conditional operator
 */
void ExprFlush(char *rel) {
	assert(rel != NULL);

	ExprPrint();
/*
fprintf(stderr, "RELATION: %s\n", rel);
*/
	fprintf(exprfile, "%s", rel);
	CharCount += strlen(rel);
}
/**
  GetFileLen
	stat tmp file to get length.
 */
long GetFileLen() {
	struct stat  filestruct;

	rv = stat(TMPFILE, &filestruct);
	if (rv != 0)
		ErrInternal("Could not stat file");

	return filestruct.st_size;
}
/**
  GetArithExpr
	put expr string in expr
	exprfile(GLOBAL)
 */
char *GetArithExpr( ) {
	long file_len = 0;
	char *expr = NULL;

	ExprPrint();
	fprintf(exprfile, "\n");
	fclose(exprfile);

	CharCount = 0;

	file_len = GetFileLen();
	expr = (char *) malloc((file_len+1) * sizeof(char));
	if (expr == NULL)
		ErrInternal("malloc failed");

	exprfile = fopen(TMPFILE, "r");
	if (exprfile == NULL)
		ErrInternal("Could not open tmp file");

	fgets(expr, file_len, exprfile);
	if (expr == NULL)
		ErrInternal("Error reading tmp file");
	fclose(exprfile);

	return expr;
}

/**
  ExprActions()
	Handle the Expression queue
 */
void ExprActions() {
	char *topass = NULL;
	char *expr = NULL;
	int  rv = 0;

	expr = GetArithExpr();
	assert(expr != NULL);
	topass = (char *) malloc((strlen(expr)+5) * sizeof(char));
			 /* is +5 for: opt! opt! ( ) \0 */
	if (topass == NULL)
		ErrInternal("malloc failed");
	strcpy(topass, "");

		/* for conv from 'until' to 'while' */
	if (verb_flags & CONDITION_NEGATE)
		strcpy(topass, "!");

	if (verb_flags & CONDITION_NOT)
		strcat(topass, "!(");
	else
		strcat(topass, "(");

	strcat(topass, expr);
	strcat(topass, ")");

	rv = emit_conditional(topass);
	if (rv != 0)
		ErrEmit();

/*
	fprintf(stderr, "%s\n", topass);
*/
#ifdef MASSIVE_DEBUG
	fprintf(stderr, "DONE WITH EXPR\n");
#endif
	free(expr);
}

/**********************COMPUTE**********************/

/**
  ComputeActions
	What to do upon completing a compute statement.
 */
void ComputeActions() {
	char *arith = NULL;
	QueueEntry *qentry = NULL;
	int  qlength = 0;
	int  i = 0;
	int  rnd_flag = 0;

	arith = GetArithExpr();
	qlength = QueueSize(arg1);

	for (i=0; i<qlength; i++) {
		qentry = QueueDequeue(arg1);
		if (qentry == NULL)
			ErrInternal("Error Dequeueing");

		if (qentry->rounded)
			rnd_flag = 1;
		emit_compute(qentry->name, arith, rnd_flag);
	}

	free(arith);
}
