/*
 * Author: Laura Tweedy (tweedy@umr.edu)
 *
 * File: c-expr.c
 *
 * Purpose: Arithmetic expressions
 *
 * Notes:
 *
 * Date: Sun Nov 30 20:52:06 CST 1997
 */
/******************************************************/

#include "c-global.h"
#include "c-expr.h"

/**** tree node ****/
/*
	value
	parent
	rchild
	lchild
*/
/**********************ARITHMETIC EXPR*******************/

/**
  ExprInit()
	Create a new expression tree.
 */
Tree *ExprInit() {
#if 0
	if ( TreeCreate() != 0 ) {
		ErrInternal("Could not create tree");
#endif
}

/**
  ExprInsertLeaf()
	Inserts a new leaf node at ptr Current.
	Does not modify Current.
 */
void ExprInsertLeaf( char *value ) {
#if 0
	TreeLeaf t = NULL;
	t = MakeTreeNode(value);
	if (t == NULL)
		ErrInternal("Could not create tree leaf");
	Current == t;
#endif
}

/**
  ExprReplaceRootAtCurrent()
	At position Current in the tree, replace the node with
	the passed in operator.  If optype is unary, previous
	tree at Current becomes single right child.  Otherwise,
	old tree at Current becomes left child.
	Current is set to right child of new operator node.
	optype = 'U' or 'B'
 */
void ExprReplaceRootAtCurrent( char *op, char optype ) {
#if 0
	TreeNode new = NULL;
	
	new = MakeTreeNode(op);
	if (new == NULL)
		ErrInternal("Could not create tree node");
	if (optype == 'B')
		new->lchild = Current;
	else
		new->rchild = Current;
	Current = new;

#endif
}

/**
  ExprInsertPlaceHolder()
	Insert an "empty" node at Current.
 */

/**
  ExprStringInit()
	register the ExprStringDelete with atexit
 */
void ExprStringInit() {
	assert(ExprString == NULL);

	rv = 0;
	rv = atexit(ExprStringDelete);
	if (rv != 0)
		ErrInternal("Error registering ExprStringDelete with atexit");
}

/**
  ExprStringDelete
	Free the global var ExprString
 */
void ExprStringDelete() {
	if (ExprString != NULL) {
		free(ExprString);
		ExprString = NULL;
	}
}

/**
  ExprStringAdd()
	Cat text to end of ExprString.
 */
void ExprStringAdd(char *add) {
	int newlen = 0;
	assert(add != NULL);

	if (ExprString != NULL) {
		newlen = strlen(ExprString) + strlen(add) + 1;
		ExprString = (char *) realloc(ExprString, newlen);
	}
	else {
		newlen = strlen(add) + 1;
		ExprString = (char *) malloc(newlen * sizeof(char));
		memset(ExprString, 0, newlen);
	}

	CharCount += newlen;
	strcat(ExprString, add);
}

/**
  ExprPow()
	Handle printing of extra notation needed for prefix operators.
	print the given string to the tmp expr file.
	Usually "pow(", ",", and ")", in that order. :)
 */
void ExprPow(char *s) {
	fprintf(exprfile, "%s", s);
	CharCount += strlen(s);
}
/**
  ExprPrint()
	Removes unmatched leading ('s, does not print single )
 */
void ExprPrint() {
	int len = 0;
	assert(exprfile != NULL);

	if (ExprString != NULL) {
fprintf(stderr, "%s\n", ExprString);
		len = strlen(ExprString) - 1;
		CharCount += len;
		if (ExprString[0] == '(') {
			if ( ExprString[len] == ')')
				ExprString[len]='\0';
			fprintf(exprfile, "%s", ExprString+1);
		}
		else if (ExprString[0] != ')')
			fprintf(exprfile, "%s", ExprString);
	}
	ExprStringDelete();
}

/**
  ExprFlush()
	Flush part of a conditional upon seeing a conditional operator
 */
void ExprFlush(char *rel) {
	assert(rel != NULL);

	ExprPrint();
fprintf(stderr, "RELATION: %s\n", rel);
	fprintf(exprfile, "%s", rel);
	CharCount += strlen(rel);
}
/**
  GetFileLen
	stat tmp file to get length.
 */
long GetFileLen() {
	struct stat  filestruct;

	rv = stat(TMPFILE, &filestruct);
	if (rv != 0)
		ErrInternal("Could not stat file");

	return filestruct.st_size;
}
/**
  GetArithExpr
	put expr string in expr
	exprfile(GLOBAL)
 */
char *GetArithExpr( ) {
	long file_len = 0;
	char *expr = NULL;

	ExprPrint();
	fprintf(exprfile, "\n");
	fclose(exprfile);

	CharCount = 0;

	file_len = GetFileLen();
	expr = (char *) malloc((file_len+1) * sizeof(char));
	if (expr == NULL)
		ErrInternal("malloc failed");

	exprfile = fopen(TMPFILE, "r");
	if (exprfile == NULL)
		ErrInternal("Could not open tmp file");

	fgets(expr, file_len, exprfile);
	if (expr == NULL)
		ErrInternal("Error reading tmp file");
	fclose(exprfile);

	return expr;
}

/**
  ExprActions()
	Handle the Expression queue
 */
void ExprActions() {
	char *topass = NULL;
	char *expr = NULL;
	int  rv = 0;

	expr = GetArithExpr();
	topass = (char *) malloc((strlen(expr)+5) * sizeof(char));
			 /* is +5 for: opt! opt! ( ) \0 */
	if (topass == NULL)
		ErrInternal("malloc failed");
	strcpy(topass, "");

		/* for conv from 'until' to 'while' */
	if (verb_flags & CONDITION_NEGATE)
		strcpy(topass, "!");

	if (verb_flags & CONDITION_NOT)
		strcat(topass, "!(");
	else
		strcat(topass, "(");

	strcat(topass, expr);
	strcat(topass, ")");

	rv = emit_conditional(topass);
	if (rv != 0)
		ErrEmit();

	fprintf(stderr, "%s\n", topass);
#ifdef MASSIVE_DEBUG
	fprintf(stderr, "DONE WITH EXPR\n");
#endif
	free(expr);
}

/**********************COMPUTE**********************/

/**
  ComputeActions
	What to do upon completing a compute statement.
 */
void ComputeActions() {
	char *arith = NULL;
	QueueEntry *qentry = NULL;
	int  qlength = 0;
	int  i = 0;

	arith = GetArithExpr();
	qlength = QueueSize(arg1);

	for (i=0; i<qlength; i++) {
		qentry = QueueDequeue(arg1);
		if (qentry == NULL)
			ErrInternal("Error Dequeueing");

		fprintf(stderr, "COMPUTE: %s = ", qentry->name);
		if (qentry->rounded)
			fprintf(stderr, "(int) ");
		fprintf(stderr, "%s\n", arith);
	}

	free(arith);
}
