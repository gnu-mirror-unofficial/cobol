#ifndef INCLUDED_C_VARS_H
#define INCLUDED_C_VARS_H
/**
  InsertNewEntry(): GLOBAL: e, the working Entry
	Does NOT reset e to NULL, because I need it after I insert it
		in some functions.
 */
void InsertNewEntry() ;

/**
  MakeNewEntry()
	Prepare a new "Entry" type
 */
void MakeNewEntry(char *s) ;

/**
  MakeNewString()
	Make a new "String" type for symbol table
 */
void MakeNewString() ;

/**
  MakeNewNumber()
	Make a new "Number" type for symbol table
 */
void MakeNewNumber() ;

/**
  FlushStack()
	Call emit code to close all remaining structures
 */
void FlushStack() ;

/**
  FQNStackPush()
	stack push, maintaining fully qualified name
 */
void FQNStackPush(char *name, int level) ;

/**
  FQNStackPop()
	Stack pop, maintaining fully qualified name
 */
void FQNStackPop(char *name, int level) ;

/**
  StructHandler()
	Handle emit structure begins and ends and stack operations
	for group items.
 */
void StructHandler(char *name, int level) ;

/**
  VariableHandler()
	Emit code for and handle stack operations with actual
	data members.
 */
void VariableHandler(char *name, int level) ;

/**
  InitVariable(): GLOBAL: e
	Fills e with value obtained from "value" clause
 */
void InitVariable() ;

/**
  InitFill(): GLOBAL: e->str
	Fills string with an initial value.  Used with "value spaces"
	and "value zeroes".
 */
void InitFill(char c) ;

/**
  ResetGlobal(): GLOBAL: DDIdent, DDLevel, DDValue_s, DDValue_n
	Reset to "" or 0.  Called after each data descr entry is
	processed
 */
void ResetGlobals() ;

/**
  ResetFQN()
	Make fully qualified name the null string.
	Just to make sure it's really empty.
 */
void ResetFQN() ;

/**
  RecordDescrActions()
	All actions which take place as a result of a record description
	line.
 */
void RecordDescrActions() ;

/**
  MakeNewParagraph()
	Enter paragraph name into the symbol table
 */
void MakeNewParagraph(char *name) ;

/**
  VerifyParagraph()
	Lookup name in symbol table and make sure it's a paragraph.
 */
void VerifyParagraph(char *name) ;

/**
  MakeNewFD(): IN: variable name for FD
		GLOBAL: e
 */
void MakeNewFD(char *name) ;

/**
  VerifyFD(): IN: variable name for FD
 */
void VerifyFD(char *name) ;

/**
  FileControlActions(): 
	Actions to take upon matching a SELECT statement
 */
void FileControlActions() ;

/**
  PrintInfoHeader(): Gratuitously give credit to me and chad.
 */
void PrintInfoHeader() ;

/**
  InitializeAll()
	Initialize stack, symbol table, and list.
 */
void InitializeAll(char *pgmname) ;

/**
  ArgQCreate()
	Create the queues for holding argument lists.
 */
void ArgQCreate() ;

/**
  VerbAddActions()
	Go thru the queues of identifiers and emit the correct C code.
 */
void VerbAddActions() ;

/**
  Enqueue()
	Create a new queue entry and enqueue it in the correct queue.
 */
void Enqueue(Queue *q, char *name) ;

/**
  MakeQEntry()
	Make a new QueueEntry container at the pointer passed in.
	Make queue entry-> name = name
 */
void MakeQEntry(QueueEntry **q, char *name) ;

/**
  ExprInit()
	remove the old temporary file and open a new one for writing.
 */
void ExprInit() ;

/**
  ExprStringInit()
	register the ExprStringDelete with atexit
 */
void ExprStringInit() ;

/**
  ExprStringDelete
	Free the global var ExprString
 */
void ExprStringDelete() ;

/**
  ExprStringAdd()
	Cat text to end of ExprString.
 */
void ExprStringAdd(char *add) ;

/**
  ExprPow()
	Handle printing of extra notation needed for prefix operators.
	print the given string to the tmp expr file.
	Usually "pow(", ",", and ")", in that order. :)
 */
void ExprPow(char *s) ;

/**
  ExprPrint()
	Removes unmatched leading ('s, does not print single )
 */
void ExprPrint() ;

/**
  ExprFlush()
	Flush part of a conditional upon seeing a conditional operator
 */
void ExprFlush(char *rel) ;

/**
  GetFileLen
	stat tmp file to get length.
 */
long GetFileLen() ;

/**
  GetArithExpr
	put expr string in expr
	exprfile(GLOBAL)
 */
char *GetArithExpr( ) ;

/**
  ExprActions()
	Handle the Expression queue
 */
void ExprActions() ;

/**
  ComputeActions
	What to do upon completing a compute statement.
 */
void ComputeActions() ;

#endif
