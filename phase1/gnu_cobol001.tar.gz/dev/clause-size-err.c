/*
 * A n t l r  T r a n s l a t i o n  H e a d e r
 *
 * Terence Parr, Will Cohen, and Hank Dietz: 1989-1994
 * Purdue University Electrical Engineering
 * With AHPCRC, University of Minnesota
 * ANTLR Version 1.33MR9
 */
#include <stdio.h>
#define ANTLR_VERSION	133MR9

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "charbuf.h"
#include "c-global.h"
#define ZZCAN_GUESS
#include <setjmp.h>
#define LL_K 4
#define zzSET_SIZE 48
#include "antlr.h"
#include "tokens.h"
#include "dlgdef.h"
#include "mode.h"
#ifndef PURIFY
#define PURIFY(r,s)
#endif

void
#ifdef __USE_PROTOS
size_err(void)
#else
size_err()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==NOT) ) {
			zzmatch(NOT); zzCONSUME;
		}
		zzEXIT(zztasp2);
		}
	}
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==ON) ) {
			zzmatch(ON); zzCONSUME;
		}
		zzEXIT(zztasp2);
		}
	}
	zzmatch(SIZE); zzCONSUME;
	zzmatch(ERROR); zzCONSUME;
	imperative();
	second_size_line();
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd19, 0x20);
	}
}

void
#ifdef __USE_PROTOS
second_size_line(void)
#else
second_size_line()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	zzGUESS_BLOCK
	zzGUESS
	if ( !zzrv && (setwd19[LA(1)]&0x40) ) {
		{
			zzBLOCK(zztasp2);
			zzMake0;
			{
			{
				zzBLOCK(zztasp3);
				zzMake0;
				{
				if ( (LA(1)==NOT) ) {
					zzmatch(NOT); zzCONSUME;
				}
				zzEXIT(zztasp3);
				}
			}
			{
				zzBLOCK(zztasp3);
				zzMake0;
				{
				if ( (LA(1)==ON)
 ) {
					zzmatch(ON); zzCONSUME;
				}
				zzEXIT(zztasp3);
				}
			}
			zzmatch(SIZE); zzCONSUME;
			zzmatch(ERROR); zzCONSUME;
			imperative();
			zzEXIT(zztasp2);
			}
		}
		zzGUESS_DONE
		{
			zzBLOCK(zztasp2);
			zzMake0;
			{
			{
				zzBLOCK(zztasp3);
				zzMake0;
				{
				if ( (LA(1)==NOT) ) {
					zzmatch(NOT); zzCONSUME;
				}
				zzEXIT(zztasp3);
				}
			}
			{
				zzBLOCK(zztasp3);
				zzMake0;
				{
				if ( (LA(1)==ON) ) {
					zzmatch(ON); zzCONSUME;
				}
				zzEXIT(zztasp3);
				}
			}
			zzmatch(SIZE); zzCONSUME;
			zzmatch(ERROR); zzCONSUME;
			imperative();
			zzEXIT(zztasp2);
			}
		}
	}
	else {
		if ( zzguessing ) zzGUESS_DONE;
		if ( (setwd19[LA(1)]&0x80) ) {
		}
		else {zzFAIL(1,zzerr44,&zzMissSet,&zzMissText,&zzBadTok,&zzBadText,&zzErrk); goto fail;}
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd20, 0x1);
	}
}
