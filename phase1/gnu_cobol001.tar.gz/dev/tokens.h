#ifndef tokens_h
#define tokens_h
/* tokens.h -- List of labelled tokens and stuff
 *
 * Generated from: src/cob-main.g src/cob-nonterminals.g src/cob-stmts.g src/div-id.g src/div-env.g src/sec-io.g src/div-data.g src/div-proc.g src/clause-file-control.g src/clause-file-descr.g src/clause-record-descr.g src/clause-condition.g src/clause-size-err.g src/clause-arithmetic.g src/clause-relation.g src/clause-keys.g src/clause-end.g src/verb-accept.g src/verb-add.g src/verb-compute.g src/verb-copy.g src/verb-display.g src/verb-divide.g src/verb-go.g src/verb-if.g src/verb-initialize.g src/verb-move.g src/verb-mult.g src/verb-subtract.g src/verb-stop.g src/verb-perform.g
 *
 * Terence Parr, Will Cohen, and Hank Dietz: 1989-1994
 * Purdue University Electrical Engineering
 * ANTLR Version 1.33MR9
 */
#define zzEOF_TOKEN 1
#define ACCEPT 4
#define ACCESS 5
#define ADD_C 6
#define ADVANCING 7
#define AFTER 8
#define ALL 9
#define ALPHABETIC_LOWER 10
#define ALPHABETIC_UPPER 11
#define ALPHABETIC 12
#define ALPHABET 13
#define ALPHANUMERIC_EDITED 14
#define ALPHANUMERIC 15
#define ALSO 16
#define ALTERNATE 17
#define ALTER 18
#define AND 19
#define ANY 20
#define AREAS 21
#define AREA 22
#define ARE 23
#define ASCENDING 24
#define ASSIGN 25
#define AT 26
#define AUTHOR 27
#define BEFORE 28
#define BINARY 29
#define BLANK 30
#define BLOCK 31
#define BOTTOM 32
#define BY 33
#define CALL 34
#define CANCEL 35
#define CD 36
#define CF 37
#define CHARACTERS 38
#define CHARACTER 39
#define CH 40
#define CLASS 41
#define CLOCK_UNITS 42
#define CLOSE 43
#define COBOL 44
#define CODE_SET 45
#define CODE 46
#define COLLATING 47
#define COLUMN 48
#define COMMA 49
#define COMMON 50
#define COMMUNICATION 51
#define COMPUTATIONAL 52
#define COMPUTE 53
#define COMP 54
#define CONFIGURATION 55
#define CONTAINS 56
#define CONTENT 57
#define CONTINUE 58
#define CONTROLS 59
#define CONTROL 60
#define CONVERTING 61
#define COPY 62
#define CORR 63
#define COUNT 64
#define CURRENCY 65
#define DATA 66
#define DATE_COMPILED 67
#define DATE_WRITTEN 68
#define DATE 69
#define DAY_OF_WEEK 70
#define DAY 71
#define DEBUG_CONTENTS 72
#define DEBUG_ITEM 73
#define DEBUG_LINE 74
#define DEBUG_NAME 75
#define DEBUG_SUB_1 76
#define DEBUG_SUB_2 77
#define DEBUG_SUB_3 78
#define DEBUGGING 79
#define DECIMAL_POINT 80
#define DECLARITIVES 81
#define DELETE 82
#define DELIMITED 83
#define DELIMITER 84
#define DEPENDING 85
#define DESCENDING 86
#define DESTINATION 87
#define DETAIL 88
#define DE 89
#define DISABLE 90
#define DISPLAY 91
#define DIVIDE 92
#define DIVISION 93
#define DOWN 94
#define DUPLICATES 95
#define DYNAMIC 96
#define EGI 97
#define ELSE_C 98
#define EMI 99
#define ENABLE 100
#define END_ADD 101
#define END_CALL 102
#define END_COMPUTE 103
#define END_DELETE 104
#define END_DIVIDE 105
#define END_EVALUATE 106
#define END_IF 107
#define END_MULTIPLY 108
#define END_OF_PAGE 109
#define END_PERFORM 110
#define END_READ 111
#define END_RECEIVE 112
#define END_RETURN 113
#define END_REWRITE 114
#define END_SEARCH 115
#define END_START 116
#define END_STRING 117
#define END_SUBTRACT 118
#define END_UNSTRING 119
#define END_WRITE 120
#define END 121
#define ENTER 122
#define ENVIRONMENT 123
#define EOP 124
#define EQUAL 125
#define ERROR 126
#define ESI 127
#define EVALUATE 128
#define EVERY 129
#define EXCEPTION 130
#define EXIT 131
#define EXTEND 132
#define EXTERNAL 133
#define FALSE_C 134
#define FD 135
#define FILE_C 136
#define FILE_CONTROL 137
#define FILLER 138
#define FINAL 139
#define FIRST 140
#define FOOTING 141
#define FOR_C 142
#define FROM 143
#define GENERATE 144
#define GIVING 145
#define GLOBAL 146
#define GO 147
#define GREATER 148
#define GROUP 149
#define HEADING 150
#define HIGH_VALUES 151
#define HIGH_VALUE 152
#define I_O_CONTROL 153
#define I_O 154
#define IDENTIFICATION 155
#define IF_C 156
#define INDEXED 157
#define INDEX 158
#define INDICATE 159
#define INITIALIZE 160
#define INITIAL_C 161
#define INITIATE 162
#define INPUT_OUTPUT 163
#define INPUT 164
#define INSPECT 165
#define INSTALLATION 166
#define INTO 167
#define INVALID 168
#define IN 169
#define IS 170
#define JUSTIFIED 171
#define JUST 172
#define KEY 173
#define LABEL 174
#define LAST 175
#define LEADING 176
#define LEFT 177
#define LENGTH 178
#define LESS 179
#define LIMIT 180
#define LIMITS 181
#define LINAGE_COUNTER 182
#define LINAGE 183
#define LINE_COUNTER 184
#define LINES 185
#define LINE 186
#define LINKAGE 187
#define LOCK 188
#define LOW_VALUES 189
#define LOW_VALUE 190
#define MEMORY 191
#define MERGE 192
#define MESSAGE 193
#define MODE 194
#define MODULES 195
#define MOVE 196
#define MULTIPLE 197
#define MULTIPLY 198
#define NATIVE 199
#define NEGATIVE 200
#define NEXT 201
#define NOT 202
#define NO 203
#define NUMBER 204
#define NUMERIC_EDITED 205
#define NUMERIC_KW 206
#define OBJECT_COMPUTER 207
#define OCCURS 208
#define OFF 209
#define OF 210
#define OMITTED 211
#define ON 212
#define OPEN 213
#define OPTIONAL 214
#define ORDER 215
#define ORGANIZATION 216
#define OR 217
#define OTHER 218
#define OUTPUT 219
#define OVERFLOW 220
#define PACKED_DECIMAL 221
#define PADDING 222
#define PAGE_COUNTER 223
#define PAGE 224
#define PERFORM 225
#define PF 226
#define PH 227
#define PICTURE 228
#define PLUS 229
#define POINTER 230
#define POSITION 231
#define POSITIVE 232
#define PRINTING 233
#define PROCEDURES 234
#define PROCEDURE 235
#define PROCEED 236
#define PROGRAM_ID 237
#define PROGRAM 238
#define PURGE 239
#define QUEUE 240
#define QUOTES 241
#define QUOTE 242
#define RANDOM 243
#define RD 244
#define READ 245
#define RECEIVE 246
#define RECORDS 247
#define RECORD 248
#define REDEFINES 249
#define REEL 250
#define REFERENCES 251
#define REFERENCE 252
#define RELATIVE 253
#define RELEASE 254
#define REMAINDER 255
#define REMOVAL 256
#define RENAMES 257
#define REPLACE 258
#define REPLACING 259
#define REPORTING 260
#define REPORTS 261
#define REPORT 262
#define RERUN 263
#define RESERVE 264
#define RESET 265
#define RETURN 266
#define REVERSED 267
#define REWIND 268
#define REWRITE 269
#define RF 270
#define RH 271
#define RIGHT 272
#define ROUNDED 273
#define RUN 274
#define SAME 275
#define SD 276
#define SEARCH 277
#define SECTION 278
#define SECURITY 279
#define SEGMENT_LIMIT 280
#define SEGMENT 281
#define SELECT 282
#define SEND 283
#define SENTENCE 284
#define SEPARATE 285
#define SEQUENCE 286
#define SEQUENTIAL 287
#define SET 288
#define SIGN 289
#define SIZE 290
#define SORT_MERGE 291
#define SORT 292
#define SOURCE_COMPUTER 293
#define SOURCE 294
#define SPACES 295
#define SPACE 296
#define SPECIAL_NAMES 297
#define STANDARD_1 298
#define STANDARD_2 299
#define STANDARD 300
#define START_C 301
#define STATUS 302
#define STOP 303
#define STRING 304
#define SUB_QUEUE_1 305
#define SUB_QUEUE_2 306
#define SUB_QUEUE_3 307
#define SUBTRACT 308
#define SUM 309
#define SUPPRESS 310
#define SYMBOLIC 311
#define SYNCHRONIZED 312
#define SYNC 313
#define TABLE 314
#define TALLYING 315
#define TAPE 316
#define TERMINAL 317
#define TERMINATE 318
#define TEST 319
#define TEXT 320
#define THAN 321
#define THEN 322
#define THROUGH 323
#define THRU 324
#define TIMES 325
#define TIME 326
#define TOP 327
#define TO 328
#define TRAILING 329
#define TRUE_C 330
#define TYPE 331
#define UNIT 332
#define UNSTRING 333
#define UNTIL 334
#define UPON 335
#define UP 336
#define USAGE 337
#define USE 338
#define USING 339
#define VALUES 340
#define VALUE 341
#define VARYING 342
#define WHEN 343
#define WITH 344
#define WORDS 345
#define WORKING_STORAGE 346
#define WRITE 347
#define ZEROES 348
#define ZEROS 349
#define ZERO 350
#define EOF 351
#define OPAREN 352
#define CPAREN 353
#define EXPONENT 354
#define PLUS_OP 355
#define MINUS_OP 356
#define DIV_OP 357
#define MULT_OP 358
#define EQUALSIGN 359
#define GREATERSIGN 360
#define LESSSIGN 361
#define GESIGN 362
#define LESIGN 363
#define PIC_TYPE 364
#define PIC_OPAREN 365
#define PIC_REPS 366
#define PIC_CPAREN 367
#define PICTURE_DEFN 368
#define NUMERIC 369
#define PROG_NAME 370
#define NONNUMERIC 371
#define PERIOD 372
#define ASCII 373
#define EBCIDIC 374
#define SEPERATE 375
#define CHAR_STRING 376

#ifdef __USE_PROTOS
void main_structure(void);
#else
extern void main_structure();
#endif

#ifdef __USE_PROTOS
void pic_defn(void);
#else
extern void pic_defn();
#endif

#ifdef __USE_PROTOS
void ident(void);
#else
extern void ident();
#endif

#ifdef __USE_PROTOS
void string_literal(void);
#else
extern void string_literal();
#endif

#ifdef __USE_PROTOS
void numeric(void);
#else
extern void numeric();
#endif

#ifdef __USE_PROTOS
void index_name(void);
#else
extern void index_name();
#endif

#ifdef __USE_PROTOS
void level_number(void);
#else
extern void level_number();
#endif

#ifdef __USE_PROTOS
void implementor_name(void);
#else
extern void implementor_name();
#endif

#ifdef __USE_PROTOS
void lit_char(void);
#else
extern void lit_char();
#endif

#ifdef __USE_PROTOS
void sym_char(void);
#else
extern void sym_char();
#endif

#ifdef __USE_PROTOS
void file_name(void);
#else
extern void file_name();
#endif

#ifdef __USE_PROTOS
void integer(void);
#else
extern void integer();
#endif

#ifdef __USE_PROTOS
void cd_name(void);
#else
extern void cd_name();
#endif

#ifdef __USE_PROTOS
void statement(void);
#else
extern void statement();
#endif

#ifdef __USE_PROTOS
void imperative(void);
#else
extern void imperative();
#endif

#ifdef __USE_PROTOS
void conditional(void);
#else
extern void conditional();
#endif

#ifdef __USE_PROTOS
void identification_division(void);
#else
extern void identification_division();
#endif

#ifdef __USE_PROTOS
void environment_division(void);
#else
extern void environment_division();
#endif

#ifdef __USE_PROTOS
void config_section(void);
#else
extern void config_section();
#endif

#ifdef __USE_PROTOS
void src_computer_clause(void);
#else
extern void src_computer_clause();
#endif

#ifdef __USE_PROTOS
void debug_line(void);
#else
extern void debug_line();
#endif

#ifdef __USE_PROTOS
void obj_computer_clause(void);
#else
extern void obj_computer_clause();
#endif

#ifdef __USE_PROTOS
void obj_suppl_line(void);
#else
extern void obj_suppl_line();
#endif

#ifdef __USE_PROTOS
void collating_line(void);
#else
extern void collating_line();
#endif

#ifdef __USE_PROTOS
void segment_line(void);
#else
extern void segment_line();
#endif

#ifdef __USE_PROTOS
void special_names(void);
#else
extern void special_names();
#endif

#ifdef __USE_PROTOS
void currency_clause(void);
#else
extern void currency_clause();
#endif

#ifdef __USE_PROTOS
void decimal_clause(void);
#else
extern void decimal_clause();
#endif

#ifdef __USE_PROTOS
void class_clause(void);
#else
extern void class_clause();
#endif

#ifdef __USE_PROTOS
void symbolic_clause(void);
#else
extern void symbolic_clause();
#endif

#ifdef __USE_PROTOS
void sym_char_clause(void);
#else
extern void sym_char_clause();
#endif

#ifdef __USE_PROTOS
void alphabet_clause(void);
#else
extern void alphabet_clause();
#endif

#ifdef __USE_PROTOS
void alpha_literal_list(void);
#else
extern void alpha_literal_list();
#endif

#ifdef __USE_PROTOS
void implementor_clause(void);
#else
extern void implementor_clause();
#endif

#ifdef __USE_PROTOS
void on_off(void);
#else
extern void on_off();
#endif

#ifdef __USE_PROTOS
void off_on(void);
#else
extern void off_on();
#endif

#ifdef __USE_PROTOS
void on_status_clause(void);
#else
extern void on_status_clause();
#endif

#ifdef __USE_PROTOS
void off_status_clause(void);
#else
extern void off_status_clause();
#endif

#ifdef __USE_PROTOS
void io_section(void);
#else
extern void io_section();
#endif

#ifdef __USE_PROTOS
void io_control(void);
#else
extern void io_control();
#endif

#ifdef __USE_PROTOS
void area_clause(void);
#else
extern void area_clause();
#endif

#ifdef __USE_PROTOS
void multiple_clause(void);
#else
extern void multiple_clause();
#endif

#ifdef __USE_PROTOS
void data_division(void);
#else
extern void data_division();
#endif

#ifdef __USE_PROTOS
void file_section(void);
#else
extern void file_section();
#endif

#ifdef __USE_PROTOS
void working_storage_section(void);
#else
extern void working_storage_section();
#endif

#ifdef __USE_PROTOS
void linkage_section(void);
#else
extern void linkage_section();
#endif

#ifdef __USE_PROTOS
void procedure_division(void);
#else
extern void procedure_division();
#endif

#ifdef __USE_PROTOS
void sentance(void);
#else
extern void sentance();
#endif

#ifdef __USE_PROTOS
void proc_stmts(void);
#else
extern void proc_stmts();
#endif

#ifdef __USE_PROTOS
void paragraph(void);
#else
extern void paragraph();
#endif

#ifdef __USE_PROTOS
void file_control_clause(void);
#else
extern void file_control_clause();
#endif

#ifdef __USE_PROTOS
void select_line(void);
#else
extern void select_line();
#endif

#ifdef __USE_PROTOS
void assign_line(void);
#else
extern void assign_line();
#endif

#ifdef __USE_PROTOS
void reserve_line(void);
#else
extern void reserve_line();
#endif

#ifdef __USE_PROTOS
void org_line(void);
#else
extern void org_line();
#endif

#ifdef __USE_PROTOS
void padding_line(void);
#else
extern void padding_line();
#endif

#ifdef __USE_PROTOS
void record_line(void);
#else
extern void record_line();
#endif

#ifdef __USE_PROTOS
void access_line(void);
#else
extern void access_line();
#endif

#ifdef __USE_PROTOS
void file_status_line(void);
#else
extern void file_status_line();
#endif

#ifdef __USE_PROTOS
void record_key_line(void);
#else
extern void record_key_line();
#endif

#ifdef __USE_PROTOS
void alt_key_line(void);
#else
extern void alt_key_line();
#endif

#ifdef __USE_PROTOS
void file_description(void);
#else
extern void file_description();
#endif

#ifdef __USE_PROTOS
void fd_line(void);
#else
extern void fd_line();
#endif

#ifdef __USE_PROTOS
void external_line(void);
#else
extern void external_line();
#endif

#ifdef __USE_PROTOS
void global_line(void);
#else
extern void global_line();
#endif

#ifdef __USE_PROTOS
void block_line(void);
#else
extern void block_line();
#endif

#ifdef __USE_PROTOS
void record_line_f(void);
#else
extern void record_line_f();
#endif

#ifdef __USE_PROTOS
void contains_l(void);
#else
extern void contains_l();
#endif

#ifdef __USE_PROTOS
void varying_l(void);
#else
extern void varying_l();
#endif

#ifdef __USE_PROTOS
void from_l(void);
#else
extern void from_l();
#endif

#ifdef __USE_PROTOS
void dep_l(void);
#else
extern void dep_l();
#endif

#ifdef __USE_PROTOS
void label_line(void);
#else
extern void label_line();
#endif

#ifdef __USE_PROTOS
void value_line(void);
#else
extern void value_line();
#endif

#ifdef __USE_PROTOS
void data_line(void);
#else
extern void data_line();
#endif

#ifdef __USE_PROTOS
void linage_foot(void);
#else
extern void linage_foot();
#endif

#ifdef __USE_PROTOS
void linage_l(void);
#else
extern void linage_l();
#endif

#ifdef __USE_PROTOS
void code_set_line(void);
#else
extern void code_set_line();
#endif

#ifdef __USE_PROTOS
void record_descr(void);
#else
extern void record_descr();
#endif

#ifdef __USE_PROTOS
void redefines_line(void);
#else
extern void redefines_line();
#endif

#ifdef __USE_PROTOS
void external_line_r(void);
#else
extern void external_line_r();
#endif

#ifdef __USE_PROTOS
void global_line_r(void);
#else
extern void global_line_r();
#endif

#ifdef __USE_PROTOS
void picture_line(void);
#else
extern void picture_line();
#endif

#ifdef __USE_PROTOS
void usage_line(void);
#else
extern void usage_line();
#endif

#ifdef __USE_PROTOS
void sign_line(void);
#else
extern void sign_line();
#endif

#ifdef __USE_PROTOS
void sync_line(void);
#else
extern void sync_line();
#endif

#ifdef __USE_PROTOS
void just_line(void);
#else
extern void just_line();
#endif

#ifdef __USE_PROTOS
void blank_line(void);
#else
extern void blank_line();
#endif

#ifdef __USE_PROTOS
void value_line_r(void);
#else
extern void value_line_r();
#endif

#ifdef __USE_PROTOS
void renames_line_r(void);
#else
extern void renames_line_r();
#endif

#ifdef __USE_PROTOS
void g88_level_descr(void);
#else
extern void g88_level_descr();
#endif

#ifdef __USE_PROTOS
void condition(void);
#else
extern void condition();
#endif

#ifdef __USE_PROTOS
void general_cond(void);
#else
extern void general_cond();
#endif

#ifdef __USE_PROTOS
void cond_arg(void);
#else
extern void cond_arg();
#endif

#ifdef __USE_PROTOS
void class_arg(void);
#else
extern void class_arg();
#endif

#ifdef __USE_PROTOS
void sign_arg(void);
#else
extern void sign_arg();
#endif

#ifdef __USE_PROTOS
void size_err(void);
#else
extern void size_err();
#endif

#ifdef __USE_PROTOS
void second_size_line(void);
#else
extern void second_size_line();
#endif

#ifdef __USE_PROTOS
void arith_expr(void);
#else
extern void arith_expr();
#endif

#ifdef __USE_PROTOS
void expr4(void);
#else
extern void expr4();
#endif

#ifdef __USE_PROTOS
void expr3(void);
#else
extern void expr3();
#endif

#ifdef __USE_PROTOS
void expr2(void);
#else
extern void expr2();
#endif

#ifdef __USE_PROTOS
void expr1(void);
#else
extern void expr1();
#endif

#ifdef __USE_PROTOS
void expr0(void);
#else
extern void expr0();
#endif

#ifdef __USE_PROTOS
void uni_op(void);
#else
extern void uni_op();
#endif

#ifdef __USE_PROTOS
void add_op(void);
#else
extern void add_op();
#endif

#ifdef __USE_PROTOS
void mult_op(void);
#else
extern void mult_op();
#endif

#ifdef __USE_PROTOS
void relation(void);
#else
extern void relation();
#endif

#ifdef __USE_PROTOS
void geneq(void);
#else
extern void geneq();
#endif

#ifdef __USE_PROTOS
void gengt(void);
#else
extern void gengt();
#endif

#ifdef __USE_PROTOS
void genlt(void);
#else
extern void genlt();
#endif

#ifdef __USE_PROTOS
void genge(void);
#else
extern void genge();
#endif

#ifdef __USE_PROTOS
void genle(void);
#else
extern void genle();
#endif

#ifdef __USE_PROTOS
void invalid_key(void);
#else
extern void invalid_key();
#endif

#ifdef __USE_PROTOS
void second_invalid_key_line(void);
#else
extern void second_invalid_key_line();
#endif

#ifdef __USE_PROTOS
void at_end(void);
#else
extern void at_end();
#endif

#ifdef __USE_PROTOS
void second_end_line(void);
#else
extern void second_end_line();
#endif

#ifdef __USE_PROTOS
void accept_stmt(void);
#else
extern void accept_stmt();
#endif

#ifdef __USE_PROTOS
void add_stmt(void);
#else
extern void add_stmt();
#endif

#ifdef __USE_PROTOS
void add_sizing(void);
#else
extern void add_sizing();
#endif

#ifdef __USE_PROTOS
void add_ending(void);
#else
extern void add_ending();
#endif

#ifdef __USE_PROTOS
void add_main(void);
#else
extern void add_main();
#endif

#ifdef __USE_PROTOS
void ident1_line(void);
#else
extern void ident1_line();
#endif

#ifdef __USE_PROTOS
void ident2_line(void);
#else
extern void ident2_line();
#endif

#ifdef __USE_PROTOS
void giving_line(void);
#else
extern void giving_line();
#endif

#ifdef __USE_PROTOS
void compute_stmt(void);
#else
extern void compute_stmt();
#endif

#ifdef __USE_PROTOS
void compute_sizing(void);
#else
extern void compute_sizing();
#endif

#ifdef __USE_PROTOS
void compute_ending(void);
#else
extern void compute_ending();
#endif

#ifdef __USE_PROTOS
void copy_stmt(void);
#else
extern void copy_stmt();
#endif

#ifdef __USE_PROTOS
void display_stmt(void);
#else
extern void display_stmt();
#endif

#ifdef __USE_PROTOS
void upon_line(void);
#else
extern void upon_line();
#endif

#ifdef __USE_PROTOS
void adv_line(void);
#else
extern void adv_line();
#endif

#ifdef __USE_PROTOS
void divide_stmt(void);
#else
extern void divide_stmt();
#endif

#ifdef __USE_PROTOS
void div_sizing(void);
#else
extern void div_sizing();
#endif

#ifdef __USE_PROTOS
void div_ending(void);
#else
extern void div_ending();
#endif

#ifdef __USE_PROTOS
void div2_line(void);
#else
extern void div2_line();
#endif

#ifdef __USE_PROTOS
void div_giving_line(void);
#else
extern void div_giving_line();
#endif

#ifdef __USE_PROTOS
void remainder_clause(void);
#else
extern void remainder_clause();
#endif

#ifdef __USE_PROTOS
void go_stmt(void);
#else
extern void go_stmt();
#endif

#ifdef __USE_PROTOS
void if_stmt(void);
#else
extern void if_stmt();
#endif

#ifdef __USE_PROTOS
void else_clause(void);
#else
extern void else_clause();
#endif

#ifdef __USE_PROTOS
void initialize_stmt(void);
#else
extern void initialize_stmt();
#endif

#ifdef __USE_PROTOS
void replacing_line(void);
#else
extern void replacing_line();
#endif

#ifdef __USE_PROTOS
void target_type(void);
#else
extern void target_type();
#endif

#ifdef __USE_PROTOS
void new_type(void);
#else
extern void new_type();
#endif

#ifdef __USE_PROTOS
void move_stmt(void);
#else
extern void move_stmt();
#endif

#ifdef __USE_PROTOS
void multiply_stmt(void);
#else
extern void multiply_stmt();
#endif

#ifdef __USE_PROTOS
void mult_sizing(void);
#else
extern void mult_sizing();
#endif

#ifdef __USE_PROTOS
void mult_ending(void);
#else
extern void mult_ending();
#endif

#ifdef __USE_PROTOS
void mult2_line(void);
#else
extern void mult2_line();
#endif

#ifdef __USE_PROTOS
void mult_giving_line(void);
#else
extern void mult_giving_line();
#endif

#ifdef __USE_PROTOS
void subtract_stmt(void);
#else
extern void subtract_stmt();
#endif

#ifdef __USE_PROTOS
void subtract_sizing(void);
#else
extern void subtract_sizing();
#endif

#ifdef __USE_PROTOS
void subtract_ending(void);
#else
extern void subtract_ending();
#endif

#ifdef __USE_PROTOS
void subtract_main(void);
#else
extern void subtract_main();
#endif

#ifdef __USE_PROTOS
void sub_ident1_line(void);
#else
extern void sub_ident1_line();
#endif

#ifdef __USE_PROTOS
void sub_ident2_line(void);
#else
extern void sub_ident2_line();
#endif

#ifdef __USE_PROTOS
void sub_giving_line(void);
#else
extern void sub_giving_line();
#endif

#ifdef __USE_PROTOS
void stop_stmt(void);
#else
extern void stop_stmt();
#endif

#ifdef __USE_PROTOS
void perform_stmt(void);
#else
extern void perform_stmt();
#endif

#ifdef __USE_PROTOS
void perform_proc_line(void);
#else
extern void perform_proc_line();
#endif

#ifdef __USE_PROTOS
void perform_imperative_line(void);
#else
extern void perform_imperative_line();
#endif

#ifdef __USE_PROTOS
void perform_times_line(void);
#else
extern void perform_times_line();
#endif

#ifdef __USE_PROTOS
void perform_test_line(void);
#else
extern void perform_test_line();
#endif

#ifdef __USE_PROTOS
void perform_until_line(void);
#else
extern void perform_until_line();
#endif

#ifdef __USE_PROTOS
void perform_varying_line(void);
#else
extern void perform_varying_line();
#endif

#ifdef __USE_PROTOS
void perform_from_line(void);
#else
extern void perform_from_line();
#endif

#ifdef __USE_PROTOS
void perform_by_line(void);
#else
extern void perform_by_line();
#endif

#endif
extern SetWordType setwd1[];
extern SetWordType zzerr1[];
extern SetWordType zzerr2[];
extern SetWordType setwd2[];
extern SetWordType zzerr3[];
extern SetWordType zzerr4[];
extern SetWordType zzerr5[];
extern SetWordType setwd3[];
extern SetWordType zzerr6[];
extern SetWordType setwd4[];
extern SetWordType zzerr7[];
extern SetWordType zzerr8[];
extern SetWordType zzerr9[];
extern SetWordType zzerr10[];
extern SetWordType zzerr11[];
extern SetWordType setwd5[];
extern SetWordType zzerr12[];
extern SetWordType zzerr13[];
extern SetWordType setwd6[];
extern SetWordType setwd7[];
extern SetWordType setwd8[];
extern SetWordType zzerr14[];
extern SetWordType zzerr15[];
extern SetWordType zzerr16[];
extern SetWordType setwd9[];
extern SetWordType zzerr17[];
extern SetWordType setwd10[];
extern SetWordType zzerr18[];
extern SetWordType setwd11[];
extern SetWordType zzerr19[];
extern SetWordType zzerr20[];
extern SetWordType setwd12[];
extern SetWordType zzerr21[];
extern SetWordType zzerr22[];
extern SetWordType zzerr23[];
extern SetWordType zzerr24[];
extern SetWordType zzerr25[];
extern SetWordType setwd13[];
extern SetWordType zzerr26[];
extern SetWordType setwd14[];
extern SetWordType zzerr27[];
extern SetWordType setwd15[];
extern SetWordType zzerr28[];
extern SetWordType zzerr29[];
extern SetWordType zzerr30[];
extern SetWordType zzerr31[];
extern SetWordType zzerr32[];
extern SetWordType zzerr33[];
extern SetWordType zzerr34[];
extern SetWordType setwd16[];
extern SetWordType zzerr35[];
extern SetWordType zzerr36[];
extern SetWordType setwd17[];
extern SetWordType zzerr37[];
extern SetWordType zzerr38[];
extern SetWordType zzerr39[];
extern SetWordType zzerr40[];
extern SetWordType setwd18[];
extern SetWordType zzerr41[];
extern SetWordType zzerr42[];
extern SetWordType zzerr43[];
extern SetWordType zzerr44[];
extern SetWordType setwd19[];
extern SetWordType setwd20[];
extern SetWordType zzerr45[];
extern SetWordType zzerr46[];
extern SetWordType zzerr47[];
extern SetWordType zzerr48[];
extern SetWordType setwd21[];
extern SetWordType setwd22[];
extern SetWordType zzerr49[];
extern SetWordType zzerr50[];
extern SetWordType zzerr51[];
extern SetWordType zzerr52[];
extern SetWordType zzerr53[];
extern SetWordType setwd23[];
extern SetWordType zzerr54[];
extern SetWordType zzerr55[];
extern SetWordType zzerr56[];
extern SetWordType zzerr57[];
extern SetWordType zzerr58[];
extern SetWordType setwd24[];
extern SetWordType zzerr59[];
extern SetWordType zzerr60[];
extern SetWordType zzerr61[];
extern SetWordType zzerr62[];
extern SetWordType zzerr63[];
extern SetWordType setwd25[];
extern SetWordType zzerr64[];
extern SetWordType zzerr65[];
extern SetWordType zzerr66[];
extern SetWordType zzerr67[];
extern SetWordType setwd26[];
extern SetWordType zzerr68[];
extern SetWordType zzerr69[];
extern SetWordType zzerr70[];
extern SetWordType zzerr71[];
extern SetWordType setwd27[];
extern SetWordType zzerr72[];
extern SetWordType zzerr73[];
extern SetWordType zzerr74[];
extern SetWordType zzerr75[];
extern SetWordType zzerr76[];
extern SetWordType setwd28[];
extern SetWordType zzerr77[];
extern SetWordType zzerr78[];
extern SetWordType zzerr79[];
extern SetWordType zzerr80[];
extern SetWordType setwd29[];
extern SetWordType zzerr81[];
extern SetWordType setwd30[];
extern SetWordType setwd31[];
extern SetWordType zzerr82[];
extern SetWordType zzerr83[];
extern SetWordType zzerr84[];
extern SetWordType zzerr85[];
extern SetWordType setwd32[];
extern SetWordType zzerr86[];
extern SetWordType zzerr87[];
extern SetWordType zzerr88[];
extern SetWordType zzerr89[];
extern SetWordType zzerr90[];
extern SetWordType setwd33[];
extern SetWordType zzerr91[];
extern SetWordType zzerr92[];
extern SetWordType zzerr93[];
extern SetWordType setwd34[];
extern SetWordType zzerr94[];
extern SetWordType zzerr95[];
extern SetWordType zzerr96[];
extern SetWordType zzerr97[];
extern SetWordType setwd35[];
extern SetWordType setwd36[];
extern SetWordType zzerr98[];
extern SetWordType zzerr99[];
extern SetWordType zzerr100[];
extern SetWordType zzerr101[];
extern SetWordType zzerr102[];
extern SetWordType setwd37[];
extern SetWordType zzerr103[];
extern SetWordType zzerr104[];
extern SetWordType zzerr105[];
extern SetWordType setwd38[];
extern SetWordType zzerr106[];
extern SetWordType zzerr107[];
extern SetWordType zzerr108[];
extern SetWordType zzerr109[];
extern SetWordType zzerr110[];
extern SetWordType setwd39[];
