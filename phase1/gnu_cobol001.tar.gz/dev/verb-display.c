/*
 * A n t l r  T r a n s l a t i o n  H e a d e r
 *
 * Terence Parr, Will Cohen, and Hank Dietz: 1989-1994
 * Purdue University Electrical Engineering
 * With AHPCRC, University of Minnesota
 * ANTLR Version 1.33MR9
 */
#include <stdio.h>
#define ANTLR_VERSION	133MR9

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "charbuf.h"
#include "c-global.h"
#define ZZCAN_GUESS
#include <setjmp.h>
#define LL_K 4
#define zzSET_SIZE 48
#include "antlr.h"
#include "tokens.h"
#include "dlgdef.h"
#include "mode.h"
#ifndef PURIFY
#define PURIFY(r,s)
#endif

void
#ifdef __USE_PROTOS
display_stmt(void)
#else
display_stmt()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	zzmatch(DISPLAY);
	zzNON_GUESS_MODE {
	printf("display\n");   
	}
 zzCONSUME;

	{
		zzBLOCK(zztasp2);
		int zzcnt=1;
		zzMake0;
		{
		do {
			if ( (LA(1)==PROG_NAME) ) {
				ident();
				zzNON_GUESS_MODE {
				printf("%s\n", Ident); emit_display_ident(Ident);   
				}
			}
			else {
				if ( (LA(1)==NUMERIC) ) {
					numeric();
					zzNON_GUESS_MODE {
					emit_display_literal(Numeric_s);   
					}
				}
				else {
					if ( (LA(1)==NONNUMERIC)
 ) {
						string_literal();
						zzNON_GUESS_MODE {
						emit_display_literal(StringLiteral);   
						}
					}
					else if ( zzcnt>1 ) break; /* implied exit branch */
					else {zzFAIL(1,zzerr71,&zzMissSet,&zzMissText,&zzBadTok,&zzBadText,&zzErrk); goto fail;}
				}
			}
			zzcnt++; zzLOOP(zztasp2);
		} while ( 1 );
		zzEXIT(zztasp2);
		}
	}
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==UPON) ) {
			upon_line();
		}
		zzEXIT(zztasp2);
		}
	}
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (setwd27[LA(1)]&0x80) ) {
			adv_line();
		}
		zzEXIT(zztasp2);
		}
	}
	zzNON_GUESS_MODE {
	emit_display_advance(0);   
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd28, 0x1);
	}
}

void
#ifdef __USE_PROTOS
upon_line(void)
#else
upon_line()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	zzmatch(UPON); zzCONSUME;
	ident();
	zzNON_GUESS_MODE {
	WarnNotImpl("UPON");   
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd28, 0x2);
	}
}

void
#ifdef __USE_PROTOS
adv_line(void)
#else
adv_line()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==WITH) ) {
			zzmatch(WITH); zzCONSUME;
		}
		zzEXIT(zztasp2);
		}
	}
	zzmatch(NO); zzCONSUME;
	zzmatch(ADVANCING);
	zzNON_GUESS_MODE {
	emit_display_advance(1);   
	}
 zzCONSUME;

	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd28, 0x4);
	}
}
