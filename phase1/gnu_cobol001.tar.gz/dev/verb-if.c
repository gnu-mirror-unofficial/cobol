/*
 * A n t l r  T r a n s l a t i o n  H e a d e r
 *
 * Terence Parr, Will Cohen, and Hank Dietz: 1989-1994
 * Purdue University Electrical Engineering
 * With AHPCRC, University of Minnesota
 * ANTLR Version 1.33MR9
 */
#include <stdio.h>
#define ANTLR_VERSION	133MR9

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "charbuf.h"
#include "c-global.h"
#define ZZCAN_GUESS
#include <setjmp.h>
#define LL_K 4
#define zzSET_SIZE 48
#include "antlr.h"
#include "tokens.h"
#include "dlgdef.h"
#include "mode.h"
#ifndef PURIFY
#define PURIFY(r,s)
#endif

void
#ifdef __USE_PROTOS
if_stmt(void)
#else
if_stmt()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	zzmatch(IF_C);
	zzNON_GUESS_MODE {
	emit_if_start();   
	}
 zzCONSUME;

	condition();
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==THEN) ) {
			zzmatch(THEN); zzCONSUME;
		}
		zzEXIT(zztasp2);
		}
	}
	zzNON_GUESS_MODE {
	emit_if_block();   
	}
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==NEXT)
 ) {
			zzmatch(NEXT); zzCONSUME;
			zzmatch(SENTENCE);
			zzNON_GUESS_MODE {
			emit_if_next_sentence();   
			}
 zzCONSUME;

		}
		else {
			if ( (setwd30[LA(1)]&0x1) ) {
				{
					zzBLOCK(zztasp3);
					int zzcnt=1;
					zzMake0;
					{
					do {
						statement();
						zzLOOP(zztasp3);
					} while ( (setwd30[LA(1)]&0x2) && (setwd30[LA(2)]&0x4) && (setwd30[LA(3)]&0x8) && (setwd30[LA(4)]&0x10) );
					zzEXIT(zztasp3);
					}
				}
			}
			else {zzFAIL(1,zzerr81,&zzMissSet,&zzMissText,&zzBadTok,&zzBadText,&zzErrk); goto fail;}
		}
		zzEXIT(zztasp2);
		}
	}
	zzNON_GUESS_MODE {
	emit_if_end();   
	}
	else_clause();
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd30, 0x20);
	}
}

void
#ifdef __USE_PROTOS
else_clause(void)
#else
else_clause()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==ELSE_C) && 
(LA(2)==NEXT) && (LA(3)==SENTENCE) && (setwd30[LA(4)]&0x40) ) {
			zzmatch(ELSE_C);
			zzNON_GUESS_MODE {
			emit_else_start();   
			}
 zzCONSUME;

			zzmatch(NEXT); zzCONSUME;
			zzmatch(SENTENCE);
			zzNON_GUESS_MODE {
			emit_else_next_sentence();   
			}
 zzCONSUME;

		}
		else {
			if ( (LA(1)==ELSE_C) && (setwd30[LA(2)]&0x80) && (setwd31[LA(3)]&0x1) && 
(setwd31[LA(4)]&0x2) ) {
				zzmatch(ELSE_C);
				zzNON_GUESS_MODE {
				emit_else_start();   
				}
 zzCONSUME;

				{
					zzBLOCK(zztasp3);
					int zzcnt=1;
					zzMake0;
					{
					do {
						statement();
						zzLOOP(zztasp3);
					} while ( (setwd31[LA(1)]&0x4) && (setwd31[LA(2)]&0x8) && (setwd31[LA(3)]&0x10) && (setwd31[LA(4)]&0x20) );
					zzEXIT(zztasp3);
					}
				}
				{
					zzBLOCK(zztasp3);
					zzMake0;
					{
					if ( (LA(1)==END_IF) && (setwd31[LA(2)]&0x40) && 
(setwd31[LA(3)]&0x80) && (setwd32[LA(4)]&0x1) ) {
						zzmatch(END_IF); zzCONSUME;
					}
					zzEXIT(zztasp3);
					}
				}
				zzNON_GUESS_MODE {
				emit_else_end();   
				}
			}
			else {
				if ( (setwd32[LA(1)]&0x2) && (setwd32[LA(2)]&0x4) && (setwd32[LA(3)]&0x8) && (setwd32[LA(4)]&0x10) ) {
					{
						zzBLOCK(zztasp3);
						zzMake0;
						{
						if ( (LA(1)==END_IF) && 
(setwd32[LA(2)]&0x20) && (setwd32[LA(3)]&0x40) && (setwd32[LA(4)]&0x80) ) {
							zzmatch(END_IF); zzCONSUME;
						}
						zzEXIT(zztasp3);
						}
					}
				}
				else {zzFAIL(4,zzerr82,zzerr83,zzerr84,zzerr85,&zzMissSet,&zzMissText,&zzBadTok,&zzBadText,&zzErrk); goto fail;}
			}
		}
		zzEXIT(zztasp2);
		}
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd33, 0x1);
	}
}
