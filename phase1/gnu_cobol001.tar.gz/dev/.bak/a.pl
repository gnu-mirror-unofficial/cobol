#!/umr/bin/perl

while($line=<>) {
chop($line);
@a=split("\t+", $line);

print("\"$a[1]\"\t\{ printf\(\"$a[0]\\n\"\)\; \} \n");

}
