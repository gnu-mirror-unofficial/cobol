/*
 * A n t l r  T r a n s l a t i o n  H e a d e r
 *
 * Terence Parr, Will Cohen, and Hank Dietz: 1989-1994
 * Purdue University Electrical Engineering
 * With AHPCRC, University of Minnesota
 * ANTLR Version 1.33MR9
 */
#include <stdio.h>
#define ANTLR_VERSION	133MR9

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "charbuf.h"
#include "c-global.h"
#define ZZCAN_GUESS
#include <setjmp.h>
#define LL_K 4
#define zzSET_SIZE 48
#include "antlr.h"
#include "tokens.h"
#include "dlgdef.h"
#include "mode.h"
#ifndef PURIFY
#define PURIFY(r,s)
#endif

void
#ifdef __USE_PROTOS
procedure_division(void)
#else
procedure_division()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
#ifdef DEBUG
	fprintf(stderr, "Entering PROCEDURE DIVISION\n");
#endif   
	zzmatch(PROCEDURE); zzCONSUME;
	zzmatch(DIVISION); zzCONSUME;
	zzmatch(PERIOD);
	zzNON_GUESS_MODE {
	emit_paragraph_main_start();   
	}
 zzCONSUME;

	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		while ( (setwd8[LA(1)]&0x1) ) {
			sentance();
			zzLOOP(zztasp2);
		}
		zzEXIT(zztasp2);
		}
	}
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		while ( (LA(1)==PROG_NAME)
 ) {
			proc_stmts();
			zzLOOP(zztasp2);
		}
		zzEXIT(zztasp2);
		}
	}
	zzNON_GUESS_MODE {
	emit_paragraph_end();   
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd8, 0x2);
	}
}

void
#ifdef __USE_PROTOS
sentance(void)
#else
sentance()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	{
		zzBLOCK(zztasp2);
		int zzcnt=1;
		zzMake0;
		{
		do {
			statement();
			zzLOOP(zztasp2);
		} while ( (setwd8[LA(1)]&0x4) );
		zzEXIT(zztasp2);
		}
	}
	zzmatch(PERIOD);
	zzNON_GUESS_MODE {
	SetFlag(&verb_flags, PROC_DIV_MAIN);   
	}
 zzCONSUME;

	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd8, 0x8);
	}
}

void
#ifdef __USE_PROTOS
proc_stmts(void)
#else
proc_stmts()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	paragraph();
	{
		zzBLOCK(zztasp2);
		int zzcnt=1;
		zzMake0;
		{
		do {
			sentance();
			zzLOOP(zztasp2);
		} while ( (setwd8[LA(1)]&0x10) );
		zzEXIT(zztasp2);
		}
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd8, 0x20);
	}
}

void
#ifdef __USE_PROTOS
paragraph(void)
#else
paragraph()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	ident();
	zzNON_GUESS_MODE {
	/* if saw a regular stmt, emit close main */
	if (verb_flags & PROC_DIV_MAIN) {
		emit_paragraph_end();
		emit_paragraph_start(Ident);
	}
	MakeNewParagraph(Ident);
	
	   #ifdef DEBUG
	fprintf(stderr, "-PARAGRAPH: %s\n", zzaArg(zztasp1,2));
#endif   
	}
	zzmatch(PERIOD); zzCONSUME;
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd8, 0x40);
	}
}
