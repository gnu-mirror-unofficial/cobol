/*
 * A n t l r  T r a n s l a t i o n  H e a d e r
 *
 * Terence Parr, Will Cohen, and Hank Dietz: 1989-1994
 * Purdue University Electrical Engineering
 * With AHPCRC, University of Minnesota
 * ANTLR Version 1.33MR9
 */
#include <stdio.h>
#define ANTLR_VERSION	133MR9

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "charbuf.h"
#include "c-global.h"
#define ZZCAN_GUESS
#include <setjmp.h>
#define LL_K 4
#define zzSET_SIZE 48
#include "antlr.h"
#include "tokens.h"
#include "dlgdef.h"
#include "mode.h"
#ifndef PURIFY
#define PURIFY(r,s)
#endif

void
#ifdef __USE_PROTOS
perform_stmt(void)
#else
perform_stmt()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	zzmatch(PERFORM);
	zzNON_GUESS_MODE {
	emit_perform_start();   
	}
 zzCONSUME;

	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==PROG_NAME) && (setwd36[LA(2)]&0x2) && 
(setwd36[LA(3)]&0x4) && (setwd36[LA(4)]&0x8) && !((LA(1)==PROG_NAME&&((LA(2)==TIMES&&((LA(3)==ACCEPT&&(LA(4)==PROG_NAME))||
((LA(3)==DISPLAY&&(LA(4)==PROG_NAME||(LA(4)==NUMERIC||(LA(4)==NONNUMERIC))))||((LA(3)==MOVE&&
(LA(4)==CORR||(LA(4)==PROG_NAME||(LA(4)==NUMERIC||(LA(4)==NONNUMERIC)))))||((LA(3)==PERFORM&&
(LA(4)==PROG_NAME||(LA(4)==NUMERIC||(LA(4)==WITH||(LA(4)==TEST||(LA(4)==UNTIL))))))||
((LA(3)==STOP&&(LA(4)==RUN||(LA(4)==END_PERFORM)))))))))))) ) {
			perform_proc_line();
			{
				zzBLOCK(zztasp3);
				zzMake0;
				{
				if ( (setwd36[LA(1)]&0x10) ) {
					perform_times_line();
				}
				else {
					if ( (setwd36[LA(1)]&0x20) ) {
						{
							zzBLOCK(zztasp4);
							zzMake0;
							{
							if ( (setwd36[LA(1)]&0x40)
 ) {
								perform_test_line();
							}
							zzEXIT(zztasp4);
							}
						}
						perform_until_line();
					}
				}
				zzEXIT(zztasp3);
				}
			}
		}
		else {
			if ( (setwd36[LA(1)]&0x80) && (setwd37[LA(2)]&0x1) && (setwd37[LA(3)]&0x2) && (setwd37[LA(4)]&0x4) ) {
				{
					zzBLOCK(zztasp3);
					zzMake0;
					{
					if ( (setwd37[LA(1)]&0x8) ) {
						perform_times_line();
					}
					else {
						if ( (setwd37[LA(1)]&0x10)
 ) {
							{
								zzBLOCK(zztasp4);
								zzMake0;
								{
								if ( (setwd37[LA(1)]&0x20) ) {
									perform_test_line();
								}
								zzEXIT(zztasp4);
								}
							}
							perform_until_line();
						}
						else {zzFAIL(1,zzerr98,&zzMissSet,&zzMissText,&zzBadTok,&zzBadText,&zzErrk); goto fail;}
					}
					zzEXIT(zztasp3);
					}
				}
				perform_imperative_line();
				zzNON_GUESS_MODE {
				strcpy(PerformParagraph, "");   
				}
			}
			else {zzFAIL(4,zzerr99,zzerr100,zzerr101,zzerr102,&zzMissSet,&zzMissText,&zzBadTok,&zzBadText,&zzErrk); goto fail;}
		}
		zzEXIT(zztasp2);
		}
	}
	zzNON_GUESS_MODE {
	emit_perform_end(PerformParagraph);   
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd37, 0x40);
	}
}

void
#ifdef __USE_PROTOS
perform_proc_line(void)
#else
perform_proc_line()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	ident();
	zzNON_GUESS_MODE {
	printf("PERFORM %s\n", Ident); 
	strcpy(PerformParagraph, Ident);
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd37, 0x80);
	}
}

void
#ifdef __USE_PROTOS
perform_imperative_line(void)
#else
perform_imperative_line()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	imperative();
	zzmatch(END_PERFORM); zzCONSUME;
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd38, 0x1);
	}
}

void
#ifdef __USE_PROTOS
perform_times_line(void)
#else
perform_times_line()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==PROG_NAME) ) {
			ident();
			zzNON_GUESS_MODE {
			VerifyIdentType(Ident, 'N');
			emit_perform_times(Ident, 0);
			}
		}
		else {
			if ( (LA(1)==NUMERIC) ) {
				integer();
				zzNON_GUESS_MODE {
				emit_perform_times(Numeric_s, 1);   
				}
			}
			else {zzFAIL(1,zzerr103,&zzMissSet,&zzMissText,&zzBadTok,&zzBadText,&zzErrk); goto fail;}
		}
		zzEXIT(zztasp2);
		}
	}
	zzmatch(TIMES); zzCONSUME;
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd38, 0x2);
	}
}

void
#ifdef __USE_PROTOS
perform_test_line(void)
#else
perform_test_line()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==WITH) ) {
			zzmatch(WITH); zzCONSUME;
		}
		zzEXIT(zztasp2);
		}
	}
	zzmatch(TEST); zzCONSUME;
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==BEFORE)
 ) {
			zzmatch(BEFORE);
			zzNON_GUESS_MODE {
			emit_perform_loop_before();   
			}
 zzCONSUME;

		}
		else {
			if ( (LA(1)==AFTER) ) {
				zzmatch(AFTER);
				zzNON_GUESS_MODE {
				emit_perform_loop_after();   
				}
 zzCONSUME;

			}
			else {zzFAIL(1,zzerr104,&zzMissSet,&zzMissText,&zzBadTok,&zzBadText,&zzErrk); goto fail;}
		}
		zzEXIT(zztasp2);
		}
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd38, 0x4);
	}
}

void
#ifdef __USE_PROTOS
perform_until_line(void)
#else
perform_until_line()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	zzmatch(UNTIL); zzCONSUME;
	condition();
	zzNON_GUESS_MODE {
	emit_perform_loop_end();   
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd38, 0x8);
	}
}

void
#ifdef __USE_PROTOS
perform_varying_line(void)
#else
perform_varying_line()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	zzmatch(VARYING); zzCONSUME;
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==PROG_NAME) ) {
			ident();
		}
		else {
			if ( (LA(1)==NUMERIC) ) {
				index_name();
			}
			else {zzFAIL(1,zzerr105,&zzMissSet,&zzMissText,&zzBadTok,&zzBadText,&zzErrk); goto fail;}
		}
		zzEXIT(zztasp2);
		}
	}
	perform_from_line();
	perform_by_line();
	zzNON_GUESS_MODE {
	WarnNotImpl("VARYING clause");   
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd38, 0x10);
	}
}

void
#ifdef __USE_PROTOS
perform_from_line(void)
#else
perform_from_line()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	zzmatch(FROM); zzCONSUME;
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==PROG_NAME) ) {
			ident();
		}
		else {
			if ( (LA(1)==NUMERIC) && 
(setwd38[LA(2)]&0x20) && (setwd38[LA(3)]&0x40) && (setwd38[LA(4)]&0x80) ) {
				index_name();
			}
			else {
				if ( (LA(1)==NUMERIC) && (setwd39[LA(2)]&0x1) && (setwd39[LA(3)]&0x2) && 
(setwd39[LA(4)]&0x4) ) {
					numeric();
				}
				else {zzFAIL(4,zzerr106,zzerr107,zzerr108,zzerr109,&zzMissSet,&zzMissText,&zzBadTok,&zzBadText,&zzErrk); goto fail;}
			}
		}
		zzEXIT(zztasp2);
		}
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd39, 0x8);
	}
}

void
#ifdef __USE_PROTOS
perform_by_line(void)
#else
perform_by_line()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	zzmatch(BY); zzCONSUME;
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==PROG_NAME) ) {
			ident();
		}
		else {
			if ( (LA(1)==NUMERIC) ) {
				numeric();
			}
			else {zzFAIL(1,zzerr110,&zzMissSet,&zzMissText,&zzBadTok,&zzBadText,&zzErrk); goto fail;}
		}
		zzEXIT(zztasp2);
		}
	}
	zzmatch(UNTIL); zzCONSUME;
	condition();
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd39, 0x10);
	}
}
