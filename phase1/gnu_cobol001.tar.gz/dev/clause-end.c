/*
 * A n t l r  T r a n s l a t i o n  H e a d e r
 *
 * Terence Parr, Will Cohen, and Hank Dietz: 1989-1994
 * Purdue University Electrical Engineering
 * With AHPCRC, University of Minnesota
 * ANTLR Version 1.33MR9
 */
#include <stdio.h>
#define ANTLR_VERSION	133MR9

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "charbuf.h"
#include "c-global.h"
#define ZZCAN_GUESS
#include <setjmp.h>
#define LL_K 4
#define zzSET_SIZE 48
#include "antlr.h"
#include "tokens.h"
#include "dlgdef.h"
#include "mode.h"
#ifndef PURIFY
#define PURIFY(r,s)
#endif

void
#ifdef __USE_PROTOS
at_end(void)
#else
at_end()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==NOT) ) {
			zzmatch(NOT); zzCONSUME;
		}
		zzEXIT(zztasp2);
		}
	}
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==AT) ) {
			zzmatch(AT); zzCONSUME;
		}
		zzEXIT(zztasp2);
		}
	}
	zzmatch(END); zzCONSUME;
	imperative();
	second_end_line();
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd25, 0x1);
	}
}

void
#ifdef __USE_PROTOS
second_end_line(void)
#else
second_end_line()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	zzGUESS_BLOCK
	zzGUESS
	if ( !zzrv && (setwd25[LA(1)]&0x2) ) {
		{
			zzBLOCK(zztasp2);
			zzMake0;
			{
			{
				zzBLOCK(zztasp3);
				zzMake0;
				{
				if ( (LA(1)==NOT)
 ) {
					zzmatch(NOT); zzCONSUME;
				}
				zzEXIT(zztasp3);
				}
			}
			{
				zzBLOCK(zztasp3);
				zzMake0;
				{
				if ( (LA(1)==AT) ) {
					zzmatch(AT); zzCONSUME;
				}
				zzEXIT(zztasp3);
				}
			}
			zzmatch(END); zzCONSUME;
			imperative();
			zzEXIT(zztasp2);
			}
		}
		zzGUESS_DONE
		{
			zzBLOCK(zztasp2);
			zzMake0;
			{
			{
				zzBLOCK(zztasp3);
				zzMake0;
				{
				if ( (LA(1)==NOT) ) {
					zzmatch(NOT); zzCONSUME;
				}
				zzEXIT(zztasp3);
				}
			}
			{
				zzBLOCK(zztasp3);
				zzMake0;
				{
				if ( (LA(1)==AT) ) {
					zzmatch(AT); zzCONSUME;
				}
				zzEXIT(zztasp3);
				}
			}
			zzmatch(END); zzCONSUME;
			imperative();
			zzEXIT(zztasp2);
			}
		}
	}
	else {
		if ( zzguessing ) zzGUESS_DONE;
		if ( (LA(1)==1) ) {
		}
		else {zzFAIL(1,zzerr59,&zzMissSet,&zzMissText,&zzBadTok,&zzBadText,&zzErrk); goto fail;}
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd25, 0x4);
	}
}
