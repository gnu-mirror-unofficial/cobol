/*
 * A n t l r  T r a n s l a t i o n  H e a d e r
 *
 * Terence Parr, Will Cohen, and Hank Dietz: 1989-1994
 * Purdue University Electrical Engineering
 * With AHPCRC, University of Minnesota
 * ANTLR Version 1.33MR9
 */
#include <stdio.h>
#define ANTLR_VERSION	133MR9

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "charbuf.h"
#include "c-global.h"
#define ZZCAN_GUESS
#include <setjmp.h>
#define LL_K 4
#define zzSET_SIZE 48
#include "antlr.h"
#include "tokens.h"
#include "dlgdef.h"
#include "mode.h"
#ifndef PURIFY
#define PURIFY(r,s)
#endif

void
#ifdef __USE_PROTOS
go_stmt(void)
#else
go_stmt()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	zzmatch(GO); zzCONSUME;
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==TO)
 ) {
			zzmatch(TO); zzCONSUME;
		}
		zzEXIT(zztasp2);
		}
	}
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==PROG_NAME) && (setwd29[LA(2)]&0x8) && (LA(3)==1) && (LA(4)==1) ) {
			ident();
		}
		else {
			if ( (LA(1)==PROG_NAME) && (setwd29[LA(2)]&0x10) && 
(setwd29[LA(3)]&0x20) && (setwd29[LA(4)]&0x40) ) {
				{
					zzBLOCK(zztasp3);
					int zzcnt=1;
					zzMake0;
					{
					do {
						ident();
						zzLOOP(zztasp3);
					} while ( (LA(1)==PROG_NAME) );
					zzEXIT(zztasp3);
					}
				}
				zzmatch(DEPENDING); zzCONSUME;
				{
					zzBLOCK(zztasp3);
					zzMake0;
					{
					if ( (LA(1)==ON) ) {
						zzmatch(ON); zzCONSUME;
					}
					zzEXIT(zztasp3);
					}
				}
				ident();
			}
			else {zzFAIL(4,zzerr77,zzerr78,zzerr79,zzerr80,&zzMissSet,&zzMissText,&zzBadTok,&zzBadText,&zzErrk); goto fail;}
		}
		zzEXIT(zztasp2);
		}
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd29, 0x80);
	}
}
