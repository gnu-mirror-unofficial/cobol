/*
 * A n t l r  T r a n s l a t i o n  H e a d e r
 *
 * Terence Parr, Will Cohen, and Hank Dietz: 1989-1994
 * Purdue University Electrical Engineering
 * With AHPCRC, University of Minnesota
 * ANTLR Version 1.33MR9
 */
#include <stdio.h>
#define ANTLR_VERSION	133MR9

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "charbuf.h"
#include "c-global.h"
#define ZZCAN_GUESS
#include <setjmp.h>
#define LL_K 4
#define zzSET_SIZE 48
#include "antlr.h"
#include "tokens.h"
#include "dlgdef.h"
#include "mode.h"
#ifndef PURIFY
#define PURIFY(r,s)
#endif

void
#ifdef __USE_PROTOS
divide_stmt(void)
#else
divide_stmt()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	zzmatch(DIVIDE); zzCONSUME;
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==PROG_NAME) ) {
			ident();
		}
		else {
			if ( (LA(1)==NUMERIC)
 ) {
				numeric();
			}
			else {zzFAIL(1,zzerr72,&zzMissSet,&zzMissText,&zzBadTok,&zzBadText,&zzErrk); goto fail;}
		}
		zzEXIT(zztasp2);
		}
	}
	div2_line();
	div_sizing();
	div_ending();
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd28, 0x8);
	}
}

void
#ifdef __USE_PROTOS
div_sizing(void)
#else
div_sizing()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	zzGUESS_BLOCK
	zzGUESS
	if ( !zzrv && (setwd28[LA(1)]&0x10) ) {
		{
			zzBLOCK(zztasp2);
			zzMake0;
			{
			size_err();
			zzEXIT(zztasp2);
			}
		}
		zzGUESS_DONE
		{
			zzBLOCK(zztasp2);
			zzMake0;
			{
			size_err();
			zzEXIT(zztasp2);
			}
		}
	}
	else {
		if ( zzguessing ) zzGUESS_DONE;
		if ( (setwd28[LA(1)]&0x20) ) {
		}
		else {zzFAIL(1,zzerr73,&zzMissSet,&zzMissText,&zzBadTok,&zzBadText,&zzErrk); goto fail;}
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd28, 0x40);
	}
}

void
#ifdef __USE_PROTOS
div_ending(void)
#else
div_ending()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	zzGUESS_BLOCK
	zzGUESS
	if ( !zzrv && (LA(1)==END_DIVIDE) ) {
		{
			zzBLOCK(zztasp2);
			zzMake0;
			{
			zzmatch(END_DIVIDE); zzCONSUME;
			zzEXIT(zztasp2);
			}
		}
		zzGUESS_DONE
		{
			zzBLOCK(zztasp2);
			zzMake0;
			{
			zzmatch(END_DIVIDE); zzCONSUME;
			zzEXIT(zztasp2);
			}
		}
	}
	else {
		if ( zzguessing ) zzGUESS_DONE;
		if ( (LA(1)==1) ) {
		}
		else {zzFAIL(1,zzerr74,&zzMissSet,&zzMissText,&zzBadTok,&zzBadText,&zzErrk); goto fail;}
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd28, 0x80);
	}
}

void
#ifdef __USE_PROTOS
div2_line(void)
#else
div2_line()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==INTO)
 ) {
			zzmatch(INTO); zzCONSUME;
		}
		else {
			if ( (LA(1)==BY) ) {
				zzmatch(BY); zzCONSUME;
			}
			else {zzFAIL(1,zzerr75,&zzMissSet,&zzMissText,&zzBadTok,&zzBadText,&zzErrk); goto fail;}
		}
		zzEXIT(zztasp2);
		}
	}
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==PROG_NAME) ) {
			{
				zzBLOCK(zztasp3);
				int zzcnt=1;
				zzMake0;
				{
				do {
					ident();
					{
						zzBLOCK(zztasp4);
						zzMake0;
						{
						if ( (LA(1)==ROUNDED) ) {
							zzmatch(ROUNDED); zzCONSUME;
						}
						zzEXIT(zztasp4);
						}
					}
					zzLOOP(zztasp3);
				} while ( (LA(1)==PROG_NAME) );
				zzEXIT(zztasp3);
				}
			}
		}
		else {
			if ( (LA(1)==NUMERIC)
 ) {
				numeric();
			}
			else {zzFAIL(1,zzerr76,&zzMissSet,&zzMissText,&zzBadTok,&zzBadText,&zzErrk); goto fail;}
		}
		zzEXIT(zztasp2);
		}
	}
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==GIVING) ) {
			div_giving_line();
		}
		zzEXIT(zztasp2);
		}
	}
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==REMAINDER) ) {
			remainder_clause();
		}
		zzEXIT(zztasp2);
		}
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd29, 0x1);
	}
}

void
#ifdef __USE_PROTOS
div_giving_line(void)
#else
div_giving_line()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	zzmatch(GIVING); zzCONSUME;
	{
		zzBLOCK(zztasp2);
		int zzcnt=1;
		zzMake0;
		{
		do {
			ident();
			{
				zzBLOCK(zztasp3);
				zzMake0;
				{
				if ( (LA(1)==ROUNDED) ) {
					zzmatch(ROUNDED); zzCONSUME;
				}
				zzEXIT(zztasp3);
				}
			}
			zzLOOP(zztasp2);
		} while ( (LA(1)==PROG_NAME) );
		zzEXIT(zztasp2);
		}
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd29, 0x2);
	}
}

void
#ifdef __USE_PROTOS
remainder_clause(void)
#else
remainder_clause()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	zzmatch(REMAINDER); zzCONSUME;
	ident();
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd29, 0x4);
	}
}
