/*
 * A n t l r  T r a n s l a t i o n  H e a d e r
 *
 * Terence Parr, Will Cohen, and Hank Dietz: 1989-1994
 * Purdue University Electrical Engineering
 * With AHPCRC, University of Minnesota
 * ANTLR Version 1.33MR9
 */
#include <stdio.h>
#define ANTLR_VERSION	133MR9

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "charbuf.h"
#include "c-global.h"
#define ZZCAN_GUESS
#include <setjmp.h>
#define LL_K 4
#define zzSET_SIZE 48
#include "antlr.h"
#include "tokens.h"
#include "dlgdef.h"
#include "mode.h"
#ifndef PURIFY
#define PURIFY(r,s)
#endif

void
#ifdef __USE_PROTOS
file_control_clause(void)
#else
file_control_clause()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	select_line();
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		while ( 1 ) {
			if ( !((setwd8[LA(1)]&0x80))) break;
			if ( (LA(1)==ASSIGN) ) {
				assign_line();
				zzNON_GUESS_MODE {
				CheckFlag(&file_control_flags, FC_ASSIGN, "ASSIGN");   
				}
			}
			else {
				if ( (LA(1)==PADDING)
 ) {
					padding_line();
					zzNON_GUESS_MODE {
					CheckFlag(&file_control_flags, FC_PADDING, "PADDING");   
					}
				}
				else {
					if ( (LA(1)==RECORD) && (LA(2)==DELIMITER) ) {
						record_line();
						zzNON_GUESS_MODE {
						CheckFlag(&file_control_flags, FC_RECORD_DELIM, "RECORD");   
						}
					}
					else {
						if ( (LA(1)==RESERVE) ) {
							reserve_line();
							zzNON_GUESS_MODE {
							CheckFlag(&file_control_flags, FC_RESERVE, "RESERVE");   
							}
						}
						else {
							if ( (LA(1)==ORGANIZATION) ) {
								org_line();
								zzNON_GUESS_MODE {
								CheckFlag(&file_control_flags, FC_ORGANIZATION, "ORGANIZATION");   
								}
							}
							else {
								if ( (LA(1)==ACCESS)
 ) {
									access_line();
									zzNON_GUESS_MODE {
									CheckFlag(&file_control_flags, FC_ACCESS_MODE, "ACCESS MODE");   
									}
								}
								else {
									if ( (setwd9[LA(1)]&0x1) ) {
										file_status_line();
										zzNON_GUESS_MODE {
										CheckFlag(&file_control_flags, FC_FILE_STATUS, "FILE STATUS");   
										}
									}
									else {
										if ( (LA(1)==RECORD) && (setwd9[LA(2)]&0x2) ) {
											record_key_line();
											zzNON_GUESS_MODE {
											CheckFlag(&file_control_flags, FC_RECORD_KEY, "RECORD");   
											}
										}
										else {
											if ( (LA(1)==ALTERNATE) ) {
												alt_key_line();
												zzNON_GUESS_MODE {
												CheckFlag(&file_control_flags, FC_ALT_RECORD, "ALTERNATE");   
												}
											}
											else break; /* MR6 code for exiting loop "for sure" */
										}
									}
								}
							}
						}
					}
				}
			}
			zzLOOP(zztasp2);
		}
		zzEXIT(zztasp2);
		}
	}
	zzmatch(PERIOD);
	zzNON_GUESS_MODE {
	FileControlActions();
	ResetFlag(&file_control_flags); 
	}
 zzCONSUME;

	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd9, 0x4);
	}
}

void
#ifdef __USE_PROTOS
select_line(void)
#else
select_line()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	zzmatch(SELECT); zzCONSUME;
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==OPTIONAL)
 ) {
			zzmatch(OPTIONAL); zzCONSUME;
		}
		zzEXIT(zztasp2);
		}
	}
	ident();
	zzNON_GUESS_MODE {
	strcpy(FDIdent, Ident);   
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd9, 0x8);
	}
}

void
#ifdef __USE_PROTOS
assign_line(void)
#else
assign_line()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	zzmatch(ASSIGN); zzCONSUME;
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==TO) ) {
			zzmatch(TO); zzCONSUME;
		}
		zzEXIT(zztasp2);
		}
	}
	{
		zzBLOCK(zztasp2);
		int zzcnt=1;
		zzMake0;
		{
		do {
			file_name();
			zzLOOP(zztasp2);
		} while ( (LA(1)==NONNUMERIC) );
		zzEXIT(zztasp2);
		}
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd9, 0x10);
	}
}

void
#ifdef __USE_PROTOS
reserve_line(void)
#else
reserve_line()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	zzmatch(RESERVE); zzCONSUME;
	integer();
	zzmatch(AREA);
	zzNON_GUESS_MODE {
	WarnNotImpl("RESERVE clause");   
	}
 zzCONSUME;

	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd9, 0x20);
	}
}

void
#ifdef __USE_PROTOS
org_line(void)
#else
org_line()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	zzmatch(ORGANIZATION); zzCONSUME;
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==IS) ) {
			zzmatch(IS); zzCONSUME;
		}
		zzEXIT(zztasp2);
		}
	}
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==SEQUENTIAL) ) {
			zzmatch(SEQUENTIAL); zzCONSUME;
		}
		else {
			if ( (LA(1)==INDEXED)
 ) {
				zzmatch(INDEXED); zzCONSUME;
			}
			else {zzFAIL(1,zzerr14,&zzMissSet,&zzMissText,&zzBadTok,&zzBadText,&zzErrk); goto fail;}
		}
		zzEXIT(zztasp2);
		}
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd9, 0x40);
	}
}

void
#ifdef __USE_PROTOS
padding_line(void)
#else
padding_line()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	zzmatch(PADDING); zzCONSUME;
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==CHARACTER) ) {
			zzmatch(CHARACTER); zzCONSUME;
		}
		zzEXIT(zztasp2);
		}
	}
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==IS) ) {
			zzmatch(IS); zzCONSUME;
		}
		zzEXIT(zztasp2);
		}
	}
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==PROG_NAME) ) {
			ident();
		}
		else {
			if ( (LA(1)==NONNUMERIC) ) {
				lit_char();
			}
			else {zzFAIL(1,zzerr15,&zzMissSet,&zzMissText,&zzBadTok,&zzBadText,&zzErrk); goto fail;}
		}
		zzEXIT(zztasp2);
		}
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd9, 0x80);
	}
}

void
#ifdef __USE_PROTOS
record_line(void)
#else
record_line()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	zzmatch(RECORD); zzCONSUME;
	zzmatch(DELIMITER); zzCONSUME;
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==IS)
 ) {
			zzmatch(IS); zzCONSUME;
		}
		zzEXIT(zztasp2);
		}
	}
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==STANDARD_1) ) {
			zzmatch(STANDARD_1); zzCONSUME;
		}
		else {
			if ( (LA(1)==PROG_NAME) ) {
				ident();
			}
			else {zzFAIL(1,zzerr16,&zzMissSet,&zzMissText,&zzBadTok,&zzBadText,&zzErrk); goto fail;}
		}
		zzEXIT(zztasp2);
		}
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd10, 0x1);
	}
}

void
#ifdef __USE_PROTOS
access_line(void)
#else
access_line()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	zzmatch(ACCESS); zzCONSUME;
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==MODE) ) {
			zzmatch(MODE); zzCONSUME;
		}
		zzEXIT(zztasp2);
		}
	}
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==IS) ) {
			zzmatch(IS); zzCONSUME;
		}
		zzEXIT(zztasp2);
		}
	}
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==SEQUENTIAL)
 ) {
			zzmatch(SEQUENTIAL); zzCONSUME;
		}
		else {
			if ( (LA(1)==RANDOM) ) {
				zzmatch(RANDOM); zzCONSUME;
			}
			else {
				if ( (LA(1)==DYNAMIC) ) {
					zzmatch(DYNAMIC); zzCONSUME;
				}
				else {zzFAIL(1,zzerr17,&zzMissSet,&zzMissText,&zzBadTok,&zzBadText,&zzErrk); goto fail;}
			}
		}
		zzEXIT(zztasp2);
		}
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd10, 0x2);
	}
}

void
#ifdef __USE_PROTOS
file_status_line(void)
#else
file_status_line()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==FILE_C) ) {
			zzmatch(FILE_C); zzCONSUME;
		}
		zzEXIT(zztasp2);
		}
	}
	zzmatch(STATUS); zzCONSUME;
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==IS) ) {
			zzmatch(IS); zzCONSUME;
		}
		zzEXIT(zztasp2);
		}
	}
	ident();
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd10, 0x4);
	}
}

void
#ifdef __USE_PROTOS
record_key_line(void)
#else
record_key_line()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	zzmatch(RECORD); zzCONSUME;
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==KEY)
 ) {
			zzmatch(KEY); zzCONSUME;
		}
		zzEXIT(zztasp2);
		}
	}
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==IS) ) {
			zzmatch(IS); zzCONSUME;
		}
		zzEXIT(zztasp2);
		}
	}
	ident();
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd10, 0x8);
	}
}

void
#ifdef __USE_PROTOS
alt_key_line(void)
#else
alt_key_line()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	zzmatch(ALTERNATE); zzCONSUME;
	zzmatch(RECORD); zzCONSUME;
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==KEY) ) {
			zzmatch(KEY); zzCONSUME;
		}
		zzEXIT(zztasp2);
		}
	}
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==IS) ) {
			zzmatch(IS); zzCONSUME;
		}
		zzEXIT(zztasp2);
		}
	}
	ident();
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (setwd10[LA(1)]&0x10) ) {
			{
				zzBLOCK(zztasp3);
				zzMake0;
				{
				if ( (LA(1)==WITH)
 ) {
					zzmatch(WITH); zzCONSUME;
				}
				zzEXIT(zztasp3);
				}
			}
			zzmatch(DUPLICATES); zzCONSUME;
		}
		zzEXIT(zztasp2);
		}
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd10, 0x20);
	}
}
