/*
 * A n t l r  T r a n s l a t i o n  H e a d e r
 *
 * Terence Parr, Will Cohen, and Hank Dietz: 1989-1994
 * Purdue University Electrical Engineering
 * With AHPCRC, University of Minnesota
 * ANTLR Version 1.33MR9
 */
#include <stdio.h>
#define ANTLR_VERSION	133MR9

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "charbuf.h"
#include "c-global.h"
#define ZZCAN_GUESS
#include <setjmp.h>
#define LL_K 4
#define zzSET_SIZE 48
#include "antlr.h"
#include "tokens.h"
#include "dlgdef.h"
#include "mode.h"
#ifndef PURIFY
#define PURIFY(r,s)
#endif

void
#ifdef __USE_PROTOS
pic_defn(void)
#else
pic_defn()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	zzmatch(PICTURE_DEFN);
	zzNON_GUESS_MODE {
	ParsePicture(zzlextext);
	/*
#ifdef DEBUG
	fprintf(stderr, "PICTURE_DEFN = %s\n", PictureDefn);
#endif
	*/
	}
 zzCONSUME;

	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd1, 0x2);
	}
}

void
#ifdef __USE_PROTOS
ident(void)
#else
ident()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	zzmatch(PROG_NAME);
	zzNON_GUESS_MODE {
	CheckIdentLen(zzlextext);
	strcpy(Ident, zzlextext);   
	}
 zzCONSUME;

	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd1, 0x4);
	}
}

void
#ifdef __USE_PROTOS
string_literal(void)
#else
string_literal()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	zzmatch(NONNUMERIC);
	zzNON_GUESS_MODE {
	CheckIdentLen(zzlextext);
	TerminalType = 'S';
	strcpy( StringLiteral, zzlextext);   
	}
 zzCONSUME;

	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd1, 0x8);
	}
}

void
#ifdef __USE_PROTOS
numeric(void)
#else
numeric()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	zzmatch(NUMERIC);
	zzNON_GUESS_MODE {
	strcpy(Numeric_s, zzlextext);
	TerminalType = 'N';
	Numeric = atof(zzlextext);   
	}
 zzCONSUME;

	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd1, 0x10);
	}
}

void
#ifdef __USE_PROTOS
index_name(void)
#else
index_name()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	integer();
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd1, 0x20);
	}
}

void
#ifdef __USE_PROTOS
level_number(void)
#else
level_number()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	integer();
	zzNON_GUESS_MODE {
	DDLevel = Numeric; VerifyLevelNum();   
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd1, 0x40);
	}
}

void
#ifdef __USE_PROTOS
implementor_name(void)
#else
implementor_name()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	string_literal();
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd1, 0x80);
	}
}

void
#ifdef __USE_PROTOS
lit_char(void)
#else
lit_char()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	string_literal();
	zzNON_GUESS_MODE {
	/* is 3 b/c need to account for 2 quote marks :) */
	if (strlen(StringLiteral) > 3) 
	ErrLitChar(StringLiteral);
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd2, 0x1);
	}
}

void
#ifdef __USE_PROTOS
sym_char(void)
#else
sym_char()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	lit_char();
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd2, 0x2);
	}
}

void
#ifdef __USE_PROTOS
file_name(void)
#else
file_name()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	string_literal();
	zzNON_GUESS_MODE {
	StringLiteral[strlen(StringLiteral)-1]='\0';
	VerifyFile(StringLiteral+1); 
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd2, 0x4);
	}
}

void
#ifdef __USE_PROTOS
integer(void)
#else
integer()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	numeric();
	zzNON_GUESS_MODE {
	VerifyInteger();   
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd2, 0x8);
	}
}

void
#ifdef __USE_PROTOS
cd_name(void)
#else
cd_name()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	ident();
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd2, 0x10);
	}
}
