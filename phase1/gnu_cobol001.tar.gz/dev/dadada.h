#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <ctype.h>
#include <math.h>
#include <errno.h>
#include <locale.h>
#include <limits.h>
#include <string.h>
#include <time.h>
double a = 0.000000;char ab [3+1] = "";struct __s_aasdf {struct __s_aasdf {double asdf = 0.000000;struct __s_bloopy {struct __s_b_a {} b_a;struct __s_b_c {} b_c;} bloopy;double noncontig_foof = 0.000000;double ss = 0.000000;double wanker = 0.000000;struct __s_ws_rec {} ws_rec;struct __s_asdf_rec {struct __s_asdf_rec {double fucked_a_b = 0.000000;
