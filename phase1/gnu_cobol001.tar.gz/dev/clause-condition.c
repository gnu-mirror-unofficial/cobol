/*
 * A n t l r  T r a n s l a t i o n  H e a d e r
 *
 * Terence Parr, Will Cohen, and Hank Dietz: 1989-1994
 * Purdue University Electrical Engineering
 * With AHPCRC, University of Minnesota
 * ANTLR Version 1.33MR9
 */
#include <stdio.h>
#define ANTLR_VERSION	133MR9

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "charbuf.h"
#include "c-global.h"
#define ZZCAN_GUESS
#include <setjmp.h>
#define LL_K 4
#define zzSET_SIZE 48
#include "antlr.h"
#include "tokens.h"
#include "dlgdef.h"
#include "mode.h"
#ifndef PURIFY
#define PURIFY(r,s)
#endif

void
#ifdef __USE_PROTOS
condition(void)
#else
condition()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	ExprInit();   
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==NOT) ) {
			zzmatch(NOT);
			zzNON_GUESS_MODE {
			SetFlag(&verb_flags, CONDITION_NOT);   
			}
 zzCONSUME;

		}
		zzEXIT(zztasp2);
		}
	}
	general_cond();
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (setwd17[LA(1)]&0x4) ) {
			{
				zzBLOCK(zztasp3);
				zzMake0;
				{
				if ( (LA(1)==AND)
 ) {
					zzmatch(AND);
					zzNON_GUESS_MODE {
					ExprStringAdd("&&");   
					}
 zzCONSUME;

				}
				else {
					if ( (LA(1)==OR) ) {
						zzmatch(OR);
						zzNON_GUESS_MODE {
						ExprStringAdd("||");   
						}
 zzCONSUME;

					}
					else {zzFAIL(1,zzerr36,&zzMissSet,&zzMissText,&zzBadTok,&zzBadText,&zzErrk); goto fail;}
				}
				zzEXIT(zztasp3);
				}
			}
			general_cond();
		}
		zzEXIT(zztasp2);
		}
	}
	zzNON_GUESS_MODE {
	ExprActions();
	ExprStringDelete(); 
	ResetFlag(&verb_flags);
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd17, 0x8);
	}
}

void
#ifdef __USE_PROTOS
general_cond(void)
#else
general_cond()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	arith_expr();
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (setwd17[LA(1)]&0x10) && (setwd17[LA(2)]&0x20) && (setwd17[LA(3)]&0x40) && (setwd17[LA(4)]&0x80) && !((LA(1)==IS&&
((LA(2)==NOT&&((LA(3)==NUMERIC&&(LA(4)==1||(LA(4)==ACCEPT||(LA(4)==DISPLAY||
(LA(4)==MOVE||(LA(4)==PERFORM||(LA(4)==STOP||(LA(4)==END_PERFORM||(LA(4)==NOT||
(LA(4)==AT||(LA(4)==END||(LA(4)==INVALID||(LA(4)==END_SUBTRACT||(LA(4)==END_MULTIPLY||
(LA(4)==END_DIVIDE||(LA(4)==END_COMPUTE||(LA(4)==END_ADD||(LA(4)==ON||(LA(4)==SIZE||
(LA(4)==END_IF||(LA(4)==IF_C||(LA(4)==ELSE_C||(LA(4)==PERIOD||(LA(4)==THEN||
(LA(4)==NEXT||(LA(4)==AND||(LA(4)==OR)))))))))))))))))))))))))))||((LA(3)==ALPHABETIC&&(LA(4)==1||
(LA(4)==ACCEPT||(LA(4)==DISPLAY||(LA(4)==MOVE||(LA(4)==PERFORM||(LA(4)==STOP||
(LA(4)==END_PERFORM||(LA(4)==NOT||(LA(4)==AT||(LA(4)==END||(LA(4)==INVALID||
(LA(4)==END_SUBTRACT||(LA(4)==END_MULTIPLY||(LA(4)==END_DIVIDE||(LA(4)==END_COMPUTE||(LA(4)==END_ADD||
(LA(4)==ON||(LA(4)==SIZE||(LA(4)==END_IF||(LA(4)==IF_C||(LA(4)==ELSE_C||
(LA(4)==PERIOD||(LA(4)==THEN||(LA(4)==NEXT||(LA(4)==AND||(LA(4)==OR)))))))))))))))))))))))))))||
((LA(3)==POSITIVE&&(LA(4)==1||(LA(4)==ACCEPT||(LA(4)==DISPLAY||(LA(4)==MOVE||
(LA(4)==PERFORM||(LA(4)==STOP||(LA(4)==END_PERFORM||(LA(4)==NOT||(LA(4)==AT||
(LA(4)==END||(LA(4)==INVALID||(LA(4)==END_SUBTRACT||(LA(4)==END_MULTIPLY||(LA(4)==END_DIVIDE||
(LA(4)==END_COMPUTE||(LA(4)==END_ADD||(LA(4)==ON||(LA(4)==SIZE||(LA(4)==END_IF||
(LA(4)==IF_C||(LA(4)==ELSE_C||(LA(4)==PERIOD||(LA(4)==THEN||(LA(4)==NEXT||
(LA(4)==AND||(LA(4)==OR)))))))))))))))))))))))))))||((LA(3)==NEGATIVE&&(LA(4)==1||(LA(4)==ACCEPT||
(LA(4)==DISPLAY||(LA(4)==MOVE||(LA(4)==PERFORM||(LA(4)==STOP||(LA(4)==END_PERFORM||
(LA(4)==NOT||(LA(4)==AT||(LA(4)==END||(LA(4)==INVALID||(LA(4)==END_SUBTRACT||
(LA(4)==END_MULTIPLY||(LA(4)==END_DIVIDE||(LA(4)==END_COMPUTE||(LA(4)==END_ADD||(LA(4)==ON||
(LA(4)==SIZE||(LA(4)==END_IF||(LA(4)==IF_C||(LA(4)==ELSE_C||(LA(4)==PERIOD||
(LA(4)==THEN||(LA(4)==NEXT||(LA(4)==AND||(LA(4)==OR)))))))))))))))))))))))))))||((LA(3)==ZERO&&
(LA(4)==1||(LA(4)==ACCEPT||(LA(4)==DISPLAY||(LA(4)==MOVE||(LA(4)==PERFORM||
(LA(4)==STOP||(LA(4)==END_PERFORM||(LA(4)==NOT||(LA(4)==AT||(LA(4)==END||
(LA(4)==INVALID||(LA(4)==END_SUBTRACT||(LA(4)==END_MULTIPLY||(LA(4)==END_DIVIDE||(LA(4)==END_COMPUTE||
(LA(4)==END_ADD||(LA(4)==ON||(LA(4)==SIZE||(LA(4)==END_IF||(LA(4)==IF_C||
(LA(4)==ELSE_C||(LA(4)==PERIOD||(LA(4)==THEN||(LA(4)==NEXT||(LA(4)==AND||
(LA(4)==OR)))))))))))))))))))))))))))))))))||((LA(2)==NUMERIC&&((LA(3)==1&&(LA(4)==1))||((LA(3)==ACCEPT&&
(LA(4)==PROG_NAME))||((LA(3)==DISPLAY&&(LA(4)==PROG_NAME||(LA(4)==NUMERIC||(LA(4)==NONNUMERIC))))||
((LA(3)==MOVE&&(LA(4)==CORR||(LA(4)==PROG_NAME||(LA(4)==NUMERIC||(LA(4)==NONNUMERIC)))))||
((LA(3)==PERFORM&&(LA(4)==PROG_NAME||(LA(4)==NUMERIC||(LA(4)==WITH||(LA(4)==TEST||
(LA(4)==UNTIL))))))||((LA(3)==STOP&&(LA(4)==RUN||(LA(4)==END_PERFORM||(LA(4)==END_IF||
(LA(4)==ACCEPT||(LA(4)==DISPLAY||(LA(4)==MOVE||(LA(4)==PERFORM||(LA(4)==STOP||
(LA(4)==IF_C||(LA(4)==ELSE_C||(LA(4)==PERIOD))))))))))))||((LA(3)==END_PERFORM&&(LA(4)==END_PERFORM||
(LA(4)==1||(LA(4)==NOT||(LA(4)==AT||(LA(4)==END||(LA(4)==INVALID||
(LA(4)==END_SUBTRACT||(LA(4)==END_MULTIPLY||(LA(4)==END_DIVIDE||(LA(4)==END_COMPUTE||(LA(4)==END_ADD||
(LA(4)==ON||(LA(4)==SIZE||(LA(4)==END_IF||(LA(4)==ACCEPT||(LA(4)==DISPLAY||
(LA(4)==MOVE||(LA(4)==PERFORM||(LA(4)==STOP||(LA(4)==IF_C||(LA(4)==ELSE_C||
(LA(4)==PERIOD)))))))))))))))))))))))||((LA(3)==NOT&&(LA(4)==AT||(LA(4)==END||(LA(4)==INVALID||
(LA(4)==ON||(LA(4)==SIZE))))))||((LA(3)==AT&&(LA(4)==END))||((LA(3)==END&&
(LA(4)==ACCEPT||(LA(4)==DISPLAY||(LA(4)==MOVE||(LA(4)==PERFORM||(LA(4)==STOP))))))||
((LA(3)==INVALID&&(LA(4)==KEY||(LA(4)==ACCEPT||(LA(4)==DISPLAY||(LA(4)==MOVE||
(LA(4)==PERFORM||(LA(4)==STOP)))))))||((LA(3)==END_SUBTRACT&&(LA(4)==1))||((LA(3)==END_MULTIPLY&&
(LA(4)==1))||((LA(3)==END_DIVIDE&&(LA(4)==1))||((LA(3)==END_COMPUTE&&(LA(4)==1))||
((LA(3)==END_ADD&&(LA(4)==1))||((LA(3)==ON&&(LA(4)==SIZE))||((LA(3)==SIZE&&
(LA(4)==ERROR))||((LA(3)==END_IF&&(LA(4)==END_IF||(LA(4)==ACCEPT||(LA(4)==DISPLAY||
(LA(4)==MOVE||(LA(4)==PERFORM||(LA(4)==STOP||(LA(4)==IF_C||(LA(4)==ELSE_C||
(LA(4)==PERIOD))))))))))||((LA(3)==IF_C&&(LA(4)==NOT||(LA(4)==PLUS_OP||(LA(4)==MINUS_OP||
(LA(4)==OPAREN||(LA(4)==NUMERIC||(LA(4)==PROG_NAME)))))))||((LA(3)==ELSE_C&&(LA(4)==NEXT||
(LA(4)==ACCEPT||(LA(4)==DISPLAY||(LA(4)==MOVE||(LA(4)==PERFORM||(LA(4)==STOP||
(LA(4)==IF_C))))))))||((LA(3)==PERIOD&&(LA(4)==1||(LA(4)==PROG_NAME||(LA(4)==ACCEPT||
(LA(4)==DISPLAY||(LA(4)==MOVE||(LA(4)==PERFORM||(LA(4)==STOP||(LA(4)==IF_C)))))))))||
((LA(3)==THEN&&(LA(4)==NEXT||(LA(4)==ACCEPT||(LA(4)==DISPLAY||(LA(4)==MOVE||
(LA(4)==PERFORM||(LA(4)==STOP||(LA(4)==IF_C))))))))||((LA(3)==NEXT&&(LA(4)==SENTENCE))||
((LA(3)==AND&&(LA(4)==PLUS_OP||(LA(4)==MINUS_OP||(LA(4)==OPAREN||(LA(4)==NUMERIC||
(LA(4)==PROG_NAME))))))||((LA(3)==OR&&(LA(4)==PLUS_OP||(LA(4)==MINUS_OP||(LA(4)==OPAREN||
(LA(4)==NUMERIC||(LA(4)==PROG_NAME))))))))))))))))))))))))))))))))))))||((LA(1)==NOT&&((LA(2)==NUMERIC&&((LA(3)==1&&
(LA(4)==1))||((LA(3)==ACCEPT&&(LA(4)==PROG_NAME))||((LA(3)==DISPLAY&&(LA(4)==PROG_NAME||
(LA(4)==NUMERIC||(LA(4)==NONNUMERIC))))||((LA(3)==MOVE&&(LA(4)==CORR||(LA(4)==PROG_NAME||
(LA(4)==NUMERIC||(LA(4)==NONNUMERIC)))))||((LA(3)==PERFORM&&(LA(4)==PROG_NAME||(LA(4)==NUMERIC||
(LA(4)==WITH||(LA(4)==TEST||(LA(4)==UNTIL))))))||((LA(3)==STOP&&(LA(4)==RUN||
(LA(4)==END_PERFORM||(LA(4)==END_IF||(LA(4)==ACCEPT||(LA(4)==DISPLAY||(LA(4)==MOVE||
(LA(4)==PERFORM||(LA(4)==STOP||(LA(4)==IF_C||(LA(4)==ELSE_C||(LA(4)==PERIOD))))))))))))||
((LA(3)==END_PERFORM&&(LA(4)==END_PERFORM||(LA(4)==1||(LA(4)==NOT||(LA(4)==AT||
(LA(4)==END||(LA(4)==INVALID||(LA(4)==END_SUBTRACT||(LA(4)==END_MULTIPLY||(LA(4)==END_DIVIDE||
(LA(4)==END_COMPUTE||(LA(4)==END_ADD||(LA(4)==ON||(LA(4)==SIZE||(LA(4)==END_IF||
(LA(4)==ACCEPT||(LA(4)==DISPLAY||(LA(4)==MOVE||(LA(4)==PERFORM||(LA(4)==STOP||
(LA(4)==IF_C||(LA(4)==ELSE_C||(LA(4)==PERIOD)))))))))))))))))))))))||((LA(3)==NOT&&(LA(4)==AT||
(LA(4)==END||(LA(4)==INVALID||(LA(4)==ON||(LA(4)==SIZE))))))||((LA(3)==AT&&
(LA(4)==END))||((LA(3)==END&&(LA(4)==ACCEPT||(LA(4)==DISPLAY||(LA(4)==MOVE||
(LA(4)==PERFORM||(LA(4)==STOP))))))||((LA(3)==INVALID&&(LA(4)==KEY||(LA(4)==ACCEPT||
(LA(4)==DISPLAY||(LA(4)==MOVE||(LA(4)==PERFORM||(LA(4)==STOP)))))))||((LA(3)==END_SUBTRACT&&
(LA(4)==1))||((LA(3)==END_MULTIPLY&&(LA(4)==1))||((LA(3)==END_DIVIDE&&(LA(4)==1))||
((LA(3)==END_COMPUTE&&(LA(4)==1))||((LA(3)==END_ADD&&(LA(4)==1))||((LA(3)==ON&&
(LA(4)==SIZE))||((LA(3)==SIZE&&(LA(4)==ERROR))||((LA(3)==END_IF&&(LA(4)==END_IF||
(LA(4)==ACCEPT||(LA(4)==DISPLAY||(LA(4)==MOVE||(LA(4)==PERFORM||(LA(4)==STOP||
(LA(4)==IF_C||(LA(4)==ELSE_C||(LA(4)==PERIOD))))))))))||((LA(3)==IF_C&&(LA(4)==NOT||
(LA(4)==PLUS_OP||(LA(4)==MINUS_OP||(LA(4)==OPAREN||(LA(4)==NUMERIC||(LA(4)==PROG_NAME)))))))||
((LA(3)==ELSE_C&&(LA(4)==NEXT||(LA(4)==ACCEPT||(LA(4)==DISPLAY||(LA(4)==MOVE||
(LA(4)==PERFORM||(LA(4)==STOP||(LA(4)==IF_C))))))))||((LA(3)==PERIOD&&(LA(4)==1||
(LA(4)==PROG_NAME||(LA(4)==ACCEPT||(LA(4)==DISPLAY||(LA(4)==MOVE||(LA(4)==PERFORM||
(LA(4)==STOP||(LA(4)==IF_C)))))))))||((LA(3)==THEN&&(LA(4)==NEXT||(LA(4)==ACCEPT||
(LA(4)==DISPLAY||(LA(4)==MOVE||(LA(4)==PERFORM||(LA(4)==STOP||(LA(4)==IF_C))))))))||
((LA(3)==NEXT&&(LA(4)==SENTENCE))||((LA(3)==AND&&(LA(4)==PLUS_OP||(LA(4)==MINUS_OP||
(LA(4)==OPAREN||(LA(4)==NUMERIC||(LA(4)==PROG_NAME))))))||((LA(3)==OR&&(LA(4)==PLUS_OP||
(LA(4)==MINUS_OP||(LA(4)==OPAREN||(LA(4)==NUMERIC||(LA(4)==PROG_NAME))))))))))))))))))))))))))))))))))))) ) {
			cond_arg();
		}
		else {
			if ( (setwd18[LA(1)]&0x1) && (setwd18[LA(2)]&0x2) && 
(setwd18[LA(3)]&0x4) && (setwd18[LA(4)]&0x8) ) {
				class_arg();
			}
			else {
				if ( (setwd18[LA(1)]&0x10) && (setwd18[LA(2)]&0x20) && (setwd18[LA(3)]&0x40) && (setwd18[LA(4)]&0x80) ) {
					sign_arg();
				}
				else {zzFAIL(4,zzerr37,zzerr38,zzerr39,zzerr40,&zzMissSet,&zzMissText,&zzBadTok,&zzBadText,&zzErrk); goto fail;}
			}
		}
		zzEXIT(zztasp2);
		}
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd19, 0x1);
	}
}

void
#ifdef __USE_PROTOS
cond_arg(void)
#else
cond_arg()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	relation();
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==NONNUMERIC)
 ) {
			string_literal();
			zzNON_GUESS_MODE {
			printf("Needs Sp FN: %s", StringLiteral);   
			}
		}
		else {
			if ( (setwd19[LA(1)]&0x2) ) {
				arith_expr();
			}
			else {zzFAIL(1,zzerr41,&zzMissSet,&zzMissText,&zzBadTok,&zzBadText,&zzErrk); goto fail;}
		}
		zzEXIT(zztasp2);
		}
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd19, 0x4);
	}
}

void
#ifdef __USE_PROTOS
class_arg(void)
#else
class_arg()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	VerifyIdent(Ident);   
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==IS) ) {
			zzmatch(IS); zzCONSUME;
		}
		zzEXIT(zztasp2);
		}
	}
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==NOT) ) {
			zzmatch(NOT); zzCONSUME;
		}
		zzEXIT(zztasp2);
		}
	}
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==NUMERIC) ) {
			zzmatch(NUMERIC); zzCONSUME;
		}
		else {
			if ( (LA(1)==ALPHABETIC)
 ) {
				zzmatch(ALPHABETIC); zzCONSUME;
			}
			else {zzFAIL(1,zzerr42,&zzMissSet,&zzMissText,&zzBadTok,&zzBadText,&zzErrk); goto fail;}
		}
		zzEXIT(zztasp2);
		}
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd19, 0x8);
	}
}

void
#ifdef __USE_PROTOS
sign_arg(void)
#else
sign_arg()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==IS) ) {
			zzmatch(IS); zzCONSUME;
		}
		zzEXIT(zztasp2);
		}
	}
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==NOT) ) {
			zzmatch(NOT); zzCONSUME;
		}
		zzEXIT(zztasp2);
		}
	}
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==POSITIVE) ) {
			zzmatch(POSITIVE); zzCONSUME;
		}
		else {
			if ( (LA(1)==NEGATIVE) ) {
				zzmatch(NEGATIVE); zzCONSUME;
			}
			else {
				if ( (LA(1)==ZERO)
 ) {
					zzmatch(ZERO); zzCONSUME;
				}
				else {zzFAIL(1,zzerr43,&zzMissSet,&zzMissText,&zzBadTok,&zzBadText,&zzErrk); goto fail;}
			}
		}
		zzEXIT(zztasp2);
		}
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd19, 0x10);
	}
}
