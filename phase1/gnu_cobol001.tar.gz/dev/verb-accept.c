/*
 * A n t l r  T r a n s l a t i o n  H e a d e r
 *
 * Terence Parr, Will Cohen, and Hank Dietz: 1989-1994
 * Purdue University Electrical Engineering
 * With AHPCRC, University of Minnesota
 * ANTLR Version 1.33MR9
 */
#include <stdio.h>
#define ANTLR_VERSION	133MR9

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "charbuf.h"
#include "c-global.h"
#define ZZCAN_GUESS
#include <setjmp.h>
#define LL_K 4
#define zzSET_SIZE 48
#include "antlr.h"
#include "tokens.h"
#include "dlgdef.h"
#include "mode.h"
#ifndef PURIFY
#define PURIFY(r,s)
#endif

void
#ifdef __USE_PROTOS
accept_stmt(void)
#else
accept_stmt()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	zzmatch(ACCEPT); zzCONSUME;
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==PROG_NAME) && 
(setwd25[LA(2)]&0x8) && (setwd25[LA(3)]&0x10) ) {
			ident();
			zzNON_GUESS_MODE {
			printf("accept %s\n", Ident);
			{ int rv = emit_accept(Ident); 
				if (rv != 0) ErrUndefVar(Ident);
			}
			}
			{
				zzBLOCK(zztasp3);
				zzMake0;
				{
				if ( (LA(1)==FROM) ) {
					zzmatch(FROM); zzCONSUME;
					ident();
				}
				zzEXIT(zztasp3);
				}
			}
		}
		else {
			if ( (LA(1)==PROG_NAME) && (setwd25[LA(2)]&0x20) && 
(setwd25[LA(3)]&0x40) ) {
				ident();
				zzmatch(FROM); zzCONSUME;
				{
					zzBLOCK(zztasp3);
					zzMake0;
					{
					if ( (LA(1)==DAY_OF_WEEK) ) {
						zzmatch(DAY_OF_WEEK);
						zzNON_GUESS_MODE {
						emit_accept_dow(Ident);   
						}
 zzCONSUME;

					}
					else {
						if ( (LA(1)==DATE) ) {
							zzmatch(DATE);
							zzNON_GUESS_MODE {
							emit_accept_date(Ident);   
							}
 zzCONSUME;

						}
						else {
							if ( (LA(1)==DAY) ) {
								zzmatch(DAY);
								zzNON_GUESS_MODE {
								emit_accept_day(Ident);   
								}
 zzCONSUME;

							}
							else {
								if ( (LA(1)==TIME)
 ) {
									zzmatch(TIME);
									zzNON_GUESS_MODE {
									emit_accept_time(Ident);   
									}
 zzCONSUME;

								}
								else {zzFAIL(1,zzerr60,&zzMissSet,&zzMissText,&zzBadTok,&zzBadText,&zzErrk); goto fail;}
							}
						}
					}
					zzEXIT(zztasp3);
					}
				}
			}
			else {zzFAIL(3,zzerr61,zzerr62,zzerr63,&zzMissSet,&zzMissText,&zzBadTok,&zzBadText,&zzErrk); goto fail;}
		}
		zzEXIT(zztasp2);
		}
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd25, 0x80);
	}
}
