/*
 * Basic Stack - 
 *  A stack data structure for int's
 *  Implementation of the stack
 *
 *  Chad Slaughter
 * 11-27-97
 */

#include <string.h>
#include <stdlib.h>
#include <stdio.h>

#define STACK_DEF
#include "stack.h"


int StackInit() {
	globalStack.top = 0;
	return 0;
}

int StackPeek(char *out_string, int* out_int){
	
	int index = globalStack.top - 1;

	if ( globalStack.top == 0 ) {
		return 9;
	}
	else {
		(*out_int) = globalStack.storage[index].level;
		 (void)strncpy( out_string, 
			  globalStack.storage[index].name,
			  strlen(globalStack.storage[index].name )+1 );
		return 0;
	}
}

int StackPop(char *out_string, int* out_int){
	
	if ( globalStack.top == 0 ) {
		return 9;
	}
	else {
		globalStack.top--;
		*out_int = globalStack.storage[globalStack.top].level;
		(void)strncpy(	 out_string, 
				 globalStack.storage[globalStack.top].name,
				 strlen(globalStack.storage[globalStack.top].name )+1 );
		return 0;
	}
}


int StackPush(char* in_string, int in_int){


	int index ;
	int length ;

	if ( globalStack.top == MAXSTACKSIZE ) {
		(void)fprintf(stderr,
				"Internal Compiler Error: "
				"Max Stack Size exceeded!!!!\n"
				);
		return 11;
	}
	index = globalStack.top;
	length = strlen(in_string);
	if ( length > MAXSTACKNAMESIZE )
		length = MAXSTACKNAMESIZE;

#if 0
	fprintf( stderr, "STACK::: %d, %s, len %d\n"
		,in_int, in_string, length );
#endif

	globalStack.storage[index].level = in_int;
	(void)strncpy(	globalStack.storage[index].name,
			in_string,
			length); 
	globalStack.storage[index].name[length] = '\0';
#if 0
	fprintf( stderr, "STACK::: %s\n", globalStack.storage[index].name);
#endif

	globalStack.top++;
	return 0;

}

int StackIsEmpty() {

	return (globalStack.top == 0 );
}
