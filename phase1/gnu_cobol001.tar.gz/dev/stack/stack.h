#ifndef INCLUDED_STACK_H
#define INCLUDED_STACK_H
/*
 * Basic Stack - 
 *  A stack data structure for int's
 *
 *  Chad Slaughter
 *  11-28-97
 */


#define MAXSTACKSIZE 55
#define MAXSTACKNAMESIZE 40

typedef struct s_Stack Stack;
typedef struct s_StackElement StackElement;

struct s_StackElement {
	int level;
	char name[MAXSTACKSIZE+1];
};

struct s_Stack {
	int top;
	StackElement storage[MAXSTACKSIZE];
};

#ifdef STACK_DEF
Stack globalStack;
#else
extern Stack globalStack;
#endif

int StackInit(void);

int StackPop(char *, int*);

int StackPush(char*, int);

int StackPeek(char *, int*);

int StackIsEmpty();


#endif
