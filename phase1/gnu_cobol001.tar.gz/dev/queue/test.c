/*
 * Test file for queue.
 * Chad Slaughter
 * 10-5-97
 */

#include <stdio.h>

#include "queue.h"

int main(void) {

	Queue *bob = NULL;
	QueueEntry *taylor = NULL;
	QueueEntry *jon= NULL;
	int rc;


/* init */
	printf("---Init\n");
	QueueNew(&bob);
	QueueEntryNew(&taylor);

/* assign init value */
	taylor->name = "asdf";

/* add */
	printf("---Add\n");
	rc = QueueEnqueue(bob, taylor);
	taylor = NULL;

	if ( rc != 0 )
		printf("Error with Enqueue rc: %d\n", rc );

	printf("Size: %d\n", QueueSize(bob) );
	printf("Is Empty: %d\n", QueueIsEmpty(bob) );

/* peek */
	printf("---Peek\n");
	taylor = QueuePeek(bob);
	if ( taylor == NULL )
		printf("Error with Peek \n" );

	printf( "String: %s  \n"
		"Size: %d    \n"
		"IsEmpty: %d \n"
		, taylor->name 
		, QueueSize(bob)
		, QueueIsEmpty(bob) 
	);

/* delete */
	printf("---Delete\n");
	jon = QueueDequeue(bob);
	if ( jon == NULL )
		printf("Error with delete \n" );

	printf(	"String: %s \n"
		"Size: %d   \n"
		"IsEmpty: %d\n"
		, jon->name 
		, QueueIsEmpty(bob) 
		, QueueSize(bob) 
	);
/* clean up */
	printf("---Cleanup\n");
	QueueEntryDelete(jon);
	QueueDelete(bob);
	

	return 0;

}
