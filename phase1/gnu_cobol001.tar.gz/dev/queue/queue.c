/*
 * Queue Data Structure
 *   Basic Queue. Duh!
 *  Implimentation file.  =)
 *  Chad Slaughter   12-04-97
 *
 */
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>


#include "list_util.h"

#include "queue.h"

struct s_Queue {

	List storage;
};

/*
 * Create & Delete a New  QueueEntry
 */
/*
 * QueueEntryNew - 
 *  Alloc memory for a new QueueEntry struct 
 *  and initalize ptrs, and values to defaults.
 */
int QueueEntryNew ( QueueEntry** newqe){

     /* Never Pass in a non-null pointer */
        assert( (*newqe) == NULL );

	(*newqe) = (QueueEntry*) malloc( sizeof(QueueEntry) );

	if ( (*newqe) == NULL ) {
                fprintf(stderr,"Failed Malloc: QueueEntryNew");
		return 9;
	}

	(*newqe)->name = NULL;  /* init name to NULL*/
#if 0
	(*newqe)-> = NULL;  /* future initialization*/
#endif 
	
	return 0;

}

/*
 * QueueEntryDelete -
 *   free memory used by a QueueEntry struct.
 *   including all ptrs
 */
int QueueEntryDelete(QueueEntry* oldqe) {

       /* Never Free a Null ptr */
        assert( oldqe != NULL );

	if ( oldqe->name != NULL )
		free( oldqe->name  ); /* free string */
#if 0

	if ( oldqe-> != NULL )
		free( oldqe->  ); /* free sustruct */
#endif

	free(oldqe);
	return 0;
}

/*
 *Initalize and Cleanup queue
 */
/* 
 * QueueNew
 *    Alloc memory for a new queue struct
 */
int QueueNew(Queue** newq) {

     /* Never Pass in a non-null pointer */
        assert( (*newq) == NULL );

	(*newq) = (Queue*) malloc( sizeof(Queue) );
	if ( (*newq) == NULL ) {
                fprintf(stderr,"Failed Malloc: QueueNew");
		return 9;
	}

	(*newq)->storage = NULL;

	return 0;

}

/*
 * QueueDelete - Clear any elements left in the queue
 *   and free memory
 */
int QueueDelete(Queue* oldq) {
	
	QueueEntry * tmpqe;
       /* Never Free a Null ptr */
        assert( oldq != NULL );
 
        /* Delete Elements from the queue */
	if ( QueueIsEmpty(oldq) != 0 ) { /* if not empty */

		tmpqe = QueueDequeue(oldq);
		while ( tmpqe != NULL ) {
			QueueEntryDelete(tmpqe);
			tmpqe = QueueDequeue(oldq);
		}
        }
        
        /* Free main struct */
        free(oldq);
 
        return 0;

}


/*
 * remove item from queue
 */
QueueEntry* QueueDequeue(Queue* q) {

	assert( q != NULL );
#if 0
	fprintf(stderr,"QUEUE: dnq - fucked\n");
#endif

	return (QueueEntry*) listDelete( &(q->storage), 1 );
}
/*
 * peek at next item in queu 
 */
QueueEntry* QueuePeek(Queue* q ) {

	return (QueueEntry*) listGet(q->storage, 1) ;

}
/*
 * Push item into queue
 */
int QueueEnqueue(Queue* q,QueueEntry* qe){

	assert( q != NULL );
	
	return listAdd( &(q->storage), -1, (void*)qe );

}
/*
 * returns 0 if NOT empty
 *         1 if is empty
 */
int QueueIsEmpty(Queue *q) {

	return ( listLength(q->storage) == 0 );
}

/*
 * return the number of elements in a queue
 */
int QueueSize(Queue *q) {

	return listLength(q->storage) ;
}
