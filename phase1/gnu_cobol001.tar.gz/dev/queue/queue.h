#ifndef INCLUDED_QUEUE_H
#define INCLUDED_QUEUE_H
/*
 * Queue Data Structure
 *   Basic Queue. Duh!
 *  Chad Slaughter   12-04-97
 *
 */

typedef struct s_QueueEntry QueueEntry;
typedef struct s_Queue Queue;


struct s_QueueEntry {
	char *name;
};

/* forward declaration of a queue */
struct s_Queue;

/*
 * Create a New  QueueEntry
 * Delete a QueueEntry
 *  
 */
int QueueEntryNew( QueueEntry** );
int QueueEntryDelete( QueueEntry*);


/*
 * Create a New Queue     
 * Delete a Queue     
 * (Initalize and Cleanup queue )
 */
int QueueNew(Queue**);
int QueueDelete(Queue*);

/*
 * remove & return item from queue
 */
QueueEntry* QueueDequeue(Queue* );

/* return next item in queue */
QueueEntry* QueuePeek(Queue* );

/*
 * Push item into queue
 */
int QueueEnqueue(Queue*, QueueEntry*); 

/*
 * Check to see if queue is empty
 */
int QueueIsEmpty( Queue* );

/*
 * Return the number of elements in the queue
 */
int QueueSize( Queue* );
 
#endif /* INCLUDED_QUEUE_H */
