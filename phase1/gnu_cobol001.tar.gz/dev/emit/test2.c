

#include <stdio.h>

#include "emit.h"

#include "emit_impl.h"


int main(int argc, char** argv) {

	/*char * testString = "cobolrun";
 	*/
	char * str1 = "accept_time";
	char * str2 = "accept_dow";
	char * str3 = "accept_date";
	char * str4 = "accept_day";
	char * str5 = "dow_string";
	char * str6 = "time_string";
	char * str7 = "date_string";
	char * str8 = "day_string";
	char * str9 = "accept_string";
	char * str10= "accept_string2";
	char * numb1= "number1";

	int rc = EmitInit(argv[1] ) ;
	printf("%d\n", rc );
	if ( rc != 0) {
		printf("error!\n");
		return 9;
	}
/* dump variables to header file */

	emit_variable_number( str1, 0 );
	emit_variable_number( str2, 0 );
	emit_variable_number( str3, 0 );
	emit_variable_number( str4, 0 );
	emit_variable_string( str5, "", 10 );
	emit_variable_string( str6, "", 8 );
	emit_variable_string( str7, "", 6 );
	emit_variable_string( str8, "", 10 );
	emit_variable_string( str9, "", 10 );
	emit_variable_string( str10, "", 10 );
	emit_variable_number( numb1, 0 );
#if 0
	fprintf(gEmitEnv.header,
		"int %s,%s,%s,%s;"
		"char %s[11];"
		"char %s[9];"
		"char %s[7];"
		"char %s[11];"
		" "
		"char %s[11];"
		"char %s[11];"
		"double %s;  "
		,str1,str2,str3,str4
		,str5,str6,str7,str8
		,str9 ,str10
		,numb1
		);
#endif

/* Main emit code to test */
	rc =  emit_accept_time_number( str1 );
	rc =  emit_accept_dow_number( str2 );
	rc =  emit_accept_date_number( str3 );
	rc =  emit_accept_day_number( str4 );
	rc = emit_accept_dow_string( str5, 10 );
	rc = emit_accept_time_string( str6, 8 );
	rc = emit_accept_date_string(str7, 6 );
	rc = emit_accept_day_string(str8, 10 );
	rc = emit_accept_string( str9 , 10) ;
	rc = emit_accept_string( str10 , 10) ;
	rc = emit_accept_number( numb1, 5 , 2);
	rc = emit_display_literal("this is a literal display");
	rc = emit_display_advance(0);

/* printf("time of day %d\n", accept_time); */
	fprintf(gEmitEnv.source,
		" printf( \" time of day: %%f \\n\" , %s ) ;        "
		" printf( \"dow: %%f \\n\" , %s ) ; "
		" printf( \"date: %%f \\n\" , %s ) ; "
		" printf( \"day: %%f \\n\" , %s ) ; "
		" printf( \"dow_s: %%s \\n\" , %s ) ; "
		" printf( \"time_s: %%s \\n\" , %s ) ;        "
		" printf( \"date_s: %%s \\n\" , %s ) ; "
		" printf( \"day_s: %%s \\n\" , %s ) ; "
		" printf( \"accpet_s: %%s \\n\" , %s ) ; "
		" printf( \"accpet_s: %%s \\n\" , %s ) ; "
		" printf( \"numb1: %%f \\n\" , %s ) ; "
		,str1 ,str2,str3,str4 , str5, str6
		,str7,str8 ,str9 ,str10
		,numb1
	);

	
	emit_stop_run( );
	/* end of main */
	emitCleanUp();
	return 0;
}

