/*
 *
 *  Main source file emit function support code. 
 *
 *  Chad Slaughter 
 *   11-29-97
 *
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <assert.h>

#include "emit.h"
#include "emit_impl.h"

int emit_accept_dow_number(char * string ) {

        int rc;
 
        rc=fprintf(gEmitEnv.source,
		"{"
		"struct tm* tmp_tm_struct;"
                "time_t tmp_time_t ; /* get current time */"
                "tmp_time_t = time(0); /* get current time */"
                "tmp_tm_struct = localtime(&tmp_time_t);"
                "if ( tmp_tm_struct->tm_wday == 0)    "
		"	{%s = 7;} /* handle sunday */"
                "else { %s = tmp_tm_struct->tm_wday; }"
		"}"
                , string, string
        );
 
        if ( rc < 0 )
                return rc;
 
        return 0;
 
}

int emit_accept_dow_string(char * string, int length ) {
	
	int rc;

	if ( !(length >= 1 ) ) {
		fprintf(stderr, "Identifier(%s): can't hold value from accept\n"
			,string);
		return 1;
	}
        rc=fprintf(gEmitEnv.source,
		"{"
		"struct tm* tmp_tm_struct;"
                "time_t tmp_time_t ;"
                "tmp_time_t = time(0);              /* get current time */"
                "tmp_tm_struct = localtime(&tmp_time_t);                  "
                "if (tmp_tm_struct->tm_wday == 0) {    /*handle sunday*/  "
		"    sprintf( %s,\"7\"); %s[1]=\'\\0\';                   "
		"}else{                                                   "
		"    sprintf( %s,\"%%d\",tmp_tm_struct->tm_wday);         "
		"%s[1]=\'\\0\';}                                          "
		"}"
                , string, string
                , string, string
        );
 
        if ( rc < 0 )
                return rc;
 

	return 0;
}

int emit_accept_time_number( char* string ){

	int rc;
	rc=fprintf(gEmitEnv.source,
		"{"
		"struct tm* tmp_tm_struct;"
                "time_t tmp_time_t ;"
		"tmp_time_t = time(0); /* get current time */"
		"tmp_tm_struct = localtime(&tmp_time_t);"
		"%s = 0;"
		"%s += tmp_tm_struct->tm_sec*100; "
		"%s += tmp_tm_struct->tm_min*10000;"
		"%s += tmp_tm_struct->tm_hour*1000000;"
		"}"
		, string, string
		, string, string
	);

	
	if ( rc < 0 )
		return rc;
	
	return 0;

}
int emit_accept_time_string( char* string , int length){
	int rc;

	if ( !(length >= 8 ) ) {
		fprintf(stderr, "Identifier(%s): can't hold value from accept\n"
			,string);
		return 1;
	}
	rc=fprintf(gEmitEnv.source,
		"{"
		"struct tm* tmp_tm_struct;"
                "time_t tmp_time_t ;"
		"int tmp_int ; "
		"tmp_time_t = time(0); /* get current time */"
		"tmp_tm_struct = localtime(&tmp_time_t);"
		"tmp_int = 0;"
		"tmp_int += tmp_tm_struct->tm_sec*100; "
		"tmp_int += tmp_tm_struct->tm_min*10000;"
		"tmp_int += tmp_tm_struct->tm_hour*1000000;"
		"sprintf( %s,\"%%d\", tmp_int); %s[8]=\'\\0\'; "
		"}"
		, string, string
	);

	
	if ( rc < 0 )
		return rc;
	
	return 0;

}

int emit_accept_date_number( char* string ){

	int rc;
	rc=fprintf(gEmitEnv.source,
		"{"
		"struct tm* tmp_tm_struct;"
                "time_t tmp_time_t ;"
		"tmp_time_t = time(0); /* get current time */"
		"tmp_tm_struct = localtime(&tmp_time_t);"
		"%s = tmp_tm_struct->tm_mday; "
		"%s += (tmp_tm_struct->tm_mon+1)*100;"
		"%s += tmp_tm_struct->tm_year*10000;"
		"}"
		, string, string
		, string
	);

	if ( rc < 0 )
		return rc;
	
	return 0;
	
}
int emit_accept_date_string( char* string, int length ){

#define ASSIGN_DATE_STRING_LENGTH 6


	int rc;
	if ( !(length >= ASSIGN_DATE_STRING_LENGTH ) ) {
		fprintf(stderr, "Identifier(%s): can't hold value from accept\n"
			,string);
		return 1;
	}
	rc=fprintf(gEmitEnv.source,
		"{"
		"struct tm* tmp_tm_struct;"
                "time_t tmp_time_t ;"
		"int tmp_int ; "
		"tmp_time_t = time(0); /* get current time */"
		"tmp_tm_struct = localtime(&tmp_time_t);"
		"tmp_int = tmp_tm_struct->tm_mday; "
		"tmp_int += (tmp_tm_struct->tm_mon+1)*100;"
		"tmp_int += tmp_tm_struct->tm_year*10000;"
		"sprintf( %s,\"%%d\", tmp_int); %s[%d]=\'\\0\'; "
		"}"
		, string, string 
		,ASSIGN_DATE_STRING_LENGTH
	);

	if ( rc < 0 )
		return rc;
	
	return 0;
	
}
int emit_accept_day_number( char* string ){

	int rc;
	rc=fprintf(gEmitEnv.source,
		"{"
		"struct tm* tmp_tm_struct;"
                "time_t tmp_time_t ;"
		"tmp_time_t = time(0); /* get current time */"
		"tmp_tm_struct = localtime(&tmp_time_t);"
		"%s = tmp_tm_struct->tm_yday; "
		"%s += tmp_tm_struct->tm_year*1000;"
		"}"
		, string, string
	);
	if ( rc < 0 )
		return rc;
	
	return 0;
	
}

int emit_accept_day_string( char* string , int length){

	int rc;
#define ASSIGN_DAY_STRING_LENGTH 5


	if ( !(length >=  ASSIGN_DAY_STRING_LENGTH ) ) {
		fprintf(stderr, "Identifier(%s): can't hold value from accept\n"
			,string);
		return 1;
	}
	rc=fprintf(gEmitEnv.source,
		"{"
		"struct tm* tmp_tm_struct;"
                "time_t tmp_time_t ;"
		"int tmp_int ; "
		"tmp_time_t = time(0); /* get current time */"
		"tmp_tm_struct = localtime(&tmp_time_t);"
		"tmp_int = tmp_tm_struct->tm_yday; "
		"tmp_int += tmp_tm_struct->tm_year*1000;"
		"sprintf( %s,\"%%d\", tmp_int);" 
		"%s[%d]=\'\\0\'; "
		"}"
		, string, string
		, ASSIGN_DAY_STRING_LENGTH 
	);
	if ( rc < 0 )
		return rc;
	
	return 0;
	
}

int emit_accept_number( char * string, int length, int decimal ) {

	int rc;
	
	rc=fprintf(gEmitEnv.source,
		"/*"
		" * Number: Reads in numbers numbers as chars and "
		" * converts them to a double."
		" *         Vaild numbers are integers, floating points"
		" */"
		"{"
		"	double tokenval = 0;     /* readin value */"
		"	int minusflag = 1;"
/*
 * int vaild -
 * to handle the case where the first char is '-' but no
 * numbers or decimals follow 
 */				
		"	int vaild = 0;				"
		"	int t;                  /* read in char */	"
		"	t = getchar();					"
		"	if ( t == \'-\' ) {"
		"		minusflag = -1;"
		"		t = getchar();"
		"	}"
		"	if ( isdigit(t) ) {                 "
		" /* Read in integer part of number. */"
		"		vaild=1;"
		"		tokenval = t -\'0\';"
		"		t = getchar();"
		"		while ( isdigit(t) ){"
		"			tokenval = tokenval * 10 + t - \'0\';"
		"			t = getchar();"
		"		}"
		"	}"
		"	if ( t == \'.\'  ) {                              " 
		" /*If decimal point read in fractional part */"
		"		int i = 1;"
		"		vaild=1;"
		"		t = getchar();"
		"		while ( isdigit(t) ) {"
		"			tokenval += (t-\'0\')/ pow( 10, i );"
		"			i++;"
		"			t = getchar();"
		"		}"
		"	}"
		"	while ( t != \'\\n\' )                         "
		" /* next char not a digit del to newline */"
		"		t = getchar();				"
		"/*handle case of invaild input */			"
				/* %s - string variable name */
		"	if ( vaild == 0 ){ %s = 0;}			"
		"	/* Return value of read in digits */     	"
				/* %s - string variable name */
		"	else{ %s = minusflag * tokenval;}		"
		"}"
		,string
		,string
/*
	Obsoleted - by emit_truncate_number
		"tmpval=(int)tokenval%%(int)pow(10,%d-%d) ;        "
		"tmpval+=((int)((tokenval-(int)tokenval)           "
		"*pow(10,%d)))/pow(10,%d);                         "
		" %s = tmpval; }                                   "
		
		,length, decimal
		,decimal,decimal
		,string
*/
	);
	if ( rc < 0 )
		return rc;

	rc = emit_truncate_number(string,length,decimal);
        return 0;
}
int emit_accept_string( char * string , int length) {


	int rc;
	rc=fprintf(gEmitEnv.source,
		"{ int i; int tmp_int;          "
		"/* null terminate string */	"
		"%s[%d] = \'\\0\';		"
		"for( i = 0; i <%d;i++ ) {	"
		"   tmp_int = getchar();	"
		"   if ( tmp_int == \'\\n\' ) {	"
		"	%s[i] = \'\\0\';	"
		"	break;			"
		"   }				"
		"   %s[i]=tmp_int;              "
		"}				"
		"while( tmp_int != \'\\n\' )	"
		"	tmp_int = getchar();}	"
		,string,length,length
		,string,string
	);

	if ( rc < 0 )
		return rc;
        return 0;

}

int emit_support_dash2under( char * string )  {


	int dash = '-';
	char *cptr = NULL;
	
	cptr = strchr(string, dash);
	while ( cptr != NULL ) {
		(*cptr) = '_';
		cptr = strchr(cptr, dash);
	}
		
	return 0;
}

int emit_variable_string( char * in_string, char* init, int length ) {

	int rc;
	rc = fprintf(gEmitEnv.header,
			"char %s [%d+1] = \"%s\";"
			,in_string, length
			,init
	      );

	if ( rc < 0 )
		return 1;
	
	return 0;
}
int emit_variable_number( char * in_string, double init ){

	int rc;
	/* handle Number Type */
	rc = fprintf(gEmitEnv.header,
			"double %s = %f;"
			,in_string,init
	     );


	if ( rc < 0 )
		return 1;

	return 0;
}

int emit_start_C_block( void ){

	int rc;
	rc = fprintf(gEmitEnv.source,
			"{"
	     );

	if ( rc < 0 )
		return 1;

	return 0;
}

int emit_end_C_block( void ){

	int rc;
	rc = fprintf(gEmitEnv.source,
			"}"
	     );

	if ( rc < 0 )
		return 1;

	return 0;
}
 
int emit_truncate_number(char *string,int length,int decimal) {

	int rc;
	double pow1,pow2;

	pow1 = pow(10,length-decimal);
	pow2 = pow(10,decimal );

#if 0 
	fprintf(stderr,"EMIT::: %s, len: %d,dec: %d \n",string,length,decimal);
#endif
	rc = fprintf(gEmitEnv.source,
			"{"
			"double tmpval,frac,whole;"
			""
			"/* split number into integral and fraction */"
/* %s - number to trunc */
			"frac = modf( %s ,&whole);" 
			""
			"/* take the modulos of the integral part by	"
                        " * 10^number of digits				"
			" * to the left of the decimal 			"
			" */"
/* %d, %d - pow(10,length-decimal) */
			"tmpval = whole - (floor(whole/%f)*%f);"
/* %d - pow(10,decimal ) */
			"frac = modf( (frac * %f ), &whole);"
/* %d - pow(10,decimal ) */
			"tmpval+=whole/%f;"
			"%s=tmpval;"
			"}"
			,string
			,pow1 ,pow1
			,pow2
			,pow2
			,string
#if 0
"{"
"int length = %d;"
"int decimal = %d;"
""
/*
"double a = %s;"
*/
"double tmpval,tmpval2,frac,whole;"
""
"/* split number into integral and fraction */"
"	frac = modf(%s,&whole);"
""
"/* take the modulos of the integral part by 10^number of digits"
" * to the left of the decimal"
" */"
"	tmpval2 = %f; " /* pow(10,length-decimal) ;" */
"	tmpval = whole-( floor(whole/%f)*%f );"
"	frac = modf( (frac*%f), &whole);"
"	tmpval+=whole/%f;"
"	%s = tmpval;"
"}"
,length,decimal, string
,pow1
,pow1 ,pow1
,pow2
,pow2
,string
#endif
	     );


	if ( rc < 0 )
		return 1;

	return 0;
}

/* 
 * Support routine for 
 * function to hold temp value if need to emit close bracket on
 * a loop 
 */
/*
 *  Possible Parameters - 
 *  
 *   0 - called form perform_end to close loop
 *   1 - called from perform_loop_end to 
 *        handle post-test loop
 *   2 - called from perform_iterative 
 *   3 - called from perform_before 
 *   4 - called from perform_after
 *
 */
int emit_perform_support_loop( int inFlag ){

	/* equal to zero means NOT to emit loop */
	static int emitLoopEnd = 0;
	/* handle the fucked up post test loop emission */
	static int emitAfterInfo = 0;

	int rc;

	if( inFlag == 2 || inFlag == 3) { /* called in loop */
		emitLoopEnd = 1; /* yes emit it */
		return 0;
	}
	else if ( inFlag == 4 ) {
		emitLoopEnd = 1;
		emitAfterInfo = 1;
		return 0;
	}
	else if ( inFlag == 0 ) {
		rc = emitLoopEnd;
		emitLoopEnd =0;
		return rc;
	}
	else if ( inFlag == 1) {
		rc = emitAfterInfo;
		emitAfterInfo = 0;
		return rc;
	}
	else {
		assert(0); /*fucked the monkey */
	}

	assert(0); /* NEVER get here, somethign fucked up */

}
