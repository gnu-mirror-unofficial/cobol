
#include <stdio.h>


#include "emit.h"

#include "emit_impl.h"


int main(int argc, char** argv) {

	char * numb1= "number1";

	int rc = EmitInit(argv[1] ) ;
	printf("%d\n", rc );
	if ( rc != 0) {
		printf("error!\n");
		return 9;
	}

/* dump variables to header file */
	fprintf(gEmitEnv.header,
		"double %s;  "
		,numb1
		);
/* Run emit code test */
	/* length 5, decimal 2 */
	rc = emit_accept_number( numb1, 5 , 2);

/* emit test code to make sure emit code run properly */
	fprintf(gEmitEnv.source,
		" printf( \"numb1: %%f \\n\" , %s ) ; "
		,numb1
	);
/* End program */
	emit_stop_run( );
	/* end of main */
	emitCleanUp();
	return 0;
}

