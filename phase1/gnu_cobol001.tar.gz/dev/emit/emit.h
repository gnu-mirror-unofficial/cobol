#ifndef INCLUDED_EMIT_H
#define INCLUDED_EMIT_H
/*
 *
 *  Header file for all emit functions and related code
 *
 *  Chad Slaughter 
 *  11/15/97
 *
 *  declarations and function prototypes are here
 */

/*
 * emit Global struct
 */
#include <stdio.h>

struct s_emitEnv{

	FILE* header;
	FILE* source;

};

typedef struct s_emitEnv  emitEnv;

#ifdef EMIT_GLOBAL_DEF
emitEnv gEmitEnv;
#else
extern emitEnv gEmitEnv;
#endif



/* function prototypes */
/* init and cleanup  for emit functions*/
int EmitInit(char* string);
void emitCleanUp(void) ;

/* accept verb */
int emit_accept( char*  );
int emit_accept_dow( char* );
int emit_accept_time( char* );
int emit_accept_date( char* );
int emit_accept_day( char* );

/* display verb */
int emit_display_ident( char* );
int emit_display_literal( char* );
int emit_display_advance( int ); 

/* stop verb */
int emit_stop_run( void );

/* variable declarations */
int emit_variable( char * );
int emit_var_struct_begin( char * );
int emit_var_struct_end( char * );


/* if, else verb */
int emit_if_start( void );
int emit_if_block( void );
int emit_if_next_sentence( void );
int emit_if_end( void );

int emit_else_start( void );
int emit_else_next_sentence( void );
int emit_else_end( void );

/* conditional clause */


/* move verb */

int emit_move_literalToNumber(char *, char *); /* src, dest */
int emit_move_literalToString(char*, char *, int );/* src, dest,lengthdest */
int emit_move_NumberToString(char*, char *, int);/* src, dest,lengthdest */
int emit_move_StringToString(char*, char*,int );/* src, dest,lengthdest */
int emit_move_NumberToNumber(char*, char* );/* src, dest */


/* copy verb */
int emit_copy( char * );

/* perform verb */

int emit_perform_start( void );

/*
 * End of perform statement -
 * Function accepts a Paragraphname or NULL 
 *
 * emit one or two closing brackets and a optional function call 
 *
 */
int emit_perform_end( char * );	
/*
 * Perform iterative loop
 *
 * name - literal or identifier 
 * flag      1          0
 */
int emit_perform_times(char* , int);

int emit_perform_loop_before( void );
int emit_perform_loop_after( void );
/* end loop condition emittion */
int emit_perform_loop_end( void );
/*
 *
 *   { <begin_perform>
 * <after>    int __do_while =1; while( __do_while || <cond>   i
 *         ){ <end_cond>        <statement>
 * <before>  while(  <cond>  ){<end_cond>   <statement>
 *     }<close_loop>
 *   }<close_perform>
 */

/*
 * Paragraphs
 */

int emit_paragraph_main_start( void ); /* handle first paragraph */
int emit_paragraph_start( char * );
int emit_paragraph_end( void );


#endif /* INCLUDED_EMIT_H */
