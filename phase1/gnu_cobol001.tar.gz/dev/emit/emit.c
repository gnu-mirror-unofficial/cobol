/*
 *
 *  Main source file for all emit functions and related code
 *
 *  Chad Slaughter 
 *  11/15/97
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>

#include "symtable.h"

#define EMIT_GLOBAL_DEF
#include "emit.h"

#include "emit_impl.h"

/*
extern int snprintf(char *str, size_t n, const char *fmt, ...) ;
 */


/***********************************************************
 * Support code for the emit functions
 ***********************************************************/

/*
 *  emitInitalize -
 * 
 *  Function takes a null terminated string, that represents the
 *  prefix to use for outputed filenames.
 *  Both files are opened and initalized for output
 *  header file is: dumped with neccessary include files
 *  source file is outputed with neccessary include
 * 	and start main
 */

int EmitInit(char* prefix) {

	char *filename = NULL;
	int prefixLength = strlen( prefix );
	int rc;

	/* alloc space for the filename        the 3 is (.[ch]\0) */
	filename = (char*) malloc( (prefixLength + 3) * sizeof(char) );
	if ( filename == NULL )
		return 1;

/* setup filenames and open files for c source output */
	sprintf(filename,"%s.h", prefix);
	gEmitEnv.header = fopen(filename, "w"); /* to print header info */
	if ( gEmitEnv.header == NULL ) {
		free( filename );
		return 2;
	}
			
	filename[prefixLength+2-1] = 'c';
	gEmitEnv.source = fopen(filename, "w"); /* to print source info */
	if ( gEmitEnv.source == NULL ) {
		free( filename );
		return 2;
	}

	/* done with thw alloced mem */
	free(filename);


/*
 * output to source file the generated header include and 
 * gen comment 
 *
 */
	rc = fprintf( gEmitEnv.source ,
			"/*\n"
			" * This file was genrated by cob2c\n"
			" */\n"
			"#include \"%s.h\"\n"
/* Moved to emit_paragraph_main( char * ); */
/*
			"int main(int argc, char** argv ) {\n"
*/
			,prefix); 

	if ( rc < 0 ) /* Error writing to file */
		return 3;

/* output include files to the header */
	rc = fprintf( gEmitEnv.header ,
			"#include <stdio.h>\n" 
			"#include <stdlib.h>\n" 
			"#include <sys/types.h>\n" 
			"#include <unistd.h>\n" 
			"#include <ctype.h>\n" 
			"#include <math.h>\n" 
			"#include <errno.h>\n" 
			"#include <locale.h>\n" 
			"#include <limits.h>\n" 
			"#include <string.h>\n" 
			"#include <time.h>\n" 
/*			"#include <.h>\n"  */
		    );
	if ( rc < 0 ) /* Error writing to file */
		return 3;

#if 0
/* emit some standard temparories for use in later emit code */
/*
 * no temparories need so far. All future temporaries
 *  will be named with two leading underscore to prevent
 *  conflicts with cobol variable names and the C compiler
 *  reserved names.
 */
	rc = fprintf( gEmitEnv.header ,
		" "
		);
#endif

	
	
	if ( rc < 0 ) /* Error writing to file */
		return 3;
		
	rc = atexit( emitCleanUp );

	/* wow it worked */
	return 0;
}

/*
 * emitCleanUp -
 *
 * CleanUp from EmitInit.
 *    Close all files that were open.
 *
 */
void emitCleanUp(void) {

	/* dump symbol table here */
	(void)fprintf( gEmitEnv.header ,
			"\n"
		 );

	
	(void)fclose(gEmitEnv.header);
	(void)fclose(gEmitEnv.source);

	return ;
}

/***********************************************************/
/***********************************************************/
/***********************************************************/
/*
 *  
 * Main emit code functions.
 *
 *
 */
/***********************************************************/
/***********************************************************/
/***********************************************************/


/***********************************************************/
/*
 * emit_paragraph -
 *   Code to emit start and end of paragraphs.
 *  
 */
/***********************************************************/

/*
 * emit_paragraph_main_start-
 *      handle first paragraph 
 */
int emit_paragraph_main_start( void ) {

	int rc;
	rc=fprintf(gEmitEnv.source,
		"void main(int argc,char** argv){\n"
	);

	if ( rc < 0 )
		return rc;

        return 0;
}
/*
 * emit_paragraph_start( char * name ) - 
 *   emit the start of a new function and a function protype.
 *
 */
int emit_paragraph_start( char * in_name ) {

	int rc;
	char * string = NULL;


	/* make a copy of the passed in string */
	string =strdup( in_name );
	if ( string == NULL )
		return 9; /* unable to alloac mem */

	/* get rid of dashes */
	emit_support_dash2under(string);


	/* emit start of function body */
	rc = fprintf(gEmitEnv.source,
			"void %s(void){"
			,string
	);
	/* emit function prototype */
	rc = fprintf(gEmitEnv.header,
			"void %s(void);"
			,string
	);

	free(string);
	if ( rc < 0 )
		return 1;
	return 0;

}

/*
 * End function, return control to call, and close block
 *
 */
int emit_paragraph_end( void ) {

	int rc;
	rc=fprintf(gEmitEnv.source,
		 "return;}\n"
	);

	if ( rc < 0 )
		return rc;

        return 0;
}


/***********************************************************/
/*
 * emit_accept -
 *
 *  Read input from stdin
 *  into the named parameter variable.
 *     The semantics of the accept statment when reading form
 *     stdin.
 *     read in x number
 * 
 */ 
/***********************************************************/

int emit_accept( char* in_string ){ 

	Entry * ptr = NULL;
	int rc;
	char * string = NULL;

	rc = SymLookup( in_string, &ptr );

	if ( rc != 0 ) /* not equal to  */
		return 1;

	/* make a copy of the passed in string */
	string =strdup( in_string );

	if ( string == NULL )
		return 9; /* unable to alloac mem */

	/* get rid of dashes */
	emit_support_dash2under(string);

	switch (ptr->type ) {

		case 'S': /* handle String Type */
			rc = emit_accept_string( string , ptr->length);
			break;
		case 'N': /* handle Number Type */
		rc = emit_accept_number( string , 
					 ptr->length, 
					 ptr->num->point);
			break;
		default: /* Bad type */
			rc = 1 ;
	}
	free(string);
	return rc;
}

/***********************************************************/
/*
 * emit_display_ident -
 *   print to the stdout the contents of the variable
 *
 */
/***********************************************************/

int emit_display_ident( char * in_string ) {

	Entry * ptr=NULL;
	char* string =NULL;
	int rc;

	rc = SymLookup( in_string, &ptr );

	if ( rc != 0 ) /* not equal to  */
		return 1;

	/* make a copy of the passed in string */
	string =strdup( in_string );

	if ( string == NULL )
		return 9; /* unable to alloac mem */

	/* get rid of dashes */
	emit_support_dash2under(string);

	switch (ptr->type ) {

		case 'S': /* handle String Type */
			rc=fprintf(gEmitEnv.source,
				"(void)printf(\"%%s\", %s);"
				,string
			   );
			break;
		case 'N': /* handle Number Type */
			rc=fprintf(gEmitEnv.source,
				"(void)printf(\"%%f\", %s);"
				,string
			   );
			break;
		default: /* Bad type */
			rc = 1 ;
	}

	free(string);
	return 9;
}

/*
 * emit_display_literal
 * printf out the literal value from a cobol display statement
 *
 */

int emit_display_literal( char* in_string ) {

	int rc;
	switch ( in_string[0] ) {

		case '\'':
			in_string[0] = '"';
			in_string[strlen(in_string)-1] = '"';
			/* fall thru */
		case '"':
		rc=fprintf(gEmitEnv.source,
			"/*display literal terminate string */"
			"(void)printf(%s);"
			,in_string
		);
		break;


		default:

		rc=fprintf(gEmitEnv.source,
			"/*display literal terminate string */"
			"(void)printf(\"%s\");"
			,in_string
		);
	}

	if ( rc < 0 )
		return rc;

        return 0;
}

/*
 *emit_display_advance -
 * hack to handle the cobol no advancing clause
 *  which determines whether a newline is added or not.
 *
 */
int emit_display_advance( int in_flag ){

	static no_newline = 0;
	int rc;

	/*  funciton called from the no advancing
         *  clause in the cobol display statement
         */
	if ( in_flag == 1 ) {
		/* setup flag so when called again we'll
		 * know not to add a newline
		 */
		no_newline = 1;
		return 0;
	}
	
	/* not a one so it must be  zero */
	assert ( in_flag == 0 ); /* just to piss off 
				  * laura when she calls it wrong */

	if ( in_flag == 0 ) {
		
		switch ( no_newline ) {

			case 1:
				rc = 0;
				break;

			default:
				rc=fprintf(gEmitEnv.source,
					"(void)printf(\"\\n\");"
		   		);
		}

		no_newline = 0;
	}

	if ( rc < 0 )
		return 1;

	return 0;
	

}
/***********************************************************/
/*
 * emit code for 
 *  accepting day of week, ( monday=1...sunday=7 ) to the variable
 *
 */
/***********************************************************/
int emit_accept_dow( char* in_string ){ 

	Entry * ptr=NULL;
	char* string =NULL;
	int rc;

	rc = SymLookup( in_string, &ptr );

	if ( rc != 0 ) /* not equal to  */
		return 1;

	/* make a copy of the passed in string */
	string =strdup( in_string );

	if ( string == NULL )
		return 9; /* unable to alloac mem */

	/* get rid of dashes */
	emit_support_dash2under(string);

	switch (ptr->type ) {

		case 'S': /* handle String Type */
			rc = emit_accept_dow_string( string ,ptr->length);
			break;
		case 'N': /* handle Number Type */
			rc = emit_accept_dow_number( string );
			break;
		default: /* Bad type */
			rc = 1 ;
	}
	free(string);
	return rc;
}

int emit_accept_time( char* in_string ){

	Entry * ptr=NULL;
	char* string =NULL;
	int rc;


	rc = SymLookup( in_string, &ptr );

	if ( rc != 0 ) /* not equal to  */
		return 1;

	/* make a copy of the passed in string */
	string =strdup( in_string );

	if ( string == NULL )
		return 9; /* unable to alloac mem */

	/* get rid of dashes */
	emit_support_dash2under(string);

	switch (ptr->type ) {

		case 'S': /* handle String Type */
			rc = emit_accept_time_string( string,ptr->length );
			break;
		case 'N': /* handle Number Type */
			rc = emit_accept_time_number( string );
			break;
		default: /* Bad type */
			rc = 1 ;
	}
	free(string);
	return rc;
}
int emit_accept_date( char* in_string ){
	Entry * ptr=NULL;
	char* string =NULL;
	int rc;
	rc = SymLookup( in_string, &ptr );

	if ( rc != 0 ) /* not equal to  */
		return 1;

	/* make a copy of the passed in string */
	string =strdup( in_string );

	if ( string == NULL )
		return 9; /* unable to alloac mem */

	/* get rid of dashes */
	emit_support_dash2under(string);
	switch (ptr->type ) {

		case 'S': /* handle String Type */
			rc = emit_accept_date_string( string,ptr->length );
			break;
		case 'N': /* handle Number Type */
			rc = emit_accept_date_number( string );
			break;
		default: /* Bad type */
			rc = 1 ;
	}
	free(string);
	return rc;
}


int emit_accept_day( char* in_string ){
	Entry * ptr=NULL;
	int rc;
	char * string;
	rc = SymLookup( in_string, &ptr );

	if ( rc != 0 ) /* not equal to  */
		return 1;

	/* make a copy of the passed in string */
	string =strdup( in_string );

	if ( string == NULL )
		return 9; /* unable to alloac mem */

	/* get rid of dashes */
	emit_support_dash2under(string);

	switch (ptr->type ) {

		case 'S': /* handle String Type */
			rc = emit_accept_day_string( string , ptr->length);
			break;
		case 'N': /* handle Number Type */
			rc = emit_accept_day_number( string );
			break;
		default: /* Bad type */
			rc = 1 ;
	}
	free(string);
	return rc;
}

/***********************************************************/
/*
 * Stop verb
 *   return to OS from main.
 */
/***********************************************************/
int emit_stop_run( void ) {

	int rc = fprintf( gEmitEnv.source,
				"exit(0);"      /* close out main */
			);
	if ( rc <= 0 )
		return 1;

		return 0;
}

/***********************************************************/
/*
 * emit_variable -
 *   emit variable declarations into
 *   the C header file.
 *  emit structure headers and trailers.
 */
/***********************************************************/
int emit_variable( char * in_string ){

	Entry * ptr=NULL;
	int rc;
	char* string =NULL;
	rc = SymLookup( in_string, &ptr );

	if ( rc != 0 ) /* not equal to  */
		return 1;

	/* make a copy of the passed in string */
	string =strdup( in_string );

	if ( string == NULL )
		return 9; /* unable to alloac mem */

	/* get rid of dashes */
	emit_support_dash2under(string);

	switch (ptr->type ) {

		case 'S': /* handle String Type */
			rc = emit_variable_string( 
				string, 
			   	ptr->str->init,
				ptr->length
				);
			break;
		case 'N': /* handle Number Type */
			rc = emit_variable_number(
				string,
				ptr->num->init
			     );
			break;
		default: /* Bad type */
			rc = 1 ;
	}

	free(string);
	return rc;
}

/* emit the begining of struct */
int emit_var_struct_begin( char * in_string ){

	int rc;
	char* string =NULL;

	/* make a copy of the passed in string */
	string =strdup( in_string );

	if ( string == NULL )
		return 9; /* unable to alloac mem */

	/* get rid of dashes */
	emit_support_dash2under(string);

	rc = fprintf( gEmitEnv.header,
			"struct __s_%s {"
			,string
	);


	free(string);

	if ( rc < 0 )
		return 1;

	return 0;
}
/* emit the end of struct */
int emit_var_struct_end( char * in_string ){

	int rc;
	char* string =NULL;

	/* make a copy of the passed in string */
	string =strdup( in_string );

	if ( string == NULL )
		return 9; /* unable to alloac mem */

	/* get rid of dashes */
	emit_support_dash2under(string);

	rc = fprintf( gEmitEnv.header,
			"} %s;"
			,string
	);


	free(string);

	if ( rc < 0 )
		return 1;

	return 0;
}


/***********************************************************/
/*
 * if, else verb 
 */
/***********************************************************/
/*
 * emit start of a C if statement
 *  the if keyword.
 */
int emit_if_start( void ) {

	int rc;
	rc = fprintf( gEmitEnv.source,
			" if (1)"
	);
	if ( rc <= 0 )
	    return 1;

	return 0;
}
/* 
 * start a code block for the if statement
 */
int emit_if_block( void ){
	return emit_start_C_block();
}

/*
 * code to impliment the next sentence cobol statement
 * not yet implimented
 */
int emit_if_next_sentence( void ){
	int rc;
	rc = fprintf( gEmitEnv.source,
			"/* next sentence - not implimented */"
	);
	if ( rc <= 0 )
		return 1;

	return 0;
}
/*
 * end of an if code block 
 */
int emit_if_end( void ){
	return emit_end_C_block();
}

/*
 * emit code for the start of the
 *  C else statement
 *  emit the else keyword.
 */
int emit_else_start( void ){
	int rc;
	rc = fprintf( gEmitEnv.source,
			" else {"
	);
	if ( rc <= 0 )
		return 1;

	return 0;
}


/*
 * code to impliment the next sentence cobol statement
 * not yet implimented
 */
int emit_else_next_sentence( void ){

	int rc;
	rc = fprintf( gEmitEnv.source,
			"/* next sentence - not implimented */"
	);
	if ( rc <= 0 )
		return 1;

	return 0;
}

int emit_else_end( void ){

	return emit_end_C_block();
}


/***********************************************************/
/* Move verb -
 *
 *  Function to emit code for the cobol move verb.
 */
/***********************************************************/

/*
 * emit_move_literalToNumber -
 *   move numeric literal value into the dest number variable.
 *
 */
int emit_move_literalToNumber(char * in_literal, char * in_number){

	Entry * ptr=NULL;
	int rc;
	char * string;
	rc = SymLookup( in_number, &ptr );

	if ( rc != 0 ) /* not equal to  */
		return 1;

	/* make a copy of the passed in string */
	string =strdup( in_number );

	if ( string == NULL )
		return 9; /* unable to alloac mem */

	/* get rid of dashes */
	emit_support_dash2under(string);
/* */
	rc = fprintf(gEmitEnv.source,
			"%s = %s;"
			,string, in_literal	
	     );


	if ( rc < 0 )
		return 1;

	if(ptr->type != 'N' )
		return 1;

	rc = emit_truncate_number(string,ptr->length,ptr->num->point);

	free(string);
	return 0;

}
/*
 * emit_move_literalToString - 
 *   move quoted string literal into  a string variable of length
 *
 */
int emit_move_literalToString(char* in_litSrc, char *in_strDest, int length ){

	int rc;
	char * string;

	/* chekc for a single quote(') literal */
	if ( in_litSrc[0] == '\'' ) {
		in_litSrc[0]='"';
		in_litSrc[length -1] ='"';
	}

	string = strdup( in_strDest );

	if ( string == NULL )
		return 9; /* unable to alloac mem */

	/* get rid of dashes */
	emit_support_dash2under(string);

	switch ( in_litSrc[0] ) {

		case '"':
			 rc = fprintf(gEmitEnv.source,
				"strncpy(%s,%s,%d);"
				"%s[%d]=\'\\0\';"
				"/*add null to end of string */"
				,string, in_litSrc ,length
				,string,length
				
	     		);
			break;
		default:
			 rc = fprintf(gEmitEnv.source,
				"strncpy(%s,\"%s\",%d);"
				"%s[%d]=\'\\0\';"
				"/*add null to end of string */"
				,string, in_litSrc ,length
				,string,length
	     		);
			
	};

	free(string);
	if ( rc < 0 )
		return 1;
	return 0;
}
/*
 * move a number to a string
 */
int emit_move_NumberToString(char* in_number, char * in_string, int length){

	Entry * ptr=NULL;
	int rc;
	char * strNumb;
	char * strStr;

	rc = SymLookup( in_number, &ptr );

	if ( rc != 0 ) /* not equal to  */
		return 1;

	/* make a copy of the passed in string */
	strNumb =strdup( in_number );
	if ( strNumb == NULL )
		return 9; /* unable to alloac mem */
	strStr = strdup( in_string );
	if ( strStr == NULL ) {
		free(strNumb);
		return 9; /* unable to alloac mem */
	}
	/* get rid of dashes */
	emit_support_dash2under(strNumb);
	emit_support_dash2under(strStr);
	

/*
	rc = emit_truncate_	
 */

	free(strNumb);
	free(strStr);
	return 8;
}

/*
 * move a string ident to a string ident of length.
 */
int emit_move_StringToString(char* in_strSrc, char*in_strDest, int length ){

	int rc;
	char * strSrc;
	char * strDest;

	/* make a copy of the passed in string */
	strSrc =strdup( in_strSrc );
	if ( strSrc == NULL )
		return 9; /* unable to alloac mem */

	strDest =strdup( in_strDest );

	if ( strDest == NULL ){
		free(strSrc);
		return 9; /* unable to alloac mem */
	}


	/* get rid of dashes */
	emit_support_dash2under(strSrc);
	emit_support_dash2under(strDest);

	rc = fprintf(gEmitEnv.source,
			"strncpy(%s,%s,%d);"
			"%s[%d]=\'\\0\';"
			"/*add null to end of string */"
			,strDest, strSrc ,length
			,strDest,length
	     );

	free(strSrc);
	free(strDest);
	if ( rc < 0 )
		return 1;
	return 0;

}

/*
 * move number ident to number ident 
 */
int emit_move_NumberToNumber(char* in_NumSrc, char* in_NumDest ) {

	Entry * ptr=NULL;
	int rc;
	char * strDest;
	char * strSrc;

	rc = SymLookup( in_NumDest, &ptr );

	if ( rc != 0 ) /* not equal to  */
		return 1;

	/* make a copy of the passed in string */
	strSrc =strdup( in_NumSrc );
	if ( strSrc == NULL )
		return 9; /* unable to alloac mem */

	/* make a copy of the passed in string */
	strDest =strdup( in_NumDest );
	if ( strDest == NULL ){
		free(strSrc);
		return 9; /* unable to alloac mem */
	}


	/* get rid of dashes */
	emit_support_dash2under(strSrc);
	emit_support_dash2under(strDest);

	rc = fprintf(gEmitEnv.source,
			"%s = %s;"
			,strDest, strSrc
	     );
	if ( rc < 0 )
		return 1;

	rc = emit_truncate_number(strDest, ptr->length,ptr->num->point);

	free(strSrc);
	free(strDest);
	return rc;
}

/***********************************************************/
/* Copy verb -
 *
 *  Function to emit code for the cobol copy verb.
 *  
 * copy includes the full text of a specified file.
 */
/***********************************************************/

int emit_copy( char * in_string ) {
	return 8;
}

/***********************************************************/
/*
 * Perform verb -
 * Function to emit code for the cobol perform verb.
 *
 *  Emits code for function calls, for iterative,pretest, 
 *   posttest loops. 
 *
 */
/***********************************************************/


/*
 * Start perform statement
 * emit open bracket, 
 */
int emit_perform_start( void ) {

	return emit_start_C_block();

}

/*
 * End of perform statement -
 * With optional function call to passed in named paragraph.
 *
 * Function accepts a Paragraphname or NULL 
 *
 * emit one or two closing brackets and a optional function call 
 *
 */
int emit_perform_end( char * in_paraName ){
	int rc;
	char * string;


	if ( string != NULL ) { /* handle paragraph name */
		/* make a copy of the passed in string */
		string =strdup(  in_paraName);
		if ( string == NULL )
			return 9; /* unable to alloac mem */

		/* get rid of dashes */
		emit_support_dash2under(string);

		rc = fprintf(gEmitEnv.source,
				"%s();"
				,string
			);
		free(string);
		if ( rc < 0 )
			return 1;
	}

	rc = emit_end_C_block();

	if (  emit_perform_support_loop( 0 ) == 1 )
		rc += emit_end_C_block(); /* end of loop bracket */

	return rc;

}
/*
 * Perform iterative loop
 * emit a iterative loop 
 *
 * name - literal or identifier 
 * flag      1          0
 */
int emit_perform_times(char * in_name , int flag){

	int rc;
	char * string = NULL;


	/* make a copy of the passed in string */
	string =strdup( in_name );
	if ( string == NULL )
		return 9; /* unable to alloac mem */

	if ( flag == 0 ) { /* identifier */
		/* get rid of dashes */
		emit_support_dash2under(string);
	}

	/* setup for proper end to loop block */
	emit_perform_support_loop( 2 );

	rc = fprintf(gEmitEnv.source,
			"int i;"
			"for(i=0;i < %s;i++){"
			,string
	     );

	free(string);
	if ( rc < 0 )
		return 1;
	return 0;

}

/* 
 * emit code for a pretest loop
 *
 */
int emit_perform_loop_before( void ){
	int rc;

	emit_perform_support_loop( 3 );
	rc = fprintf(gEmitEnv.source,
		"while(" 
	     );

	if ( rc < 0 )
		return 1;
	return 0;

}
/*
 * Emit code for a post test loop
 * emit test after loop 
 */
int emit_perform_loop_after( void ){
	int rc;
	emit_perform_support_loop( 4 );

	rc = fprintf(gEmitEnv.source,
		"__postTestLoop = 1;"
		"while(__postTestLoop || " 
	     );

	if ( rc < 0 )
		return 1;
	return 0;

}

/*
 * Close condition expression for pre & post test loops
 *  For a post test loop emit support code to handle post
 * tests
 */
int emit_perform_loop_end( void ) {
	/* end loop condition emittion */
	int rc;

	/* close off while conditional and 
	 * open code block for loop	
	 */
	rc = fprintf(gEmitEnv.source,
			"){"
	     );


	/* test for post test loop */
	if ( emit_perform_support_loop( 1 ) == 1 ) { 
		rc += fprintf (gEmitEnv.source,
				"__postTestLoop = 0;"
		);
	}
	
	if ( rc < 0 )
		return 1;
	return 0;

}

