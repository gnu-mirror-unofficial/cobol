#ifndef INCLUDED_EMIT_IMPL_H
#define INCLUDED_EMIT_IMPL_H

/*  Support Functions for the main emit functions */

/* support functions for the accept verb based 
 *  on variable type .
 */
int emit_accept_dow_number(char * string ) ;
int emit_accept_dow_string(char * string, int ) ;
 
int emit_accept_time_number( char* string );
int emit_accept_time_string( char* string,int  );

int emit_accept_date_number( char* string );
int emit_accept_date_string( char* string, int );

int emit_accept_day_number( char* string );
int emit_accept_day_string( char* string,int );

int emit_accept_string( char * string, int ) ;
int emit_accept_number( char * string, int, int  ) ;

/*
 * Support code for emitting variable declartions
 *  based on type
 */
int emit_variable_string( char * in_string, char* init, int length ) ;
int emit_variable_number( char * in_string, double init );

/*  function to convert cobol variable names into C variable names */
int emit_support_dash2under( char * string );

/*  Function to emit numeric truncation */
int emit_truncate_number(char * ,int,int);

/*
 * minor support functions to encapalate
 * the printing of the start and end of C code blocks
 */
int emit_start_C_block( void );
int emit_end_C_block( void );
/*
 * Support routines for perform statment
 * function to hold temp value if need to emit close bracket on
 * a loop 
 */
int emit_perform_support_loop( int ); 



#endif /* INCLUDED_EMIT_IMPL_H */
