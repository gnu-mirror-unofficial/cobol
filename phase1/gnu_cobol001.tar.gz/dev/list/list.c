/*
 * Linked list functions, just for you.
 * John J. Adelsberger III
 */

#include <stdlib.h>
#include "list.h"

/*
 * Used for producing new nodes with given data, returns the node with
 * NULL pointers.  Yes, you can use this as a new list w/o calling attach.
 */
struct list_node *make_node(TYPE *dt)
{
    struct list_node *nw = (struct list_node*)malloc(sizeof(struct list_node));
    nw->data = (TYPE*)malloc(sizeof(TYPE));
    *(nw->data) = *dt;
    nw->next = nw->prev = NULL;
    return nw;
}

/*
 * Returns the attach point, or nw if attach point is NULL.
 */
struct list_node* attach(struct list_node *attach_point, struct list_node *nw)
{
    if(!nw) return NULL;

    /*
     * Check for new list.
     */ 
    if(!attach_point)
    {
        nw->prev = nw->next = NULL;
        return nw;
    }

    /*
     * Guess it isn't a new list.
     */
    nw->next = attach_point->next;
    nw->prev = attach_point;
    attach_point->next = nw;
    return attach_point;
}

/*
 * Returns the head of the list.
 */
struct list_node* nuke(struct list_node *head, struct list_node *old)
{
    /*
     * Make it Chad-proof.
     */
    if(!head) return NULL;
    if(!old) return head;

    /*
     * Swizzle them pointers...
     */
    if(old->prev) old->prev->next = old->next;
    if(old->next) old->next->prev = old->prev;
    else head = head->next;

    /*
     * Clean up after yourself!
     */
    free(old->data);
    free(old);

    return head;
}

/*
 * Returns the size of the list, 0 if NULL.
 */
int size(struct list_node *head)
{
    int i;
    struct list_node *curr = head;

    for(i = 0; curr; i++, curr = curr->next);

    return i;
}

/*
 * Destroy a list.
 */
int make_empty(struct list_node *head)
{
    if(!head) return 0;
    if(head->next) make_empty(head->next);
    free(head->data);
    free(head);
    
    return 0;
}
