#ifndef INCLUDED_LIST_H
#define INCLUDED_LIST_H
/*
 * Linked list goodies, just for you.
 * John J. Adelsberger III
 */


#include "ListEntry.h"

/*
 * Type of data being stored in these lists.
 */
#define TYPE ListEntry

/*
 * List node structure.
 */
struct list_node
{
    struct list_node *next, *prev;
    TYPE *data;
};

/*
 * Fn prototypes.
 */
struct list_node* make_node(TYPE *dt);
struct list_node* attach(struct list_node *attach_point, struct list_node *nw);
struct list_node* nuke(struct list_node *head, struct list_node *old);
int size(struct list_node *head);
int make_empty(struct list_node *head);

#endif /* INCLUDED_LIST_H */
