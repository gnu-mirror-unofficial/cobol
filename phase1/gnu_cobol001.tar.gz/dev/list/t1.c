#include <stdio.h>
#include "list.h"

int main() {

	list_node *Head;
	ListEntry *le;

	le->type = 'S';
	strcpy(le->data, "bob");
	le->rounded = 0;

	Head = make_node(le);
	attach(Head, NULL);

	printf("%d\n", size(Head));

return 0;
}
