#ifndef INCLUDED_LISTENTRY_H
#define INCLUDED_LISTENTRY_H

/*
	The struct being stored in the list
 */

#ifndef MAXIDENTLENGTH
#define MAXIDENTLENGTH 40
#endif

typedef struct s_ListEntry ListEntry

struct s_ListEntry {
	char	type;	/* 'N', 'S' (ident) */
	char	data[MAXIDENTLENGTH];
			/* if number, type = 'N' Stored double as string here*/
	int	rounded;
};
#endif /* INCLUDED_LISTENTRY_H */
