/*
 * A n t l r  T r a n s l a t i o n  H e a d e r
 *
 * Terence Parr, Will Cohen, and Hank Dietz: 1989-1994
 * Purdue University Electrical Engineering
 * With AHPCRC, University of Minnesota
 * ANTLR Version 1.33MR9
 */
#include <stdio.h>
#define ANTLR_VERSION	133MR9

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "charbuf.h"
#include "c-global.h"
#define ZZCAN_GUESS
#include <setjmp.h>
#define LL_K 4
#define zzSET_SIZE 48
#include "antlr.h"
#include "tokens.h"
#include "dlgdef.h"
#include "mode.h"
#ifndef PURIFY
#define PURIFY(r,s)
#endif

void
#ifdef __USE_PROTOS
add_stmt(void)
#else
add_stmt()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	add_main();
	add_sizing();
	add_ending();
	zzNON_GUESS_MODE {
	/*VerbAddActions(); */  
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd26, 0x1);
	}
}

void
#ifdef __USE_PROTOS
add_sizing(void)
#else
add_sizing()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	zzGUESS_BLOCK
	zzGUESS
	if ( !zzrv && (setwd26[LA(1)]&0x2) ) {
		{
			zzBLOCK(zztasp2);
			zzMake0;
			{
			size_err();
			zzEXIT(zztasp2);
			}
		}
		zzGUESS_DONE
		{
			zzBLOCK(zztasp2);
			zzMake0;
			{
			size_err();
			zzEXIT(zztasp2);
			}
		}
	}
	else {
		if ( zzguessing ) zzGUESS_DONE;
		if ( (setwd26[LA(1)]&0x4) ) {
		}
		else {zzFAIL(1,zzerr64,&zzMissSet,&zzMissText,&zzBadTok,&zzBadText,&zzErrk); goto fail;}
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd26, 0x8);
	}
}

void
#ifdef __USE_PROTOS
add_ending(void)
#else
add_ending()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	zzGUESS_BLOCK
	zzGUESS
	if ( !zzrv && (LA(1)==END_ADD) ) {
		{
			zzBLOCK(zztasp2);
			zzMake0;
			{
			zzmatch(END_ADD); zzCONSUME;
			zzEXIT(zztasp2);
			}
		}
		zzGUESS_DONE
		{
			zzBLOCK(zztasp2);
			zzMake0;
			{
			zzmatch(END_ADD); zzCONSUME;
			zzEXIT(zztasp2);
			}
		}
	}
	else {
		if ( zzguessing ) zzGUESS_DONE;
		if ( (LA(1)==1) ) {
		}
		else {zzFAIL(1,zzerr65,&zzMissSet,&zzMissText,&zzBadTok,&zzBadText,&zzErrk); goto fail;}
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd26, 0x10);
	}
}

void
#ifdef __USE_PROTOS
add_main(void)
#else
add_main()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	zzmatch(ADD_C); zzCONSUME;
	ident1_line();
	zzmatch(TO); zzCONSUME;
	ident2_line();
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd26, 0x20);
	}
}

void
#ifdef __USE_PROTOS
ident1_line(void)
#else
ident1_line()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==CORR)
 ) {
			zzmatch(CORR);
			zzNON_GUESS_MODE {
			SetFlag(&verb_flags, ADD_CORR);   
			}
 zzCONSUME;

		}
		zzEXIT(zztasp2);
		}
	}
	{
		zzBLOCK(zztasp2);
		int zzcnt=1;
		zzMake0;
		{
		do {
			if ( (LA(1)==PROG_NAME) ) {
				ident();
				zzNON_GUESS_MODE {
				Enqueue(arg1, Ident);   
				}
			}
			else {
				if ( (LA(1)==NUMERIC) ) {
					numeric();
					zzNON_GUESS_MODE {
					Enqueue(arg2, Numeric_s);   
					}
				}
				else if ( zzcnt>1 ) break; /* implied exit branch */
				else {zzFAIL(1,zzerr66,&zzMissSet,&zzMissText,&zzBadTok,&zzBadText,&zzErrk); goto fail;}
			}
			zzcnt++; zzLOOP(zztasp2);
		} while ( 1 );
		zzEXIT(zztasp2);
		}
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd26, 0x40);
	}
}

void
#ifdef __USE_PROTOS
ident2_line(void)
#else
ident2_line()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==PROG_NAME) ) {
			{
				zzBLOCK(zztasp3);
				int zzcnt=1;
				zzMake0;
				{
				do {
					ident();
					{
						zzBLOCK(zztasp4);
						zzMake0;
						{
						if ( (LA(1)==ROUNDED) ) {
							zzmatch(ROUNDED);
							zzNON_GUESS_MODE {
							SetFlag(&verb_flags, ROUNDED);   
							}
 zzCONSUME;

						}
						zzEXIT(zztasp4);
						}
					}
					zzNON_GUESS_MODE {
					Enqueue(arg2, Ident); ResetFlag(&verb_flags);   
					}
					zzLOOP(zztasp3);
				} while ( (LA(1)==PROG_NAME)
 );
				zzEXIT(zztasp3);
				}
			}
		}
		else {
			if ( (LA(1)==NUMERIC) ) {
				numeric();
				zzNON_GUESS_MODE {
				Enqueue(arg2, Numeric_s);   
				}
			}
			else {zzFAIL(1,zzerr67,&zzMissSet,&zzMissText,&zzBadTok,&zzBadText,&zzErrk); goto fail;}
		}
		zzEXIT(zztasp2);
		}
	}
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==GIVING) ) {
			giving_line();
		}
		zzEXIT(zztasp2);
		}
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd26, 0x80);
	}
}

void
#ifdef __USE_PROTOS
giving_line(void)
#else
giving_line()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	zzmatch(GIVING); zzCONSUME;
	{
		zzBLOCK(zztasp2);
		int zzcnt=1;
		zzMake0;
		{
		do {
			ident();
			{
				zzBLOCK(zztasp3);
				zzMake0;
				{
				if ( (LA(1)==ROUNDED) ) {
					zzmatch(ROUNDED);
					zzNON_GUESS_MODE {
					SetFlag(&verb_flags, ROUNDED);   
					}
 zzCONSUME;

				}
				zzEXIT(zztasp3);
				}
			}
			zzNON_GUESS_MODE {
			Enqueue(giving, Ident); ResetFlag(&verb_flags);   
			}
			zzLOOP(zztasp2);
		} while ( (LA(1)==PROG_NAME) );
		zzEXIT(zztasp2);
		}
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd27, 0x1);
	}
}
