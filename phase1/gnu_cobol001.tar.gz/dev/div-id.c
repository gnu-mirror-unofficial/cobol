/*
 * A n t l r  T r a n s l a t i o n  H e a d e r
 *
 * Terence Parr, Will Cohen, and Hank Dietz: 1989-1994
 * Purdue University Electrical Engineering
 * With AHPCRC, University of Minnesota
 * ANTLR Version 1.33MR9
 */
#include <stdio.h>
#define ANTLR_VERSION	133MR9

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "charbuf.h"
#include "c-global.h"
#define ZZCAN_GUESS
#include <setjmp.h>
#define LL_K 4
#define zzSET_SIZE 48
#include "antlr.h"
#include "tokens.h"
#include "dlgdef.h"
#include "mode.h"
#ifndef PURIFY
#define PURIFY(r,s)
#endif

void
#ifdef __USE_PROTOS
identification_division(void)
#else
identification_division()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
#ifdef DEBUG
	fprintf(stderr, "Entering IDENTIFICATION DIVISION\n");
#endif   
	zzmatch(IDENTIFICATION); zzCONSUME;
	zzmatch(DIVISION); zzCONSUME;
	zzmatch(PERIOD); zzCONSUME;
	zzmatch(PROGRAM_ID); zzCONSUME;
	zzmatch(PERIOD); zzCONSUME;
	ident();
	zzNON_GUESS_MODE {
	PrintInfoHeader();
	InitializeAll(Ident);
	}
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (setwd3[LA(1)]&0x2) ) {
			{
				zzBLOCK(zztasp3);
				zzMake0;
				{
				if ( (LA(1)==IS) ) {
					zzmatch(IS); zzCONSUME;
				}
				zzEXIT(zztasp3);
				}
			}
			{
				zzBLOCK(zztasp3);
				zzMake0;
				{
				if ( (LA(1)==COMMON) ) {
					zzmatch(COMMON); zzCONSUME;
				}
				else {
					if ( (LA(1)==INITIAL_C) ) {
						zzmatch(INITIAL_C); zzCONSUME;
					}
					else {zzFAIL(1,zzerr3,&zzMissSet,&zzMissText,&zzBadTok,&zzBadText,&zzErrk); goto fail;}
				}
				zzEXIT(zztasp3);
				}
			}
			{
				zzBLOCK(zztasp3);
				zzMake0;
				{
				if ( (LA(1)==PROGRAM)
 ) {
					zzmatch(PROGRAM); zzCONSUME;
				}
				zzEXIT(zztasp3);
				}
			}
		}
		zzEXIT(zztasp2);
		}
	}
	zzmatch(PERIOD); zzCONSUME;
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		while ( (setwd3[LA(1)]&0x4) ) {
			{
				zzBLOCK(zztasp3);
				zzMake0;
				{
				if ( (LA(1)==AUTHOR) ) {
					zzmatch(AUTHOR);
					zzNON_GUESS_MODE {
					CheckFlag( &id_div_flags , ID_AUTHOR, "AUTHOR" );   
					}
 zzCONSUME;

				}
				else {
					if ( (LA(1)==INSTALLATION) ) {
						zzmatch(INSTALLATION);
						zzNON_GUESS_MODE {
						CheckFlag( &id_div_flags , ID_INSTALLATION, "INSTALLATION" );   
						}
 zzCONSUME;

					}
					else {
						if ( (LA(1)==DATE_WRITTEN) ) {
							zzmatch(DATE_WRITTEN);
							zzNON_GUESS_MODE {
							CheckFlag( &id_div_flags , ID_DATE_WRITTEN, "DATE-WRITTEN" );   
							}
 zzCONSUME;

						}
						else {
							if ( (LA(1)==DATE_COMPILED)
 ) {
								zzmatch(DATE_COMPILED);
								zzNON_GUESS_MODE {
								CheckFlag( &id_div_flags , ID_DATE_COMPILED, "DATE-COMPILED");   
								}
 zzCONSUME;

							}
							else {
								if ( (LA(1)==SECURITY) ) {
									zzmatch(SECURITY);
									zzNON_GUESS_MODE {
									CheckFlag( &id_div_flags , ID_SECURITY, "SECURITY");   
									}
 zzCONSUME;

								}
								else {zzFAIL(1,zzerr4,&zzMissSet,&zzMissText,&zzBadTok,&zzBadText,&zzErrk); goto fail;}
							}
						}
					}
				}
				zzEXIT(zztasp3);
				}
			}
			zzmatch(PERIOD); zzCONSUME;
			{
				zzBLOCK(zztasp3);
				int zzcnt=1;
				zzMake0;
				{
				do {
					if ( (LA(1)==NUMERIC) ) {
						numeric();
					}
					else {
						if ( (LA(1)==PROG_NAME) ) {
							ident();
						}
						else {
							if ( (LA(1)==NONNUMERIC) ) {
								string_literal();
							}
							else if ( zzcnt>1 ) break; /* implied exit branch */
							else {zzFAIL(1,zzerr5,&zzMissSet,&zzMissText,&zzBadTok,&zzBadText,&zzErrk); goto fail;}
						}
					}
					zzcnt++; zzLOOP(zztasp3);
				} while ( 1 );
				zzEXIT(zztasp3);
				}
			}
			zzmatch(PERIOD); zzCONSUME;
			zzLOOP(zztasp2);
		}
		zzEXIT(zztasp2);
		}
	}
	zzNON_GUESS_MODE {
	ResetFlag( &id_div_flags );   
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd3, 0x8);
	}
}
