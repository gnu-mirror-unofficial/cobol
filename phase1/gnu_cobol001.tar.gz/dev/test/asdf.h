#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <ctype.h>
#include <math.h>
#include <errno.h>
#include <locale.h>
#include <limits.h>
#include <string.h>
#include <time.h>
double a = 0.000000;char b [3+1] = "";double noncontig_foof = 0.000000;double asdf = 0.000000;void 90_and_your_dog(void);
