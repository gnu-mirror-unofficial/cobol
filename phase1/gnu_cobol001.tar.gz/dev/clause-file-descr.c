/*
 * A n t l r  T r a n s l a t i o n  H e a d e r
 *
 * Terence Parr, Will Cohen, and Hank Dietz: 1989-1994
 * Purdue University Electrical Engineering
 * With AHPCRC, University of Minnesota
 * ANTLR Version 1.33MR9
 */
#include <stdio.h>
#define ANTLR_VERSION	133MR9

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "charbuf.h"
#include "c-global.h"
#define ZZCAN_GUESS
#include <setjmp.h>
#define LL_K 4
#define zzSET_SIZE 48
#include "antlr.h"
#include "tokens.h"
#include "dlgdef.h"
#include "mode.h"
#ifndef PURIFY
#define PURIFY(r,s)
#endif

void
#ifdef __USE_PROTOS
file_description(void)
#else
file_description()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
#ifdef DEBUG
	fprintf(stderr, "Entering File_Description\n");
#endif
	fd_line();
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		while ( 1 ) {
			if ( !((setwd10[LA(1)]&0x40))) break;
			if ( (setwd10[LA(1)]&0x80) && (setwd11[LA(2)]&0x1) && (setwd11[LA(3)]&0x2) && (setwd11[LA(4)]&0x4) && !((LA(1)==IS&&
((LA(2)==GLOBAL&&((LA(3)==PERIOD&&(LA(4)==NUMERIC))||((LA(3)==IS&&(LA(4)==EXTERNAL||
(LA(4)==GLOBAL)))||((LA(3)==EXTERNAL&&(LA(4)==PERIOD||(LA(4)==IS||(LA(4)==EXTERNAL||
(LA(4)==GLOBAL||(LA(4)==BLOCK||(LA(4)==RECORD||(LA(4)==LABEL||(LA(4)==VALUE||
(LA(4)==DATA||(LA(4)==CODE_SET)))))))))))||((LA(3)==GLOBAL&&(LA(4)==PERIOD||(LA(4)==IS||
(LA(4)==EXTERNAL||(LA(4)==GLOBAL||(LA(4)==BLOCK||(LA(4)==RECORD||(LA(4)==LABEL||
(LA(4)==VALUE||(LA(4)==DATA||(LA(4)==CODE_SET)))))))))))||((LA(3)==BLOCK&&(LA(4)==CONTAINS||
(LA(4)==NUMERIC)))||((LA(3)==RECORD&&(LA(4)==CONTAINS||(LA(4)==IS||(LA(4)==VARYING))))||
((LA(3)==LABEL&&(LA(4)==RECORD||(LA(4)==RECORDS)))||((LA(3)==VALUE&&(LA(4)==OF))||
((LA(3)==DATA&&(LA(4)==RECORD||(LA(4)==RECORDS)))||((LA(3)==CODE_SET&&(LA(4)==IS||
(LA(4)==PROG_NAME))))))))))))))))) ) {
				external_line();
				zzNON_GUESS_MODE {
				CheckFlag(&file_descr_flags, FD_EXTERNAL, "EXTERNAL");   
				}
			}
			else {
				if ( (setwd11[LA(1)]&0x8) && (setwd11[LA(2)]&0x10) && (setwd11[LA(3)]&0x20) && (setwd11[LA(4)]&0x40) ) {
					global_line();
					zzNON_GUESS_MODE {
					CheckFlag(&file_descr_flags, FD_GLOBAL, "GLOBAL");   
					}
				}
				else {
					if ( (LA(1)==BLOCK) ) {
						block_line();
						zzNON_GUESS_MODE {
						CheckFlag(&file_descr_flags, FD_BLOCK, "BLOCK");   
						}
					}
					else {
						if ( (LA(1)==RECORD)
 ) {
							record_line_f();
							zzNON_GUESS_MODE {
							CheckFlag(&file_descr_flags, FD_RECORD, "RECORD");   
							}
						}
						else {
							if ( (LA(1)==LABEL) ) {
								label_line();
								zzNON_GUESS_MODE {
								CheckFlag(&file_descr_flags, FD_LABEL, "LABEL");   
								}
							}
							else {
								if ( (LA(1)==VALUE) ) {
									value_line();
									zzNON_GUESS_MODE {
									CheckFlag(&file_descr_flags, FD_VALUE_OF, "VALUE OF");   
									}
								}
								else {
									if ( (LA(1)==DATA) ) {
										data_line();
										zzNON_GUESS_MODE {
										CheckFlag(&file_descr_flags, FD_DATA, "DATA");   
										}
									}
									else {
										if ( (LA(1)==CODE_SET) ) {
											code_set_line();
											zzNON_GUESS_MODE {
											CheckFlag(&file_descr_flags, FD_CODE_SET, "CODE SET");   
											}
										}
										else break; /* MR6 code for exiting loop "for sure" */
									}
								}
							}
						}
					}
				}
			}
			zzLOOP(zztasp2);
		}
		zzEXIT(zztasp2);
		}
	}
	zzmatch(PERIOD);
	zzNON_GUESS_MODE {
	ResetFlag(&file_descr_flags);   
	}
 zzCONSUME;

	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd11, 0x80);
	}
}

void
#ifdef __USE_PROTOS
fd_line(void)
#else
fd_line()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==FD)
 ) {
			zzmatch(FD); zzCONSUME;
		}
		else {
			if ( (LA(1)==SD) ) {
				zzmatch(SD); zzCONSUME;
			}
			else {zzFAIL(1,zzerr18,&zzMissSet,&zzMissText,&zzBadTok,&zzBadText,&zzErrk); goto fail;}
		}
		zzEXIT(zztasp2);
		}
	}
	ident();
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd12, 0x1);
	}
}

void
#ifdef __USE_PROTOS
external_line(void)
#else
external_line()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==IS) ) {
			zzmatch(IS); zzCONSUME;
		}
		zzEXIT(zztasp2);
		}
	}
	zzmatch(EXTERNAL);
	zzNON_GUESS_MODE {
	WarnNotImpl("EXTERNAL clause");   
	}
 zzCONSUME;

	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd12, 0x2);
	}
}

void
#ifdef __USE_PROTOS
global_line(void)
#else
global_line()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==IS) ) {
			zzmatch(IS); zzCONSUME;
		}
		zzEXIT(zztasp2);
		}
	}
	zzmatch(GLOBAL);
	zzNON_GUESS_MODE {
	WarnNotImpl("GLOBAL clause");   
	}
 zzCONSUME;

	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd12, 0x4);
	}
}

void
#ifdef __USE_PROTOS
block_line(void)
#else
block_line()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	zzmatch(BLOCK); zzCONSUME;
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==CONTAINS) ) {
			zzmatch(CONTAINS); zzCONSUME;
		}
		zzEXIT(zztasp2);
		}
	}
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==NUMERIC) && 
(setwd12[LA(2)]&0x8) && (LA(3)==NUMERIC) ) {
			integer();
			zzmatch(TO); zzCONSUME;
		}
		zzEXIT(zztasp2);
		}
	}
	integer();
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==RECORDS) ) {
			zzmatch(RECORDS); zzCONSUME;
		}
		else {
			if ( (LA(1)==CHARACTERS) ) {
				zzmatch(CHARACTERS); zzCONSUME;
			}
			else {zzFAIL(1,zzerr19,&zzMissSet,&zzMissText,&zzBadTok,&zzBadText,&zzErrk); goto fail;}
		}
		zzEXIT(zztasp2);
		}
	}
	zzNON_GUESS_MODE {
	WarnNotImpl("BLOCK clause");   
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd12, 0x10);
	}
}

void
#ifdef __USE_PROTOS
record_line_f(void)
#else
record_line_f()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	zzmatch(RECORD); zzCONSUME;
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==CONTAINS)
 ) {
			contains_l();
		}
		else {
			if ( (setwd12[LA(1)]&0x20) ) {
				varying_l();
			}
			else {zzFAIL(1,zzerr20,&zzMissSet,&zzMissText,&zzBadTok,&zzBadText,&zzErrk); goto fail;}
		}
		zzEXIT(zztasp2);
		}
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd12, 0x40);
	}
}

void
#ifdef __USE_PROTOS
contains_l(void)
#else
contains_l()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	zzmatch(CONTAINS); zzCONSUME;
	integer();
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==TO) ) {
			zzmatch(TO); zzCONSUME;
			integer();
		}
		zzEXIT(zztasp2);
		}
	}
	zzmatch(CHARACTERS); zzCONSUME;
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd12, 0x80);
	}
}

void
#ifdef __USE_PROTOS
varying_l(void)
#else
varying_l()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==IS) ) {
			zzmatch(IS); zzCONSUME;
		}
		zzEXIT(zztasp2);
		}
	}
	zzmatch(VARYING); zzCONSUME;
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==IN) ) {
			zzmatch(IN); zzCONSUME;
		}
		zzEXIT(zztasp2);
		}
	}
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==SIZE)
 ) {
			zzmatch(SIZE); zzCONSUME;
		}
		zzEXIT(zztasp2);
		}
	}
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (setwd13[LA(1)]&0x1) ) {
			from_l();
		}
		zzEXIT(zztasp2);
		}
	}
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==DEPENDING) ) {
			dep_l();
		}
		zzEXIT(zztasp2);
		}
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd13, 0x2);
	}
}

void
#ifdef __USE_PROTOS
from_l(void)
#else
from_l()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (setwd13[LA(1)]&0x4) ) {
			{
				zzBLOCK(zztasp3);
				zzMake0;
				{
				if ( (LA(1)==FROM) ) {
					zzmatch(FROM); zzCONSUME;
				}
				zzEXIT(zztasp3);
				}
			}
			integer();
		}
		zzEXIT(zztasp2);
		}
	}
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==TO)
 ) {
			zzmatch(TO); zzCONSUME;
			integer();
		}
		zzEXIT(zztasp2);
		}
	}
	zzmatch(CHARACTERS); zzCONSUME;
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd13, 0x8);
	}
}

void
#ifdef __USE_PROTOS
dep_l(void)
#else
dep_l()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	zzmatch(DEPENDING); zzCONSUME;
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==ON) ) {
			zzmatch(ON); zzCONSUME;
		}
		zzEXIT(zztasp2);
		}
	}
	ident();
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd13, 0x10);
	}
}

void
#ifdef __USE_PROTOS
label_line(void)
#else
label_line()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	zzmatch(LABEL); zzCONSUME;
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==RECORD) ) {
			zzmatch(RECORD); zzCONSUME;
			{
				zzBLOCK(zztasp3);
				zzMake0;
				{
				if ( (LA(1)==IS) ) {
					zzmatch(IS); zzCONSUME;
				}
				zzEXIT(zztasp3);
				}
			}
		}
		else {
			if ( (LA(1)==RECORDS) ) {
				zzmatch(RECORDS); zzCONSUME;
				{
					zzBLOCK(zztasp3);
					zzMake0;
					{
					if ( (LA(1)==ARE)
 ) {
						zzmatch(ARE); zzCONSUME;
					}
					zzEXIT(zztasp3);
					}
				}
			}
			else {zzFAIL(1,zzerr21,&zzMissSet,&zzMissText,&zzBadTok,&zzBadText,&zzErrk); goto fail;}
		}
		zzEXIT(zztasp2);
		}
	}
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==STANDARD) ) {
			zzmatch(STANDARD); zzCONSUME;
		}
		else {
			if ( (LA(1)==OMITTED) ) {
				zzmatch(OMITTED); zzCONSUME;
			}
			else {zzFAIL(1,zzerr22,&zzMissSet,&zzMissText,&zzBadTok,&zzBadText,&zzErrk); goto fail;}
		}
		zzEXIT(zztasp2);
		}
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd13, 0x20);
	}
}

void
#ifdef __USE_PROTOS
value_line(void)
#else
value_line()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	zzmatch(VALUE); zzCONSUME;
	zzmatch(OF); zzCONSUME;
	{
		zzBLOCK(zztasp2);
		int zzcnt=1;
		zzMake0;
		{
		do {
			implementor_name();
			{
				zzBLOCK(zztasp3);
				zzMake0;
				{
				if ( (LA(1)==IS) ) {
					zzmatch(IS); zzCONSUME;
				}
				zzEXIT(zztasp3);
				}
			}
			{
				zzBLOCK(zztasp3);
				zzMake0;
				{
				if ( (LA(1)==PROG_NAME) ) {
					ident();
				}
				else {
					if ( (LA(1)==NONNUMERIC)
 ) {
						string_literal();
					}
					else {zzFAIL(1,zzerr23,&zzMissSet,&zzMissText,&zzBadTok,&zzBadText,&zzErrk); goto fail;}
				}
				zzEXIT(zztasp3);
				}
			}
			zzLOOP(zztasp2);
		} while ( (LA(1)==NONNUMERIC) );
		zzEXIT(zztasp2);
		}
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd13, 0x40);
	}
}

void
#ifdef __USE_PROTOS
data_line(void)
#else
data_line()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	zzmatch(DATA); zzCONSUME;
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==RECORD) ) {
			zzmatch(RECORD); zzCONSUME;
			{
				zzBLOCK(zztasp3);
				zzMake0;
				{
				if ( (LA(1)==IS) ) {
					zzmatch(IS); zzCONSUME;
				}
				zzEXIT(zztasp3);
				}
			}
		}
		else {
			if ( (LA(1)==RECORDS) ) {
				zzmatch(RECORDS); zzCONSUME;
				{
					zzBLOCK(zztasp3);
					zzMake0;
					{
					if ( (LA(1)==ARE)
 ) {
						zzmatch(ARE); zzCONSUME;
					}
					zzEXIT(zztasp3);
					}
				}
			}
			else {zzFAIL(1,zzerr24,&zzMissSet,&zzMissText,&zzBadTok,&zzBadText,&zzErrk); goto fail;}
		}
		zzEXIT(zztasp2);
		}
	}
	{
		zzBLOCK(zztasp2);
		int zzcnt=1;
		zzMake0;
		{
		do {
			ident();
			zzLOOP(zztasp2);
		} while ( (LA(1)==PROG_NAME) );
		zzEXIT(zztasp2);
		}
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd13, 0x80);
	}
}

void
#ifdef __USE_PROTOS
linage_foot(void)
#else
linage_foot()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==WITH) ) {
			zzmatch(WITH); zzCONSUME;
		}
		zzEXIT(zztasp2);
		}
	}
	zzmatch(FOOTING); zzCONSUME;
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==AT) ) {
			zzmatch(AT); zzCONSUME;
		}
		zzEXIT(zztasp2);
		}
	}
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==PROG_NAME) ) {
			ident();
		}
		else {
			if ( (LA(1)==NUMERIC)
 ) {
				integer();
			}
			else {zzFAIL(1,zzerr25,&zzMissSet,&zzMissText,&zzBadTok,&zzBadText,&zzErrk); goto fail;}
		}
		zzEXIT(zztasp2);
		}
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd14, 0x1);
	}
}

void
#ifdef __USE_PROTOS
linage_l(void)
#else
linage_l()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==LINES) ) {
			zzmatch(LINES); zzCONSUME;
		}
		zzEXIT(zztasp2);
		}
	}
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==AT) ) {
			zzmatch(AT); zzCONSUME;
		}
		zzEXIT(zztasp2);
		}
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd14, 0x2);
	}
}

void
#ifdef __USE_PROTOS
code_set_line(void)
#else
code_set_line()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	zzmatch(CODE_SET); zzCONSUME;
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==IS) ) {
			zzmatch(IS); zzCONSUME;
		}
		zzEXIT(zztasp2);
		}
	}
	ident();
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd14, 0x4);
	}
}
