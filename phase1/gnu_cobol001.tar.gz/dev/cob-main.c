/*
 * A n t l r  T r a n s l a t i o n  H e a d e r
 *
 * Terence Parr, Will Cohen, and Hank Dietz: 1989-1994
 * Purdue University Electrical Engineering
 * With AHPCRC, University of Minnesota
 * ANTLR Version 1.33MR9
 */
#include <stdio.h>
#define ANTLR_VERSION	133MR9

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "charbuf.h"
#include "c-global.h"
#define ZZCAN_GUESS
#include <setjmp.h>
#define LL_K 4
#define zzSET_SIZE 48
#include "antlr.h"
#include "tokens.h"
#include "dlgdef.h"
#include "mode.h"
#ifndef PURIFY
#define PURIFY(r,s)
#endif
ANTLR_INFO

int     AntlrCount=0;
int	zzreal_line;

#include "setNLA.h"

void setDebug() {
#define DEBUG
}
void setMassiveDebug() {
#define MASSIVE_DEBUG
}

int main(int argc, char **argv) { 
	
	/* Command line options. */
	static	char *option_list[] = {
		"{debug}", "{massive_debug}", NULL } ;
		int	option;
		char	*argument;
		FILE	*input = NULL;
		
	if (argc == 1)
		ErrUsage(argv[0]);
		
	input = fopen(argv[1], "r");
		if (input == NULL)
		ErrInputFile(argv[1]);
		
	opt_init(argc, argv, 1, option_list, NULL);
		while(option = opt_get (NULL, &argument)) {
		switch(option) {
		case 1: setDebug();
		break;
		case 2: setMassiveDebug();
		setDebug();
		break;
	} /* switch */
} /* while */

again:	ANTLR(main_structure(), input); 
fclose(input);
return 0;
} 

#define LANL(i) (*LATEXT(i) == '\n' ? "NL" : LATEXT(i))

  

void
#ifdef __USE_PROTOS
main_structure(void)
#else
main_structure()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	identification_division();
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==ENVIRONMENT) ) {
			environment_division();
		}
		zzEXIT(zztasp2);
		}
	}
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==DATA) ) {
			data_division();
		}
		zzEXIT(zztasp2);
		}
	}
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==PROCEDURE) ) {
			procedure_division();
		}
		zzEXIT(zztasp2);
		}
	}
	zzmatch(1); zzCONSUME;
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd1, 0x1);
	}
}
