/*
 * A n t l r  T r a n s l a t i o n  H e a d e r
 *
 * Terence Parr, Will Cohen, and Hank Dietz: 1989-1994
 * Purdue University Electrical Engineering
 * With AHPCRC, University of Minnesota
 * ANTLR Version 1.33MR9
 */
#include <stdio.h>
#define ANTLR_VERSION	133MR9

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "charbuf.h"
#include "c-global.h"
#define ZZCAN_GUESS
#include <setjmp.h>
#define LL_K 4
#define zzSET_SIZE 48
#include "antlr.h"
#include "tokens.h"
#include "dlgdef.h"
#include "mode.h"
#ifndef PURIFY
#define PURIFY(r,s)
#endif

void
#ifdef __USE_PROTOS
record_descr(void)
#else
record_descr()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	level_number();
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==PROG_NAME) ) {
			ident();
			zzNON_GUESS_MODE {
			strcpy(DDIdent, Ident);   
			}
		}
		else {
			if ( (setwd14[LA(1)]&0x8)
 ) {
				{
					zzBLOCK(zztasp3);
					zzMake0;
					{
					if ( (LA(1)==FILLER) ) {
						zzmatch(FILLER); zzCONSUME;
					}
					zzEXIT(zztasp3);
					}
				}
				zzNON_GUESS_MODE {
				strcpy(DDIdent, "");   
				}
			}
			else {zzFAIL(1,zzerr26,&zzMissSet,&zzMissText,&zzBadTok,&zzBadText,&zzErrk); goto fail;}
		}
		zzEXIT(zztasp2);
		}
	}
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		while ( 1 ) {
			if ( !((setwd14[LA(1)]&0x10))) break;
			if ( (LA(1)==REDEFINES) ) {
				redefines_line();
				zzNON_GUESS_MODE {
				CheckFlag(&data_descr_flags, DD_REDEFINES, "REDEFINES");   
				}
			}
			else {
				if ( (setwd14[LA(1)]&0x20) && (setwd14[LA(2)]&0x40)
 ) {
					external_line_r();
					zzNON_GUESS_MODE {
					CheckFlag(&data_descr_flags, DD_EXTERNAL, "EXTERNAL");   
					}
				}
				else {
					if ( (LA(1)==IS) && (LA(2)==GLOBAL) ) {
						global_line_r();
						zzNON_GUESS_MODE {
						CheckFlag(&data_descr_flags, DD_GLOBAL, "GLOBAL");   
						}
					}
					else {
						if ( (LA(1)==PICTURE) ) {
							picture_line();
							zzNON_GUESS_MODE {
							CheckFlag(&data_descr_flags, DD_PICTURE, "PICTURE");   
							}
						}
						else {
							if ( (setwd14[LA(1)]&0x80) ) {
								usage_line();
								zzNON_GUESS_MODE {
								CheckFlag(&data_descr_flags, DD_USAGE, "USAGE");   
								}
							}
							else {
								if ( (setwd15[LA(1)]&0x1)
 ) {
									sign_line();
									zzNON_GUESS_MODE {
									CheckFlag(&data_descr_flags, DD_SIGN, "SIGN");   
									}
								}
								else {
									if ( (setwd15[LA(1)]&0x2) ) {
										sync_line();
										zzNON_GUESS_MODE {
										CheckFlag(&data_descr_flags, DD_SYNC, "SYNC");   
										}
									}
									else {
										if ( (setwd15[LA(1)]&0x4) ) {
											just_line();
											zzNON_GUESS_MODE {
											CheckFlag(&data_descr_flags, DD_JUST, "JUST");   
											}
										}
										else {
											if ( (LA(1)==BLANK) ) {
												blank_line();
												zzNON_GUESS_MODE {
												CheckFlag(&data_descr_flags, DD_BLANK, "BLANK");   
												}
											}
											else {
												if ( (LA(1)==VALUE) ) {
													value_line_r();
													zzNON_GUESS_MODE {
													CheckFlag(&data_descr_flags, DD_VALUE, "VALUE");   
													}
												}
												else {
													if ( (LA(1)==RENAMES)
 ) {
														renames_line_r();
													}
													else break; /* MR6 code for exiting loop "for sure" */
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
			zzLOOP(zztasp2);
		}
		zzEXIT(zztasp2);
		}
	}
	zzmatch(PERIOD);
	zzNON_GUESS_MODE {
	
	RecordDescrActions(); 
	ResetGlobals();
	ResetFlag(&data_descr_flags); 
	}
 zzCONSUME;

	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd15, 0x8);
	}
}

void
#ifdef __USE_PROTOS
redefines_line(void)
#else
redefines_line()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	zzmatch(REDEFINES); zzCONSUME;
	ident();
	zzNON_GUESS_MODE {
	WarnNotImpl("REDEFINES clause");   
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd15, 0x10);
	}
}

void
#ifdef __USE_PROTOS
external_line_r(void)
#else
external_line_r()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==IS) ) {
			zzmatch(IS); zzCONSUME;
		}
		zzEXIT(zztasp2);
		}
	}
	zzmatch(EXTERNAL);
	zzNON_GUESS_MODE {
	WarnNotImpl("EXTERNAL clause");   
	}
 zzCONSUME;

	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd15, 0x20);
	}
}

void
#ifdef __USE_PROTOS
global_line_r(void)
#else
global_line_r()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	zzmatch(IS); zzCONSUME;
	zzmatch(GLOBAL);
	zzNON_GUESS_MODE {
	WarnNotImpl("IS GLOBAL clause");   
	}
 zzCONSUME;

	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd15, 0x40);
	}
}

void
#ifdef __USE_PROTOS
picture_line(void)
#else
picture_line()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	zzmatch(PICTURE); zzCONSUME;
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==IS) ) {
			zzmatch(IS); zzCONSUME;
		}
		zzEXIT(zztasp2);
		}
	}
	pic_defn();
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd15, 0x80);
	}
}

void
#ifdef __USE_PROTOS
usage_line(void)
#else
usage_line()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==USAGE) ) {
			zzmatch(USAGE); zzCONSUME;
			{
				zzBLOCK(zztasp3);
				zzMake0;
				{
				if ( (LA(1)==IS) ) {
					zzmatch(IS); zzCONSUME;
				}
				zzEXIT(zztasp3);
				}
			}
		}
		zzEXIT(zztasp2);
		}
	}
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==BINARY)
 ) {
			zzmatch(BINARY); zzCONSUME;
		}
		else {
			if ( (LA(1)==DISPLAY) ) {
				zzmatch(DISPLAY); zzCONSUME;
			}
			else {
				if ( (LA(1)==INDEX) ) {
					zzmatch(INDEX); zzCONSUME;
				}
				else {
					if ( (LA(1)==PACKED_DECIMAL) ) {
						zzmatch(PACKED_DECIMAL); zzCONSUME;
					}
					else {zzFAIL(1,zzerr27,&zzMissSet,&zzMissText,&zzBadTok,&zzBadText,&zzErrk); goto fail;}
				}
			}
		}
		zzEXIT(zztasp2);
		}
	}
	zzNON_GUESS_MODE {
	WarnNotImpl("USAGE clause");   
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd16, 0x1);
	}
}

void
#ifdef __USE_PROTOS
sign_line(void)
#else
sign_line()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==SIGN) ) {
			zzmatch(SIGN); zzCONSUME;
			{
				zzBLOCK(zztasp3);
				zzMake0;
				{
				if ( (LA(1)==IS)
 ) {
					zzmatch(IS); zzCONSUME;
				}
				zzEXIT(zztasp3);
				}
			}
		}
		zzEXIT(zztasp2);
		}
	}
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==LEADING) ) {
			zzmatch(LEADING); zzCONSUME;
		}
		else {
			if ( (LA(1)==TRAILING) ) {
				zzmatch(TRAILING); zzCONSUME;
			}
			else {zzFAIL(1,zzerr28,&zzMissSet,&zzMissText,&zzBadTok,&zzBadText,&zzErrk); goto fail;}
		}
		zzEXIT(zztasp2);
		}
	}
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==SEPERATE) ) {
			zzmatch(SEPERATE); zzCONSUME;
			{
				zzBLOCK(zztasp3);
				zzMake0;
				{
				if ( (LA(1)==CHARACTER) ) {
					zzmatch(CHARACTER); zzCONSUME;
				}
				zzEXIT(zztasp3);
				}
			}
		}
		zzEXIT(zztasp2);
		}
	}
	zzNON_GUESS_MODE {
	WarnNotImpl("SIGN IS clause");   
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd16, 0x2);
	}
}

void
#ifdef __USE_PROTOS
sync_line(void)
#else
sync_line()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==SYNC)
 ) {
			zzmatch(SYNC); zzCONSUME;
		}
		else {
			if ( (LA(1)==SYNCHRONIZED) ) {
				zzmatch(SYNCHRONIZED); zzCONSUME;
			}
			else {zzFAIL(1,zzerr29,&zzMissSet,&zzMissText,&zzBadTok,&zzBadText,&zzErrk); goto fail;}
		}
		zzEXIT(zztasp2);
		}
	}
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==LEFT) ) {
			zzmatch(LEFT); zzCONSUME;
		}
		else {
			if ( (LA(1)==RIGHT) ) {
				zzmatch(RIGHT); zzCONSUME;
			}
		}
		zzEXIT(zztasp2);
		}
	}
	zzNON_GUESS_MODE {
	WarnNotImpl("SYNC clause");   
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd16, 0x4);
	}
}

void
#ifdef __USE_PROTOS
just_line(void)
#else
just_line()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==JUST) ) {
			zzmatch(JUST); zzCONSUME;
		}
		else {
			if ( (LA(1)==JUSTIFIED)
 ) {
				zzmatch(JUSTIFIED); zzCONSUME;
			}
			else {zzFAIL(1,zzerr30,&zzMissSet,&zzMissText,&zzBadTok,&zzBadText,&zzErrk); goto fail;}
		}
		zzEXIT(zztasp2);
		}
	}
	zzmatch(RIGHT); zzCONSUME;
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd16, 0x8);
	}
}

void
#ifdef __USE_PROTOS
blank_line(void)
#else
blank_line()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	zzmatch(BLANK); zzCONSUME;
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==WHEN) ) {
			zzmatch(WHEN); zzCONSUME;
		}
		zzEXIT(zztasp2);
		}
	}
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==ZERO) ) {
			zzmatch(ZERO); zzCONSUME;
		}
		else {
			if ( (LA(1)==ZEROES) ) {
				zzmatch(ZEROES); zzCONSUME;
			}
			else {
				if ( (LA(1)==ZEROS) ) {
					zzmatch(ZEROS); zzCONSUME;
				}
				else {zzFAIL(1,zzerr31,&zzMissSet,&zzMissText,&zzBadTok,&zzBadText,&zzErrk); goto fail;}
			}
		}
		zzEXIT(zztasp2);
		}
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd16, 0x10);
	}
}

void
#ifdef __USE_PROTOS
value_line_r(void)
#else
value_line_r()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	zzmatch(VALUE); zzCONSUME;
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==IS)
 ) {
			zzmatch(IS); zzCONSUME;
		}
		zzEXIT(zztasp2);
		}
	}
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==NONNUMERIC) ) {
			string_literal();
			zzNON_GUESS_MODE {
			strcpy(DDValue_s, StringLiteral);   
			}
		}
		else {
			if ( (LA(1)==NUMERIC) ) {
				numeric();
				zzNON_GUESS_MODE {
				strcpy(DDValue_s, zzlextext);
				DDValue_n = Numeric;   
				}
			}
			else {
				if ( (LA(1)==ZERO) ) {
					zzmatch(ZERO); zzCONSUME;
				}
				else {
					if ( (LA(1)==ZEROES) ) {
						zzmatch(ZEROES); zzCONSUME;
					}
					else {
						if ( (LA(1)==ZEROS)
 ) {
							zzmatch(ZEROS);
							zzNON_GUESS_MODE {
							CheckFlag(&data_descr_flags, DD_ZEROES, "ZEROES");   
							}
 zzCONSUME;

						}
						else {
							if ( (LA(1)==SPACES) ) {
								zzmatch(SPACES);
								zzNON_GUESS_MODE {
								CheckFlag(&data_descr_flags, DD_SPACES, "SPACES");   
								}
 zzCONSUME;

							}
							else {zzFAIL(1,zzerr32,&zzMissSet,&zzMissText,&zzBadTok,&zzBadText,&zzErrk); goto fail;}
						}
					}
				}
			}
		}
		zzEXIT(zztasp2);
		}
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd16, 0x20);
	}
}

void
#ifdef __USE_PROTOS
renames_line_r(void)
#else
renames_line_r()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	zzmatch(RENAMES);
	zzNON_GUESS_MODE {
	WarnNotImpl("66 level definition");
	if ( DDLevel != 66 )
	ErrLevel(66, "Wrong Level Number for clause");
	}
 zzCONSUME;

	ident();
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (setwd16[LA(1)]&0x40) ) {
			{
				zzBLOCK(zztasp3);
				zzMake0;
				{
				if ( (LA(1)==THRU) ) {
					zzmatch(THRU); zzCONSUME;
				}
				else {
					if ( (LA(1)==THROUGH) ) {
						zzmatch(THROUGH); zzCONSUME;
					}
					else {zzFAIL(1,zzerr33,&zzMissSet,&zzMissText,&zzBadTok,&zzBadText,&zzErrk); goto fail;}
				}
				zzEXIT(zztasp3);
				}
			}
			ident();
		}
		zzEXIT(zztasp2);
		}
	}
	zzmatch(PERIOD); zzCONSUME;
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd16, 0x80);
	}
}

void
#ifdef __USE_PROTOS
g88_level_descr(void)
#else
g88_level_descr()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	level_number();
	ident();
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==VALUE)
 ) {
			zzmatch(VALUE); zzCONSUME;
			{
				zzBLOCK(zztasp3);
				zzMake0;
				{
				if ( (LA(1)==IS) ) {
					zzmatch(IS); zzCONSUME;
				}
				zzEXIT(zztasp3);
				}
			}
		}
		else {
			if ( (LA(1)==VALUES) ) {
				zzmatch(VALUES); zzCONSUME;
				{
					zzBLOCK(zztasp3);
					zzMake0;
					{
					if ( (LA(1)==ARE) ) {
						zzmatch(ARE); zzCONSUME;
					}
					zzEXIT(zztasp3);
					}
				}
			}
			else {zzFAIL(1,zzerr34,&zzMissSet,&zzMissText,&zzBadTok,&zzBadText,&zzErrk); goto fail;}
		}
		zzEXIT(zztasp2);
		}
	}
	{
		zzBLOCK(zztasp2);
		int zzcnt=1;
		zzMake0;
		{
		do {
			zzmatch(CHAR_STRING); zzCONSUME;
			{
				zzBLOCK(zztasp3);
				zzMake0;
				{
				if ( (setwd17[LA(1)]&0x1) ) {
					{
						zzBLOCK(zztasp4);
						zzMake0;
						{
						if ( (LA(1)==THRU)
 ) {
							zzmatch(THRU); zzCONSUME;
						}
						else {
							if ( (LA(1)==THROUGH) ) {
								zzmatch(THROUGH); zzCONSUME;
							}
							else {zzFAIL(1,zzerr35,&zzMissSet,&zzMissText,&zzBadTok,&zzBadText,&zzErrk); goto fail;}
						}
						zzEXIT(zztasp4);
						}
					}
					zzmatch(CHAR_STRING); zzCONSUME;
				}
				zzEXIT(zztasp3);
				}
			}
			zzLOOP(zztasp2);
		} while ( (LA(1)==CHAR_STRING) );
		zzEXIT(zztasp2);
		}
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd17, 0x2);
	}
}
