/*
 * A n t l r  T r a n s l a t i o n  H e a d e r
 *
 * Terence Parr, Will Cohen, and Hank Dietz: 1989-1994
 * Purdue University Electrical Engineering
 * With AHPCRC, University of Minnesota
 * ANTLR Version 1.33MR9
 */
#include <stdio.h>
#define ANTLR_VERSION	133MR9

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "charbuf.h"
#include "c-global.h"
#define ZZCAN_GUESS
#include <setjmp.h>
#define LL_K 4
#define zzSET_SIZE 48
#include "antlr.h"
#include "tokens.h"
#include "dlgdef.h"
#include "mode.h"
#ifndef PURIFY
#define PURIFY(r,s)
#endif

void
#ifdef __USE_PROTOS
relation(void)
#else
relation()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==IS) ) {
			zzmatch(IS); zzCONSUME;
		}
		zzEXIT(zztasp2);
		}
	}
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==NOT) ) {
			zzmatch(NOT);
			zzNON_GUESS_MODE {
			SetFlag(&verb_flags, RELATION_NOT);   
			}
 zzCONSUME;

		}
		zzEXIT(zztasp2);
		}
	}
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (setwd21[LA(1)]&0x40) ) {
			geneq();
		}
		else {
			if ( (setwd21[LA(1)]&0x80) && (setwd22[LA(2)]&0x1) && 
(setwd22[LA(3)]&0x2) && (setwd22[LA(4)]&0x4) && !((LA(1)==GREATER&&((LA(2)==THAN&&((LA(3)==OR&&(LA(4)==EQUAL))))))) ) {
				gengt();
			}
			else {
				if ( (setwd22[LA(1)]&0x8) && 
(setwd22[LA(2)]&0x10) && (setwd22[LA(3)]&0x20) && (setwd22[LA(4)]&0x40) && !((LA(1)==LESS&&((LA(2)==THAN&&((LA(3)==OR&&
(LA(4)==EQUAL))))))) ) {
					genlt();
				}
				else {
					if ( (setwd22[LA(1)]&0x80) && (setwd23[LA(2)]&0x1) && (setwd23[LA(3)]&0x2) && (setwd23[LA(4)]&0x4) ) {
						genge();
					}
					else {
						if ( (setwd23[LA(1)]&0x8) && (setwd23[LA(2)]&0x10) && 
(setwd23[LA(3)]&0x20) && (setwd23[LA(4)]&0x40) ) {
							genle();
						}
						else {zzFAIL(4,zzerr49,zzerr50,zzerr51,zzerr52,&zzMissSet,&zzMissText,&zzBadTok,&zzBadText,&zzErrk); goto fail;}
					}
				}
			}
		}
		zzEXIT(zztasp2);
		}
	}
	zzNON_GUESS_MODE {
	ResetFlag(&verb_flags);   
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd23, 0x80);
	}
}

void
#ifdef __USE_PROTOS
geneq(void)
#else
geneq()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==EQUAL) ) {
			zzmatch(EQUAL); zzCONSUME;
			{
				zzBLOCK(zztasp3);
				zzMake0;
				{
				if ( (LA(1)==TO) ) {
					zzmatch(TO); zzCONSUME;
				}
				zzEXIT(zztasp3);
				}
			}
		}
		else {
			if ( (LA(1)==EQUALSIGN) ) {
				zzmatch(EQUALSIGN); zzCONSUME;
			}
			else {zzFAIL(1,zzerr53,&zzMissSet,&zzMissText,&zzBadTok,&zzBadText,&zzErrk); goto fail;}
		}
		zzEXIT(zztasp2);
		}
	}
	zzNON_GUESS_MODE {
	if (verb_flags & RELATION_NOT) 
	ExprFlush("!=");
	ExprFlush("==");
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd24, 0x1);
	}
}

void
#ifdef __USE_PROTOS
gengt(void)
#else
gengt()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==GREATER)
 ) {
			zzmatch(GREATER); zzCONSUME;
			{
				zzBLOCK(zztasp3);
				zzMake0;
				{
				if ( (LA(1)==THAN) ) {
					zzmatch(THAN); zzCONSUME;
				}
				zzEXIT(zztasp3);
				}
			}
		}
		else {
			if ( (LA(1)==GREATERSIGN) ) {
				zzmatch(GREATERSIGN); zzCONSUME;
			}
			else {zzFAIL(1,zzerr54,&zzMissSet,&zzMissText,&zzBadTok,&zzBadText,&zzErrk); goto fail;}
		}
		zzEXIT(zztasp2);
		}
	}
	zzNON_GUESS_MODE {
	if (verb_flags & RELATION_NOT) ExprFlush("<");
	else ExprFlush(">");
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd24, 0x2);
	}
}

void
#ifdef __USE_PROTOS
genlt(void)
#else
genlt()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==LESS) ) {
			zzmatch(LESS); zzCONSUME;
			{
				zzBLOCK(zztasp3);
				zzMake0;
				{
				if ( (LA(1)==THAN) ) {
					zzmatch(THAN); zzCONSUME;
				}
				zzEXIT(zztasp3);
				}
			}
		}
		else {
			if ( (LA(1)==LESSSIGN)
 ) {
				zzmatch(LESSSIGN); zzCONSUME;
			}
			else {zzFAIL(1,zzerr55,&zzMissSet,&zzMissText,&zzBadTok,&zzBadText,&zzErrk); goto fail;}
		}
		zzEXIT(zztasp2);
		}
	}
	zzNON_GUESS_MODE {
	if (verb_flags & RELATION_NOT) ExprFlush(">=");
	else ExprFlush("<");
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd24, 0x4);
	}
}

void
#ifdef __USE_PROTOS
genge(void)
#else
genge()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==GREATER) ) {
			zzmatch(GREATER); zzCONSUME;
			{
				zzBLOCK(zztasp3);
				zzMake0;
				{
				if ( (LA(1)==THAN) ) {
					zzmatch(THAN); zzCONSUME;
				}
				zzEXIT(zztasp3);
				}
			}
			zzmatch(OR); zzCONSUME;
			zzmatch(EQUAL); zzCONSUME;
			{
				zzBLOCK(zztasp3);
				zzMake0;
				{
				if ( (LA(1)==TO) ) {
					zzmatch(TO); zzCONSUME;
				}
				zzEXIT(zztasp3);
				}
			}
		}
		else {
			if ( (LA(1)==GESIGN) ) {
				zzmatch(GESIGN); zzCONSUME;
			}
			else {zzFAIL(1,zzerr56,&zzMissSet,&zzMissText,&zzBadTok,&zzBadText,&zzErrk); goto fail;}
		}
		zzEXIT(zztasp2);
		}
	}
	zzNON_GUESS_MODE {
	if (verb_flags & RELATION_NOT) ExprFlush("<");
	else ExprFlush(">=");
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd24, 0x8);
	}
}

void
#ifdef __USE_PROTOS
genle(void)
#else
genle()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==LESS)
 ) {
			zzmatch(LESS); zzCONSUME;
			{
				zzBLOCK(zztasp3);
				zzMake0;
				{
				if ( (LA(1)==THAN) ) {
					zzmatch(THAN); zzCONSUME;
				}
				zzEXIT(zztasp3);
				}
			}
			zzmatch(OR); zzCONSUME;
			zzmatch(EQUAL); zzCONSUME;
			{
				zzBLOCK(zztasp3);
				zzMake0;
				{
				if ( (LA(1)==TO) ) {
					zzmatch(TO); zzCONSUME;
				}
				zzEXIT(zztasp3);
				}
			}
		}
		else {
			if ( (LA(1)==LESIGN) ) {
				zzmatch(LESIGN); zzCONSUME;
			}
			else {zzFAIL(1,zzerr57,&zzMissSet,&zzMissText,&zzBadTok,&zzBadText,&zzErrk); goto fail;}
		}
		zzEXIT(zztasp2);
		}
	}
	zzNON_GUESS_MODE {
	if (verb_flags & RELATION_NOT) ExprFlush(">");
	else ExprFlush("<=");
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd24, 0x10);
	}
}
