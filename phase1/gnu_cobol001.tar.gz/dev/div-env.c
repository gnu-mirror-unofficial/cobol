/*
 * A n t l r  T r a n s l a t i o n  H e a d e r
 *
 * Terence Parr, Will Cohen, and Hank Dietz: 1989-1994
 * Purdue University Electrical Engineering
 * With AHPCRC, University of Minnesota
 * ANTLR Version 1.33MR9
 */
#include <stdio.h>
#define ANTLR_VERSION	133MR9

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "charbuf.h"
#include "c-global.h"
#define ZZCAN_GUESS
#include <setjmp.h>
#define LL_K 4
#define zzSET_SIZE 48
#include "antlr.h"
#include "tokens.h"
#include "dlgdef.h"
#include "mode.h"
#ifndef PURIFY
#define PURIFY(r,s)
#endif

void
#ifdef __USE_PROTOS
environment_division(void)
#else
environment_division()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
#ifdef DEBUG
	fprintf(stderr, "Entering ENVIRONMENT DIVISION\n");
#endif   
	zzmatch(ENVIRONMENT); zzCONSUME;
	zzmatch(DIVISION); zzCONSUME;
	zzmatch(PERIOD); zzCONSUME;
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==CONFIGURATION)
 ) {
			config_section();
		}
		zzEXIT(zztasp2);
		}
	}
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==INPUT_OUTPUT) ) {
			io_section();
		}
		zzEXIT(zztasp2);
		}
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd3, 0x10);
	}
}

void
#ifdef __USE_PROTOS
config_section(void)
#else
config_section()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	zzmatch(CONFIGURATION); zzCONSUME;
	zzmatch(SECTION); zzCONSUME;
	zzmatch(PERIOD); zzCONSUME;
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		while ( 1 ) {
			if ( !((setwd3[LA(1)]&0x20))) break;
			if ( (LA(1)==SOURCE_COMPUTER) ) {
				src_computer_clause();
				zzNON_GUESS_MODE {
				CheckFlag(&env_div_flags, ENV_SRC_COMPUTER, "SOURCE-COMPUTER");   
				}
			}
			else {
				if ( (LA(1)==OBJECT_COMPUTER) ) {
					obj_computer_clause();
					zzNON_GUESS_MODE {
					CheckFlag(&env_div_flags, ENV_OBJ_COMPUTER, "OBJECT-COMPUTER");   
					}
				}
				else {
					if ( (LA(1)==SPECIAL_NAMES)
 ) {
						special_names();
						zzNON_GUESS_MODE {
						CheckFlag(&env_div_flags, ENV_SPECIAL_NAMES, "SPECIAL-NAMES");   
						}
					}
					else break; /* MR6 code for exiting loop "for sure" */
				}
			}
			zzLOOP(zztasp2);
		}
		zzEXIT(zztasp2);
		}
	}
	zzNON_GUESS_MODE {
	ResetFlag(&env_div_flags);   
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd3, 0x40);
	}
}

void
#ifdef __USE_PROTOS
src_computer_clause(void)
#else
src_computer_clause()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	zzmatch(SOURCE_COMPUTER); zzCONSUME;
	zzmatch(PERIOD); zzCONSUME;
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==PROG_NAME) ) {
			debug_line();
		}
		zzEXIT(zztasp2);
		}
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd3, 0x80);
	}
}

void
#ifdef __USE_PROTOS
debug_line(void)
#else
debug_line()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	ident();
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (setwd4[LA(1)]&0x1) ) {
			{
				zzBLOCK(zztasp3);
				zzMake0;
				{
				if ( (LA(1)==WITH) ) {
					zzmatch(WITH); zzCONSUME;
				}
				zzEXIT(zztasp3);
				}
			}
			zzmatch(DEBUGGING); zzCONSUME;
			zzmatch(MODE); zzCONSUME;
		}
		zzEXIT(zztasp2);
		}
	}
	zzmatch(PERIOD); zzCONSUME;
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd4, 0x2);
	}
}

void
#ifdef __USE_PROTOS
obj_computer_clause(void)
#else
obj_computer_clause()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	zzmatch(OBJECT_COMPUTER); zzCONSUME;
	zzmatch(PERIOD); zzCONSUME;
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==PROG_NAME) ) {
			obj_suppl_line();
		}
		zzEXIT(zztasp2);
		}
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd4, 0x4);
	}
}

void
#ifdef __USE_PROTOS
obj_suppl_line(void)
#else
obj_suppl_line()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	ident();
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (setwd4[LA(1)]&0x8)
 ) {
			collating_line();
		}
		zzEXIT(zztasp2);
		}
	}
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==SEGMENT_LIMIT) ) {
			segment_line();
		}
		zzEXIT(zztasp2);
		}
	}
	zzmatch(PERIOD); zzCONSUME;
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd4, 0x10);
	}
}

void
#ifdef __USE_PROTOS
collating_line(void)
#else
collating_line()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==PROGRAM) ) {
			zzmatch(PROGRAM); zzCONSUME;
		}
		zzEXIT(zztasp2);
		}
	}
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==COLLATING) ) {
			zzmatch(COLLATING); zzCONSUME;
		}
		zzEXIT(zztasp2);
		}
	}
	zzmatch(SEQUENCE); zzCONSUME;
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==IS) ) {
			zzmatch(IS); zzCONSUME;
		}
		zzEXIT(zztasp2);
		}
	}
	ident();
	zzNON_GUESS_MODE {
	CheckFlag(&env_div_flags, ENV_COLL_SEQUENCE, "SEQUENCE");   
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd4, 0x20);
	}
}

void
#ifdef __USE_PROTOS
segment_line(void)
#else
segment_line()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	zzmatch(SEGMENT_LIMIT); zzCONSUME;
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==IS)
 ) {
			zzmatch(IS); zzCONSUME;
		}
		zzEXIT(zztasp2);
		}
	}
	ident();
	zzNON_GUESS_MODE {
	CheckFlag(&env_div_flags, ENV_SEGMENT_LIMIT, "SEGMENT-LIMIT");   
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd4, 0x40);
	}
}

void
#ifdef __USE_PROTOS
special_names(void)
#else
special_names()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	zzmatch(SPECIAL_NAMES); zzCONSUME;
	zzmatch(PERIOD); zzCONSUME;
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		while ( (setwd4[LA(1)]&0x80) ) {
			{
				zzBLOCK(zztasp3);
				zzMake0;
				{
				if ( (LA(1)==CURRENCY) ) {
					currency_clause();
					zzNON_GUESS_MODE {
					CheckFlag(&env_div_flags, ENV_CURRENCY, "CURRENCY");   
					}
				}
				else {
					if ( (LA(1)==DECIMAL_POINT) ) {
						decimal_clause();
						zzNON_GUESS_MODE {
						CheckFlag(&env_div_flags, ENV_DECIMAL, "DECIMAL");   
						}
					}
					else {zzFAIL(1,zzerr6,&zzMissSet,&zzMissText,&zzBadTok,&zzBadText,&zzErrk); goto fail;}
				}
				zzEXIT(zztasp3);
				}
			}
			zzmatch(PERIOD); zzCONSUME;
			zzLOOP(zztasp2);
		}
		zzEXIT(zztasp2);
		}
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd5, 0x1);
	}
}

void
#ifdef __USE_PROTOS
currency_clause(void)
#else
currency_clause()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	zzmatch(CURRENCY); zzCONSUME;
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==SIGN) ) {
			zzmatch(SIGN); zzCONSUME;
		}
		zzEXIT(zztasp2);
		}
	}
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==IS)
 ) {
			zzmatch(IS); zzCONSUME;
		}
		zzEXIT(zztasp2);
		}
	}
	lit_char();
	zzNON_GUESS_MODE {
	WarnNotImpl("CURRENCY");   
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd5, 0x2);
	}
}

void
#ifdef __USE_PROTOS
decimal_clause(void)
#else
decimal_clause()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	zzmatch(DECIMAL_POINT); zzCONSUME;
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==IS) ) {
			zzmatch(IS); zzCONSUME;
		}
		zzEXIT(zztasp2);
		}
	}
	zzmatch(COMMA);
	zzNON_GUESS_MODE {
	WarnNotImpl("DECIMAL-POINT");   
	}
 zzCONSUME;

	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd5, 0x4);
	}
}

void
#ifdef __USE_PROTOS
class_clause(void)
#else
class_clause()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	zzmatch(CLASS); zzCONSUME;
	ident();
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==IS) ) {
			zzmatch(IS); zzCONSUME;
		}
		zzEXIT(zztasp2);
		}
	}
	{
		zzBLOCK(zztasp2);
		int zzcnt=1;
		zzMake0;
		{
		do {
			ident();
			{
				zzBLOCK(zztasp3);
				zzMake0;
				{
				if ( (setwd5[LA(1)]&0x8) ) {
					{
						zzBLOCK(zztasp4);
						zzMake0;
						{
						if ( (LA(1)==THROUGH) ) {
							zzmatch(THROUGH); zzCONSUME;
						}
						else {
							if ( (LA(1)==THRU)
 ) {
								zzmatch(THRU); zzCONSUME;
							}
							else {zzFAIL(1,zzerr7,&zzMissSet,&zzMissText,&zzBadTok,&zzBadText,&zzErrk); goto fail;}
						}
						zzEXIT(zztasp4);
						}
					}
					ident();
				}
				zzEXIT(zztasp3);
				}
			}
			zzLOOP(zztasp2);
		} while ( (LA(1)==PROG_NAME) );
		zzEXIT(zztasp2);
		}
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd5, 0x10);
	}
}

void
#ifdef __USE_PROTOS
symbolic_clause(void)
#else
symbolic_clause()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	zzmatch(SYMBOLIC); zzCONSUME;
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==CHARACTERS) ) {
			zzmatch(CHARACTERS); zzCONSUME;
		}
		zzEXIT(zztasp2);
		}
	}
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==NONNUMERIC) ) {
			{
				zzBLOCK(zztasp3);
				int zzcnt=1;
				zzMake0;
				{
				do {
					sym_char();
					zzLOOP(zztasp3);
				} while ( (LA(1)==NONNUMERIC) );
				zzEXIT(zztasp3);
				}
			}
		}
		else {
			if ( (LA(1)==IN)
 ) {
				zzmatch(IN); zzCONSUME;
				ident();
			}
			else {zzFAIL(1,zzerr8,&zzMissSet,&zzMissText,&zzBadTok,&zzBadText,&zzErrk); goto fail;}
		}
		zzEXIT(zztasp2);
		}
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd5, 0x20);
	}
}

void
#ifdef __USE_PROTOS
sym_char_clause(void)
#else
sym_char_clause()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	{
		zzBLOCK(zztasp2);
		int zzcnt=1;
		zzMake0;
		{
		do {
			sym_char();
			zzLOOP(zztasp2);
		} while ( (LA(1)==NONNUMERIC) );
		zzEXIT(zztasp2);
		}
	}
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==IS) ) {
			zzmatch(IS); zzCONSUME;
		}
		else {
			if ( (LA(1)==ARE) ) {
				zzmatch(ARE); zzCONSUME;
			}
			else {zzFAIL(1,zzerr9,&zzMissSet,&zzMissText,&zzBadTok,&zzBadText,&zzErrk); goto fail;}
		}
		zzEXIT(zztasp2);
		}
	}
	{
		zzBLOCK(zztasp2);
		int zzcnt=1;
		zzMake0;
		{
		do {
			integer();
			zzLOOP(zztasp2);
		} while ( (LA(1)==NUMERIC) );
		zzEXIT(zztasp2);
		}
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd5, 0x40);
	}
}

void
#ifdef __USE_PROTOS
alphabet_clause(void)
#else
alphabet_clause()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	zzmatch(ALPHABET); zzCONSUME;
	ident();
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==IS)
 ) {
			zzmatch(IS); zzCONSUME;
		}
		zzEXIT(zztasp2);
		}
	}
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==ASCII) ) {
			zzmatch(ASCII); zzCONSUME;
		}
		else {
			if ( (LA(1)==EBCIDIC) ) {
				zzmatch(EBCIDIC); zzCONSUME;
			}
			else {zzFAIL(1,zzerr10,&zzMissSet,&zzMissText,&zzBadTok,&zzBadText,&zzErrk); goto fail;}
		}
		zzEXIT(zztasp2);
		}
	}
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==STANDARD_1) ) {
			zzmatch(STANDARD_1); zzCONSUME;
		}
		else {
			if ( (LA(1)==STANDARD_2) ) {
				zzmatch(STANDARD_2); zzCONSUME;
			}
			else {
				if ( (LA(1)==NATIVE)
 ) {
					zzmatch(NATIVE); zzCONSUME;
				}
				else {
					if ( (LA(1)==PROG_NAME) ) {
						ident();
					}
					else {
						if ( (LA(1)==NONNUMERIC) ) {
							{
								zzBLOCK(zztasp3);
								int zzcnt=1;
								zzMake0;
								{
								do {
									alpha_literal_list();
									zzLOOP(zztasp3);
								} while ( (LA(1)==NONNUMERIC) );
								zzEXIT(zztasp3);
								}
							}
						}
						else {zzFAIL(1,zzerr11,&zzMissSet,&zzMissText,&zzBadTok,&zzBadText,&zzErrk); goto fail;}
					}
				}
			}
		}
		zzEXIT(zztasp2);
		}
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd5, 0x80);
	}
}

void
#ifdef __USE_PROTOS
alpha_literal_list(void)
#else
alpha_literal_list()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	lit_char();
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (setwd6[LA(1)]&0x1) ) {
			{
				zzBLOCK(zztasp3);
				zzMake0;
				{
				if ( (LA(1)==THROUGH)
 ) {
					zzmatch(THROUGH); zzCONSUME;
				}
				else {
					if ( (LA(1)==THRU) ) {
						zzmatch(THRU); zzCONSUME;
					}
					else {zzFAIL(1,zzerr12,&zzMissSet,&zzMissText,&zzBadTok,&zzBadText,&zzErrk); goto fail;}
				}
				zzEXIT(zztasp3);
				}
			}
			lit_char();
		}
		else {
			if ( (LA(1)==ALSO) ) {
				{
					zzBLOCK(zztasp3);
					int zzcnt=1;
					zzMake0;
					{
					do {
						zzmatch(ALSO); zzCONSUME;
						lit_char();
						zzLOOP(zztasp3);
					} while ( (LA(1)==ALSO) );
					zzEXIT(zztasp3);
					}
				}
			}
		}
		zzEXIT(zztasp2);
		}
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd6, 0x2);
	}
}

void
#ifdef __USE_PROTOS
implementor_clause(void)
#else
implementor_clause()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	ident();
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==IS) ) {
			zzmatch(IS); zzCONSUME;
			ident();
		}
		zzEXIT(zztasp2);
		}
	}
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==ON)
 ) {
			on_off();
		}
		else {
			if ( (LA(1)==OFF) ) {
				off_on();
			}
			else {zzFAIL(1,zzerr13,&zzMissSet,&zzMissText,&zzBadTok,&zzBadText,&zzErrk); goto fail;}
		}
		zzEXIT(zztasp2);
		}
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd6, 0x4);
	}
}

void
#ifdef __USE_PROTOS
on_off(void)
#else
on_off()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	on_status_clause();
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==OFF) ) {
			off_status_clause();
		}
		zzEXIT(zztasp2);
		}
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd6, 0x8);
	}
}

void
#ifdef __USE_PROTOS
off_on(void)
#else
off_on()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	off_status_clause();
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==ON) ) {
			on_status_clause();
		}
		zzEXIT(zztasp2);
		}
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd6, 0x10);
	}
}

void
#ifdef __USE_PROTOS
on_status_clause(void)
#else
on_status_clause()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	zzmatch(ON); zzCONSUME;
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==STATUS) ) {
			zzmatch(STATUS); zzCONSUME;
		}
		zzEXIT(zztasp2);
		}
	}
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==IS)
 ) {
			zzmatch(IS); zzCONSUME;
		}
		zzEXIT(zztasp2);
		}
	}
	ident();
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd6, 0x20);
	}
}

void
#ifdef __USE_PROTOS
off_status_clause(void)
#else
off_status_clause()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	zzmatch(OFF); zzCONSUME;
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==STATUS) ) {
			zzmatch(STATUS); zzCONSUME;
		}
		zzEXIT(zztasp2);
		}
	}
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==IS) ) {
			zzmatch(IS); zzCONSUME;
		}
		zzEXIT(zztasp2);
		}
	}
	ident();
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd6, 0x40);
	}
}
