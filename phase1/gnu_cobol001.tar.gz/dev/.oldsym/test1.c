

#include "symtable.h"
#include <stdio.h>
#include <stdlib.h>


int main() {

	Entry* e = NULL;
	int rc;

	rc = SymTableInit();
	if ( rc != 0 )
		printf("Iit failed\n");

	rc = SymEntryNew( e ); 
	if (rc != 0 )
		printf("Entry create failed\n");

	SymEntryDelete( e );
	
	exit(9);
}
