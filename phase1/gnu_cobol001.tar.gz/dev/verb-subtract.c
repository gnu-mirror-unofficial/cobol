/*
 * A n t l r  T r a n s l a t i o n  H e a d e r
 *
 * Terence Parr, Will Cohen, and Hank Dietz: 1989-1994
 * Purdue University Electrical Engineering
 * With AHPCRC, University of Minnesota
 * ANTLR Version 1.33MR9
 */
#include <stdio.h>
#define ANTLR_VERSION	133MR9

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "charbuf.h"
#include "c-global.h"
#define ZZCAN_GUESS
#include <setjmp.h>
#define LL_K 4
#define zzSET_SIZE 48
#include "antlr.h"
#include "tokens.h"
#include "dlgdef.h"
#include "mode.h"
#ifndef PURIFY
#define PURIFY(r,s)
#endif

void
#ifdef __USE_PROTOS
subtract_stmt(void)
#else
subtract_stmt()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	subtract_main();
	subtract_sizing();
	subtract_ending();
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd34, 0x80);
	}
}

void
#ifdef __USE_PROTOS
subtract_sizing(void)
#else
subtract_sizing()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	zzGUESS_BLOCK
	zzGUESS
	if ( !zzrv && (setwd35[LA(1)]&0x1) ) {
		{
			zzBLOCK(zztasp2);
			zzMake0;
			{
			size_err();
			zzEXIT(zztasp2);
			}
		}
		zzGUESS_DONE
		{
			zzBLOCK(zztasp2);
			zzMake0;
			{
			size_err();
			zzEXIT(zztasp2);
			}
		}
	}
	else {
		if ( zzguessing ) zzGUESS_DONE;
		if ( (setwd35[LA(1)]&0x2)
 ) {
		}
		else {zzFAIL(1,zzerr94,&zzMissSet,&zzMissText,&zzBadTok,&zzBadText,&zzErrk); goto fail;}
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd35, 0x4);
	}
}

void
#ifdef __USE_PROTOS
subtract_ending(void)
#else
subtract_ending()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	zzGUESS_BLOCK
	zzGUESS
	if ( !zzrv && (LA(1)==END_SUBTRACT) ) {
		{
			zzBLOCK(zztasp2);
			zzMake0;
			{
			zzmatch(END_SUBTRACT); zzCONSUME;
			zzEXIT(zztasp2);
			}
		}
		zzGUESS_DONE
		{
			zzBLOCK(zztasp2);
			zzMake0;
			{
			zzmatch(END_SUBTRACT); zzCONSUME;
			zzEXIT(zztasp2);
			}
		}
	}
	else {
		if ( zzguessing ) zzGUESS_DONE;
		if ( (LA(1)==1) ) {
		}
		else {zzFAIL(1,zzerr95,&zzMissSet,&zzMissText,&zzBadTok,&zzBadText,&zzErrk); goto fail;}
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd35, 0x8);
	}
}

void
#ifdef __USE_PROTOS
subtract_main(void)
#else
subtract_main()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	zzmatch(SUBTRACT); zzCONSUME;
	sub_ident1_line();
	zzmatch(FROM); zzCONSUME;
	sub_ident2_line();
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd35, 0x10);
	}
}

void
#ifdef __USE_PROTOS
sub_ident1_line(void)
#else
sub_ident1_line()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==CORR) ) {
			zzmatch(CORR); zzCONSUME;
		}
		zzEXIT(zztasp2);
		}
	}
	{
		zzBLOCK(zztasp2);
		int zzcnt=1;
		zzMake0;
		{
		do {
			if ( (LA(1)==PROG_NAME) ) {
				ident();
			}
			else {
				if ( (LA(1)==NUMERIC)
 ) {
					numeric();
				}
				else if ( zzcnt>1 ) break; /* implied exit branch */
				else {zzFAIL(1,zzerr96,&zzMissSet,&zzMissText,&zzBadTok,&zzBadText,&zzErrk); goto fail;}
			}
			zzcnt++; zzLOOP(zztasp2);
		} while ( 1 );
		zzEXIT(zztasp2);
		}
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd35, 0x20);
	}
}

void
#ifdef __USE_PROTOS
sub_ident2_line(void)
#else
sub_ident2_line()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==PROG_NAME) ) {
			{
				zzBLOCK(zztasp3);
				int zzcnt=1;
				zzMake0;
				{
				do {
					ident();
					{
						zzBLOCK(zztasp4);
						zzMake0;
						{
						if ( (LA(1)==ROUNDED) ) {
							zzmatch(ROUNDED); zzCONSUME;
						}
						zzEXIT(zztasp4);
						}
					}
					zzLOOP(zztasp3);
				} while ( (LA(1)==PROG_NAME) );
				zzEXIT(zztasp3);
				}
			}
		}
		else {
			if ( (LA(1)==NUMERIC) ) {
				numeric();
			}
			else {zzFAIL(1,zzerr97,&zzMissSet,&zzMissText,&zzBadTok,&zzBadText,&zzErrk); goto fail;}
		}
		zzEXIT(zztasp2);
		}
	}
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==GIVING)
 ) {
			sub_giving_line();
		}
		zzEXIT(zztasp2);
		}
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd35, 0x40);
	}
}

void
#ifdef __USE_PROTOS
sub_giving_line(void)
#else
sub_giving_line()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	zzmatch(GIVING); zzCONSUME;
	{
		zzBLOCK(zztasp2);
		int zzcnt=1;
		zzMake0;
		{
		do {
			ident();
			{
				zzBLOCK(zztasp3);
				zzMake0;
				{
				if ( (LA(1)==ROUNDED) ) {
					zzmatch(ROUNDED); zzCONSUME;
				}
				zzEXIT(zztasp3);
				}
			}
			zzLOOP(zztasp2);
		} while ( (LA(1)==PROG_NAME) );
		zzEXIT(zztasp2);
		}
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd35, 0x80);
	}
}
