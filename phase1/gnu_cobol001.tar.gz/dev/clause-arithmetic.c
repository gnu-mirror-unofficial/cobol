/*
 * A n t l r  T r a n s l a t i o n  H e a d e r
 *
 * Terence Parr, Will Cohen, and Hank Dietz: 1989-1994
 * Purdue University Electrical Engineering
 * With AHPCRC, University of Minnesota
 * ANTLR Version 1.33MR9
 */
#include <stdio.h>
#define ANTLR_VERSION	133MR9

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "charbuf.h"
#include "c-global.h"
#define ZZCAN_GUESS
#include <setjmp.h>
#define LL_K 4
#define zzSET_SIZE 48
#include "antlr.h"
#include "tokens.h"
#include "dlgdef.h"
#include "mode.h"
#ifndef PURIFY
#define PURIFY(r,s)
#endif

void
#ifdef __USE_PROTOS
arith_expr(void)
#else
arith_expr()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	expr4();
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (setwd20[LA(1)]&0x2) ) {
			add_op();
			expr4();
		}
		zzEXIT(zztasp2);
		}
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd20, 0x4);
	}
}

void
#ifdef __USE_PROTOS
expr4(void)
#else
expr4()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	expr3();
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (setwd20[LA(1)]&0x8)
 ) {
			mult_op();
			expr3();
		}
		zzEXIT(zztasp2);
		}
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd20, 0x10);
	}
}

void
#ifdef __USE_PROTOS
expr3(void)
#else
expr3()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	expr2();
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==EXPONENT) ) {
			zzmatch(EXPONENT);
			zzNON_GUESS_MODE {
			ExprPow(" pow("); ExprPrint();   
			}
 zzCONSUME;

			expr2();
			zzNON_GUESS_MODE {
			ExprPow(","); ExprPrint(); ExprPow(")");   
			}
		}
		zzEXIT(zztasp2);
		}
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd20, 0x20);
	}
}

void
#ifdef __USE_PROTOS
expr2(void)
#else
expr2()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (setwd20[LA(1)]&0x40) ) {
			uni_op();
		}
		zzEXIT(zztasp2);
		}
	}
	expr1();
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd20, 0x80);
	}
}

void
#ifdef __USE_PROTOS
expr1(void)
#else
expr1()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==OPAREN) ) {
			zzmatch(OPAREN);
			zzNON_GUESS_MODE {
			ExprStringAdd("(");   
			}
 zzCONSUME;

			arith_expr();
			zzmatch(CPAREN);
			zzNON_GUESS_MODE {
			ExprStringAdd(")");   
			}
 zzCONSUME;

		}
		else {
			if ( (setwd21[LA(1)]&0x1) ) {
				expr0();
			}
			else {zzFAIL(1,zzerr45,&zzMissSet,&zzMissText,&zzBadTok,&zzBadText,&zzErrk); goto fail;}
		}
		zzEXIT(zztasp2);
		}
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd21, 0x2);
	}
}

void
#ifdef __USE_PROTOS
expr0(void)
#else
expr0()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==NUMERIC)
 ) {
			numeric();
			zzNON_GUESS_MODE {
			ExprStringAdd(Numeric_s);   
			}
		}
		else {
			if ( (LA(1)==PROG_NAME) ) {
				ident();
				zzNON_GUESS_MODE {
				ExprStringAdd(Ident);   
				}
			}
			else {zzFAIL(1,zzerr46,&zzMissSet,&zzMissText,&zzBadTok,&zzBadText,&zzErrk); goto fail;}
		}
		zzEXIT(zztasp2);
		}
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd21, 0x4);
	}
}

void
#ifdef __USE_PROTOS
uni_op(void)
#else
uni_op()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	add_op();
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd21, 0x8);
	}
}

void
#ifdef __USE_PROTOS
add_op(void)
#else
add_op()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==PLUS_OP) ) {
			zzmatch(PLUS_OP);
			zzNON_GUESS_MODE {
			ExprStringAdd(zzlextext);   
			}
 zzCONSUME;

		}
		else {
			if ( (LA(1)==MINUS_OP) ) {
				zzmatch(MINUS_OP);
				zzNON_GUESS_MODE {
				ExprStringAdd(zzlextext);   
				}
 zzCONSUME;

			}
			else {zzFAIL(1,zzerr47,&zzMissSet,&zzMissText,&zzBadTok,&zzBadText,&zzErrk); goto fail;}
		}
		zzEXIT(zztasp2);
		}
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd21, 0x10);
	}
}

void
#ifdef __USE_PROTOS
mult_op(void)
#else
mult_op()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==MULT_OP) ) {
			zzmatch(MULT_OP);
			zzNON_GUESS_MODE {
			ExprStringAdd(zzlextext);   
			}
 zzCONSUME;

		}
		else {
			if ( (LA(1)==DIV_OP)
 ) {
				zzmatch(DIV_OP);
				zzNON_GUESS_MODE {
				ExprStringAdd(zzlextext);   
				}
 zzCONSUME;

			}
			else {zzFAIL(1,zzerr48,&zzMissSet,&zzMissText,&zzBadTok,&zzBadText,&zzErrk); goto fail;}
		}
		zzEXIT(zztasp2);
		}
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd21, 0x20);
	}
}
