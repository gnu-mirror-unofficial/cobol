/*
 * A n t l r  T r a n s l a t i o n  H e a d e r
 *
 * Terence Parr, Will Cohen, and Hank Dietz: 1989-1994
 * Purdue University Electrical Engineering
 * With AHPCRC, University of Minnesota
 * ANTLR Version 1.33MR9
 */
#include <stdio.h>
#define ANTLR_VERSION	133MR9

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "charbuf.h"
#include "c-global.h"
#define ZZCAN_GUESS
#include <setjmp.h>
#define LL_K 4
#define zzSET_SIZE 48
#include "antlr.h"
#include "tokens.h"
#include "dlgdef.h"
#include "mode.h"
#ifndef PURIFY
#define PURIFY(r,s)
#endif

void
#ifdef __USE_PROTOS
data_division(void)
#else
data_division()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
#ifdef DEBUG
	fprintf(stderr, "Entering DATA DIVISION\n");
#endif   
	zzmatch(DATA); zzCONSUME;
	zzmatch(DIVISION); zzCONSUME;
	zzmatch(PERIOD); zzCONSUME;
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==FILE_C) ) {
			file_section();
		}
		zzEXIT(zztasp2);
		}
	}
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==WORKING_STORAGE) ) {
			working_storage_section();
		}
		zzEXIT(zztasp2);
		}
	}
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==LINKAGE) ) {
			linkage_section();
		}
		zzEXIT(zztasp2);
		}
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd7, 0x8);
	}
}

void
#ifdef __USE_PROTOS
file_section(void)
#else
file_section()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	zzmatch(FILE_C); zzCONSUME;
	zzmatch(SECTION); zzCONSUME;
	zzmatch(PERIOD); zzCONSUME;
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		while ( (setwd7[LA(1)]&0x10)
 ) {
			file_description();
			{
				zzBLOCK(zztasp3);
				int zzcnt=1;
				zzMake0;
				{
				do {
					record_descr();
					zzLOOP(zztasp3);
				} while ( (LA(1)==NUMERIC) );
				zzEXIT(zztasp3);
				}
			}
			zzLOOP(zztasp2);
		}
		zzEXIT(zztasp2);
		}
	}
	zzNON_GUESS_MODE {
	FlushStack();   
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd7, 0x20);
	}
}

void
#ifdef __USE_PROTOS
working_storage_section(void)
#else
working_storage_section()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	zzmatch(WORKING_STORAGE); zzCONSUME;
	zzmatch(SECTION); zzCONSUME;
	zzmatch(PERIOD);
	zzNON_GUESS_MODE {
	ResetFQN();   
	}
 zzCONSUME;

	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		while ( (LA(1)==NUMERIC) ) {
			record_descr();
			zzLOOP(zztasp2);
		}
		zzEXIT(zztasp2);
		}
	}
	zzNON_GUESS_MODE {
	FlushStack();   
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd7, 0x40);
	}
}

void
#ifdef __USE_PROTOS
linkage_section(void)
#else
linkage_section()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	zzmatch(LINKAGE); zzCONSUME;
	zzmatch(SECTION); zzCONSUME;
	zzmatch(PERIOD); zzCONSUME;
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		while ( (LA(1)==NUMERIC) ) {
			record_descr();
			zzLOOP(zztasp2);
		}
		zzEXIT(zztasp2);
		}
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd7, 0x80);
	}
}
