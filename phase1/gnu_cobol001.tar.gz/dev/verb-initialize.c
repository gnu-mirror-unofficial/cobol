/*
 * A n t l r  T r a n s l a t i o n  H e a d e r
 *
 * Terence Parr, Will Cohen, and Hank Dietz: 1989-1994
 * Purdue University Electrical Engineering
 * With AHPCRC, University of Minnesota
 * ANTLR Version 1.33MR9
 */
#include <stdio.h>
#define ANTLR_VERSION	133MR9

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "charbuf.h"
#include "c-global.h"
#define ZZCAN_GUESS
#include <setjmp.h>
#define LL_K 4
#define zzSET_SIZE 48
#include "antlr.h"
#include "tokens.h"
#include "dlgdef.h"
#include "mode.h"
#ifndef PURIFY
#define PURIFY(r,s)
#endif

void
#ifdef __USE_PROTOS
initialize_stmt(void)
#else
initialize_stmt()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	zzmatch(INITIALIZE); zzCONSUME;
	{
		zzBLOCK(zztasp2);
		int zzcnt=1;
		zzMake0;
		{
		do {
			ident();
			zzLOOP(zztasp2);
		} while ( (LA(1)==PROG_NAME) );
		zzEXIT(zztasp2);
		}
	}
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==REPLACING) ) {
			replacing_line();
		}
		zzEXIT(zztasp2);
		}
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd33, 0x2);
	}
}

void
#ifdef __USE_PROTOS
replacing_line(void)
#else
replacing_line()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	zzmatch(REPLACING); zzCONSUME;
	{
		zzBLOCK(zztasp2);
		int zzcnt=1;
		zzMake0;
		{
		do {
			target_type();
			{
				zzBLOCK(zztasp3);
				zzMake0;
				{
				if ( (LA(1)==DATA)
 ) {
					zzmatch(DATA); zzCONSUME;
				}
				zzEXIT(zztasp3);
				}
			}
			zzmatch(BY); zzCONSUME;
			new_type();
			zzLOOP(zztasp2);
		} while ( (setwd33[LA(1)]&0x4) );
		zzEXIT(zztasp2);
		}
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd33, 0x8);
	}
}

void
#ifdef __USE_PROTOS
target_type(void)
#else
target_type()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==ALPHABETIC) ) {
			zzmatch(ALPHABETIC); zzCONSUME;
		}
		else {
			if ( (LA(1)==ALPHANUMERIC) ) {
				zzmatch(ALPHANUMERIC); zzCONSUME;
			}
			else {
				if ( (LA(1)==NUMERIC_KW) ) {
					zzmatch(NUMERIC_KW); zzCONSUME;
				}
				else {
					if ( (LA(1)==ALPHANUMERIC_EDITED)
 ) {
						zzmatch(ALPHANUMERIC_EDITED); zzCONSUME;
					}
					else {
						if ( (LA(1)==NUMERIC_EDITED) ) {
							zzmatch(NUMERIC_EDITED); zzCONSUME;
						}
						else {zzFAIL(1,zzerr86,&zzMissSet,&zzMissText,&zzBadTok,&zzBadText,&zzErrk); goto fail;}
					}
				}
			}
		}
		zzEXIT(zztasp2);
		}
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd33, 0x10);
	}
}

void
#ifdef __USE_PROTOS
new_type(void)
#else
new_type()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==PROG_NAME) ) {
			ident();
		}
		else {
			if ( (LA(1)==NUMERIC) ) {
				numeric();
			}
			else {
				if ( (LA(1)==NONNUMERIC) ) {
					string_literal();
				}
				else {zzFAIL(1,zzerr87,&zzMissSet,&zzMissText,&zzBadTok,&zzBadText,&zzErrk); goto fail;}
			}
		}
		zzEXIT(zztasp2);
		}
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd33, 0x20);
	}
}
