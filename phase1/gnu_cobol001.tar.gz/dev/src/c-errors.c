/* Error handling routines for cobol */

#include <stdio.h>

#ifndef INCLUDED_C_ERRORS_H
#include "c-errors.h"
#endif
extern int zzline;
int ErrLine =0;

/**
  die()
	Bleat and die.
 */
void die() {
	fprintf(stderr, ">>ABEND<<\n");
	exit(0);
}
/**
  ErrUndefVar()
	Undefined Variable.
 */
void ErrUndefVar( char *name ) {
	fprintf(stderr, "Error: %d: Undefined Variable '%s'\n",
			 zzline, name);
	die();
}
/**
  ErrRedefVar()
	Redefined Variable.
 */
void ErrRedefVar( char *name ) {
	fprintf(stderr, "Error: %d: Variable Redefined '%s'\n",
			zzline, name);
	die();
}
/**
  ErrAlreadyDefined()
	Variable already defined.
 */
void ErrAlreadyDefined( char *name ) {
	fprintf(stderr, "Error: %d: Clause beginning '%s' already defined\n", 
			zzline, name);
	die();
}
/**
  ErrPictureDefn()
	Error in picture definition.
 */
void ErrPictureDefn( ) {
	fprintf(stderr, "Error: %d: Picture definition is invalid\n",
			zzline);
	die();
}
/**
  ErrInternal()
	Internal Error.
 */
void ErrInternal(char *s) {
	fprintf(stderr, "Error: INTERNAL!: %d: %s\n", zzline, s);
	die();
}
/**
  ErrLitChar()
	Literal character was longer than single character.
 */
void ErrLitChar(char *s) {
	fprintf(stderr, "Error: %d: Literal Character '%s' is too long\n",
			zzline, s);
	die();
}

/**
  ErrUndefFD()
	The FD entry we found has no matching select stmt.
 */
void ErrUndefFD(char *s) {
	fprintf(stderr, "Error: %d: FD entry does not have corresponding SELECT\n", 
			zzline);
	fprintf(stderr, "     : fd %s\n", s);
	die();
}
/**
  ErrLevel()
	Level number was invalid or incorrect w/ given clause
 */
void ErrLevel(int i, char *s) {
	fprintf(stderr, "Error: %d: Level number %d\n",
			zzline, i);
	fprintf(stderr, "     : %s\n", s);
	die();
}

/**
  WarnNotImpl()
	The statement parsed is not implemented
	Does NOT exit program.
 */
void WarnNotImpl(char *s) {
	fprintf(stderr, "Warning: %d: %s not yet implemented.  Ignored.\n", 
			zzline, s);
}

/**
  WarnFileNotFound()
	Warn that filename given does not exist in the current directory.
 */
void WarnFileNotFound(char *s) {
	fprintf(stderr, "Warning: %d: File Not Found %s\n", zzline, s);
}

/**
  ErrIdentTooLong()
	Identifier name was longer than MAXIDENTLENGTH.
 */
void ErrIdentTooLong(char *s) {
	fprintf(stderr, "Error: %d: Identifier, literal, or picure too long\n",
			zzline);
	fprintf(stderr, "     : %s\n", s);
	die();
}
/**
  ErrWrongType()
	Invalid types in operation.
 */
void ErrWrongType(char *was, char *shouldbe) {
	fprintf(stderr, "Error: %d: Wrong Type for operation\n", zzline);
	fprintf(stderr, "     : Was %s Should be %s\n", was, shouldbe);
	die();
}
/**
  ErrUnfinishedRecord()
	Empty record decl w/ no storage (?)
 */
void ErrUnfinishedRecord(char *s) {
	fprintf(stderr, "Error: %d: Record description was incomplete\n",
			zzline);
	if (strcmp(s, "") != 0)
		fprintf(stderr, "     : %s\n", s);
	die();
}

/**
  ErrEmit()
	Error while emitting code (like internal error)
 */
void ErrEmit() {
	fprintf(stderr, "Error: %d: Error emitting C code\n", zzline);
	die();
}
/**
  ErrArgCount()
	Argument count was too high or too low for clause.
	Used with ()* or ()+ clauses.
 */
void ErrArgCount( char *clause, char *which ) {
	fprintf(stderr, "Error: %d: Argument count incorrect\n", zzline);
	fprintf(stderr, "     : With %s, %s arguments\n", clause, which);
	die();
}

/**
  ErrUsage()
	Print usage stmt
 */
void ErrUsage( char *pgm ) {
	fprintf(stderr, "\n");
	fprintf(stderr, "Usage:\n");
	fprintf(stderr, "	%s cobol_src\n", pgm);
	fprintf(stderr, "\n");
	die();
}

/**
  ErrInputFile()
 */
void ErrInputFile( char *file ) {
	fprintf(stderr, "Could not open input file: %s\n", file);
	die();
}
