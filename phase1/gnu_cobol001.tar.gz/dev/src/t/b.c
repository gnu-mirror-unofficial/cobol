#include <stdio.h>
#define BOB 1024
#define SAL 2048

void main() {

int flags=0;

flags += BOB;

if (flags & BOB)
	printf("BOB already defined\n");
else
	flags += BOB;

if (flags & SAL)
	printf("SAL already defined\n");
else
	flags += SAL;

if ( (flags & BOB) && (flags & SAL) )
	printf("BOTH defined\n");

}
