#include <stdio.h>
#include "opt_util.h"
#include "list_util.h"
#include "get_util.h"
/*
#include "fnm_util.h"
#include "drs_util.h"
#include "str_util.h.new"
*/

void main(int argc, char **argv) {
	char infile[40];
	char outfile[40];

 static  char  *option_list[] = {    /* Command line options. */
        "{test}", "{kick}", "{blah}",
        NULL
    } ;       
	int option, length;
	char *argument, *arg, *s;
	char *name;
/*
	List fileList;
	FileName inputFile;
	DirectoryScan  directory ; 
*/

	opt_init(argc, argv, 1, option_list, NULL);

	while (option = opt_get (NULL, &argument)) {
	switch (option) {
        case 1:                 /* "-bold" */
            printf("was test\n");
            break ;
        case 2:                 /* "-columns <number>" */
	    printf("was kick\n");
            break ;                            
        case 3:                 /* "-columns <number>" */
	    printf("was blah\n");
            break ;                            
	case NONOPT:
	    length = -1;  arg = argument;
            while ((arg = getarg (arg, &length)) != NULL) {
	    	printf("file is %s\n", arg);
	    }
/*
            length = -1 ;  arg = argument ;
            while ((arg = getarg (arg, &length)) != NULL) {
                name = str_dupl (arg, length) ;
                drsCreate (name, &directory) ;
                while ((s = drsNext (directory)) != NULL) {
                    listAdd (&fileList, -1, (void *) fnmCreate (s, NULL)) ;
                }
                drsDestroy (directory) ;
                str_free (&name, -1) ;
            }
	    printf("file was %s\n", name);
*/
            break ;        
	}

	} /* while */

return;
}
