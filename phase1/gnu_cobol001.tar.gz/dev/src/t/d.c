#include <stdio.h>
#include <unistd.h>

void main() {

unlink("a.a");

return;
}
