/*
   Java Applet to convert from Infix, Postfix, Prefix notation
                               written by Ron Zucker
*/
import java.awt.*;
public class parser extends java.applet.Applet
{
  TextField infix, postfix, prefix;
  String inhold, prehold, posthold;

  // this method is just a shortcut to create the GridBagConstraints...
  void buildConstraints(GridBagConstraints gbc, int gx, int gy,
       int gw, int gh, int wx, int wy)
  {
    gbc.gridx=gx;
    gbc.gridy=gy;
    gbc.gridheight=gh;
    gbc.gridwidth=gw;
    gbc.weightx=wx;
    gbc.weighty=wy;
    gbc.ipadx=5;
    gbc.ipady=5;
  }

  // overiding the Applet init method with my own init to layout the screen...
  public void init()
  {
  //  set up applet layout
    GridBagLayout gridbag= new GridBagLayout();
    GridBagConstraints constraints = new GridBagConstraints();
    setLayout(gridbag);

    buildConstraints(constraints,0,0,1,1,10,20);
    Label lab1=new Label("Infix notation:",Label.RIGHT);
    constraints.fill = GridBagConstraints.BOTH;
    constraints.anchor=GridBagConstraints.CENTER;
    gridbag.setConstraints(lab1, constraints);
    add(lab1);

    infix = new TextField("");
    buildConstraints(constraints,1,0,1,1,90,0);
    gridbag.setConstraints(infix, constraints);
    add(infix);

    Label lab2=new Label("Postfix notation:",Label.RIGHT);
    buildConstraints(constraints,0,1,1,1,0,20);
    gridbag.setConstraints(lab2, constraints);
    add(lab2);

    postfix = new TextField("");
    buildConstraints(constraints,1,1,1,1,0,0);
    gridbag.setConstraints(postfix, constraints);
    add(postfix);

    Label lab3=new Label("Prefix notation:",Label.RIGHT);
    buildConstraints(constraints,0,2,1,1,0,20);
    gridbag.setConstraints(lab3, constraints);
    add(lab3);

    prefix = new TextField("");
    buildConstraints(constraints,1,2,1,1,0,0);
    gridbag.setConstraints(prefix, constraints);
    add(prefix);
    inhold="";
    posthold="";
    prehold="";
  }

  // this method is waiting for an action...
  public boolean action(Event e, Object arg)
  {
    if (e.target instanceof TextField)
      return handleText();
    else
      return false;
  }
  
  /*
     this method determines which textfield changed and calls the appropriate
     conversions 
  */
  boolean handleText()
  {
    String inFix, postFix, preFix;
    if (!inhold.equals(infix.getText()))
    {
      inFix = infix.getText();
      inhold=inFix;
      parsePost(inFix);
      parsePre(inFix);
    }
    else
    if (!posthold.equals(postfix.getText()))
    {
      postFix = postfix.getText();
      posthold=postFix;
      inFix = postParse(postFix);
      parsePre(inFix);
    }
    else
    if (!prehold.equals(prefix.getText()))
    {
      preFix = prefix.getText();
      prehold=preFix;
      inFix=preParse(preFix);
      parsePost(inFix);
    }
     
    return true;
  }

  //  this method converts Infix notation into Postfix notation...
  void parsePost(String inval)
  {
    String opString, outString;
    char ltr;
    int i;
    opString="";
    outString="";

    for (i=0; i < inval.length(); i++)
    {
      ltr = inval.charAt(i);
      switch (ltr)
      {
        case '(':
           opString+='(';
           break;
        case ')':
            while ((opString.length() > 0) &&
                  (opString.charAt(opString.length()-1)!= '('))
            {
             outString+=opString.charAt(opString.length()-1);
             opString=opString.substring(0,opString.length()-1);
            }
           opString=opString.substring(0,opString.length()-1);
           break;
        case '^':
           while ((opString.length() > 0) &&
                  (opString.charAt(opString.length()-1)== '^'))
            {
             outString+=opString.charAt(opString.length()-1);
             opString=opString.substring(0,opString.length()-1);
            }
           opString+=ltr;
           break;
        case '*': case '/':
           while ((opString.length() > 0) &&
                  (  (opString.charAt(opString.length()-1)== '^')
                  || (opString.charAt(opString.length()-1)== '*')
                  || (opString.charAt(opString.length()-1)== '/')))
            {
             outString+=opString.charAt(opString.length()-1);
             opString=opString.substring(0,opString.length()-1);
            }
           opString+=ltr;
           break;
        case '+': case '-':
           while ((opString.length() > 0) &&
                  (( opString.charAt(opString.length()-1)== '^')
                  || (opString.charAt(opString.length()-1)== '*')
                  || (opString.charAt(opString.length()-1)== '/')
                  || (opString.charAt(opString.length()-1)== '+')
                  || (opString.charAt(opString.length()-1)== '-')))
            {
             outString+=opString.charAt(opString.length()-1);
             opString=opString.substring(0,opString.length()-1);
            }
           opString+=ltr;
           break;
        default:
           outString+=ltr;
           break;
      }
    }
    while (opString.length() > 0)
    {
      outString+=opString.charAt(opString.length()-1);
      opString=opString.substring(0,opString.length()-1);
    }
    postfix.setText(outString);
    posthold=outString;
  }



  //  this method converts Infix notation into Prefix notation...
  void parsePre(String inval)
  {
    String opString, outString;
    char ltr;
    int i;
    opString="";
    outString="";

    for (i=inval.length()-1; i >= 0; i--)
    {
      ltr = inval.charAt(i);
      switch (ltr)
      {
        case ')':
           opString+=')';
           break;
        case '(':
            while ((opString.length() > 0) &&
                  (opString.charAt(opString.length()-1)!= ')'))
            {
             outString=opString.charAt(opString.length()-1)+outString;
             opString=opString.substring(0,opString.length()-1);
            }
           opString=opString.substring(0,opString.length()-1);
           break;
        case '^':
           while ((opString.length() > 0) &&
                  (opString.charAt(opString.length()-1)== '^'))
            {
             outString=opString.charAt(opString.length()-1)+outString;
             opString=opString.substring(0,opString.length()-1);
            }
           opString+=ltr;
           break;
        case '*': case '/':
           while ((opString.length() > 0) &&
                  (  (opString.charAt(opString.length()-1)== '^')))
            {
             outString=opString.charAt(opString.length()-1)+outString;
             opString=opString.substring(0,opString.length()-1);
            }
           opString+=ltr;
           break;
        case '+': case '-':
           while ((opString.length() > 0) &&
                  (( opString.charAt(opString.length()-1)== '^')
                  || (opString.charAt(opString.length()-1)== '*')
                  || (opString.charAt(opString.length()-1)== '/')))
            {
             outString=opString.charAt(opString.length()-1)+outString;
             opString=opString.substring(0,opString.length()-1);
            }
           opString+=ltr;
           break;
        default:
           outString=ltr+outString;
      }
    }
    while (opString.length() > 0)
    {
      outString=opString.charAt(opString.length()-1)+outString;;
      opString=opString.substring(0,opString.length()-1);
    }
    prefix.setText(outString);
    prehold=outString;
  }

  //  This method converts Postfix notation into Infix notation...
  String postParse(String inval)
  {
    String[] operands = new String[30];
    String newop;
    int i, opcount,numval,opsub;
    opcount=-1;
    for (i=0; i<inval.length(); i++)
    {
      char ltr = inval.charAt(i);
      if (!((ltr=='^') || (ltr=='*') || (ltr=='/') || (ltr=='+') || (ltr=='-')))
      {
        opcount++;
        operands[opcount]="" + ltr;
      }
      else
      {
        numval=0;
        newop=")";
        opsub=opcount;
        while (numval<2)
        {
          if (!operands[opsub].equals(""))
          {
           numval++;
           if (numval==1)
             newop=ltr + operands[opsub] + newop;
           else
             newop="(" + operands[opsub] + newop;
           operands[opsub]="";
          }
          opsub--;
        }
        operands[opcount]=newop;
      }
    }
    infix.setText(operands[opcount]);
    inhold=operands[opcount];
    return inhold;
  }
  
  //  This method converts Prefix notation into Infix notation...
  String preParse(String inval)
  {
    String[] operands = new String[30];
    String newop;
    int i, opcount,numval,opsub;
    opcount=-1;
    for (i=inval.length()-1; i>=0; i--)
    {
      char ltr = inval.charAt(i);
      if (!((ltr=='^') || (ltr=='*') || (ltr=='/') || (ltr=='+') || (ltr=='-')))
      {
        opcount++;
        operands[opcount]="" + ltr;
      }
      else
      {
        numval=0;
        newop="(";
        opsub=opcount;
        while (numval<2)
        {
          if (!operands[opsub].equals(""))
          {
           numval++;
           if (numval==1)
             newop=newop + operands[opsub] + ltr;
           else
             newop=newop + operands[opsub] + ")";
           operands[opsub]="";
          }
          opsub--;
        }
        operands[opcount]=newop;
      }
    }
    infix.setText(operands[opcount]);
    inhold=operands[opcount];
    return inhold;
  }
}
