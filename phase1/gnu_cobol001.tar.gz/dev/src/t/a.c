
#include <stdio.h>
typedef struct {
	int a;
	struct {
	char i;
	char j;
	} name;
} entry;

int main() {
	entry bob;

	bob.a = 5;
	bob.name.i = 'T';
	bob.name.j = 'L';

	printf("%c\n", bob.name.j);
	printf("%c\n", bob.name.i);
	return 0;
}
