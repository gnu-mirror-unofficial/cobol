#include <stdio.h>
#include <string.h>

void bb() {
#define DEBUG
}
char *aaa="hi there";
char a[5]="";
void main() {
int b=0;
	strcpy(a, "as");
	printf("%s\n", a);
	printf("%s\n", aaa);

	switch(b){
	case 0: /*bb();*/
		break;
	}
	asdf();
return;
}

void asdf(){
	#ifdef DEBUG
	printf("asdf\n");
	#endif
}
