#ifndef INCLUDED_C_ERRORS_H
#define INCLUDED_C_ERRORS_H
/**
  die()
	Bleat and die.
 */
void die() ;

/**
  ErrUndefVar()
	Undefined Variable.
 */
void ErrUndefVar( char *name ) ;

/**
  ErrRedefVar()
	Redefined Variable.
 */
void ErrRedefVar( char *name ) ;

/**
  ErrAlreadyDefined()
	Variable already defined.
 */
void ErrAlreadyDefined( char *name ) ;

/**
  ErrPictureDefn()
	Error in picture definition.
 */
void ErrPictureDefn( ) ;

/**
  ErrInternal()
	Internal Error.
 */
void ErrInternal(char *s) ;

/**
  ErrLitChar()
	Literal character was longer than single character.
 */
void ErrLitChar(char *s) ;

/**
  ErrUndefFD()
	The FD entry we found has no matching select stmt.
 */
void ErrUndefFD(char *s) ;

/**
  ErrLevel()
	Level number was invalid or incorrect w/ given clause
 */
void ErrLevel(int i, char *s) ;

/**
  WarnNotImpl()
	The statement parsed is not implemented
	Does NOT exit program.
 */
void WarnNotImpl(char *s) ;

/**
  WarnFileNotFound()
	Warn that filename given does not exist in the current directory.
 */
void WarnFileNotFound(char *s) ;

/**
  ErrIdentTooLong()
	Identifier name was longer than MAXIDENTLENGTH.
 */
void ErrIdentTooLong(char *s) ;

/**
  ErrWrongType()
	Invalid types in operation.
 */
void ErrWrongType(char *was, char *shouldbe) ;

/**
  ErrUnfinishedRecord()
	Empty record decl w/ no storage (?)
 */
void ErrUnfinishedRecord(char *s) ;

/**
  ErrEmit()
	Error while emitting code (like internal error)
 */
void ErrEmit() ;

/**
  ErrArgCount()
	Argument count was too high or too low for clause.
	Used with ()* or ()+ clauses.
 */
void ErrArgCount( char *clause, char *which ) ;

#endif /* INCLUDED_C_ERRORS_H */
