
/*
  dlgflex.c
  Provides glue between Antlr and flex generated lexical analyzer
  version 0.1 of 17-Oct-94
  Caveat Programmer
*/

#include "config.h"
#include <stdio.h>

/*  Obtained by: grep LL_K scan.c >LLK.h        */

#include "LL_K.h"

/*  Obtained from: pccts/antlr.h                */

#include "ZZLEXBUFSIZE.h"

int     zzbufsize;
int     zzbufovf;
char *  zzlextext;
int     zzlabase=0;
int     zzlap=0;
int     zzbegcol=0;
int     zzendcol=0;
int     zzline=0;

#ifdef LL_K
  int   zztokenLA[LL_K];
  char  zztextLA[LL_K][ZZLEXBUFSIZE];
#else
  int   zztoken;
#endif

extern char *   yytext;
extern FILE *   yyin;

/******************************************************************************/
#ifdef __USE_PROTOS
   extern int yylex(void);
#else
   extern int yylex();
#endif



/******************************************************************************/
#ifdef __USE_PROTOS
   extern void setNLA(int);
#else
   extern void setNLA();
#endif
/******************************************************************************/
#ifdef __USE_PROTOS
void zzrdstream(FILE *f)
#else
void zzrdstream(f)
   FILE *       f;
#endif
{
   if (f) {
      yyin=f;
   };
   return;
}
/******************************************************************************/
#ifdef __USE_PROTOS
void zzgettok(void)
#else
void zzgettok()
#endif
{
   char *       src;
   char *       dst;
   char *       endDst;
   int          result;

   result=yylex();
   if (result == 0) {
      setNLA(1);
   } else {
      setNLA(result);

      for (src=yytext, dst=zzlextext, endDst=&zzlextext[zzbufsize-1];
           *src != 0 && dst < endDst;
           src++,dst++) {
       *dst=*src;
      };
      if (*src != 0) {
         zzbufovf=1;
      } else {
         zzbufovf=0;
      };
      *dst=0;
   };
   return;
}
