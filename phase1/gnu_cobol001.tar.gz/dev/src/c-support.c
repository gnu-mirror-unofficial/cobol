/*
 * Author: Laura Tweedy (tweedy@umr.edu)
 *
 * File: c-support.c
 *
 * Purpose: Various support functions for verifying input validity,
 *	flag manipulation, extra parsing, etc.
 *
 * Notes:
 *
 * Date: Sun Nov 30 20:40:08 CST 1997
 */
/******************************************************/

#ifndef INCLUDED_C_SUPPORT_H
#include "c-support.h"
#endif


/* stack and symtable .h's included from c-global.h */
#define CLAUSE_FLAGS_S 1
#define PICTURE_S 1
#define TERMINAL_S 1
#include "c-global.h"

/*****GLOBALS*****/
int  pc = 0;	/* picture count, running total of picturedefn length */

/************/
/**
  CheckFlag(): IN: flag variable to be checked and modified, 
		flag we're checking and setting,
		name of clause ( for err reporting )
 */
void CheckFlag( int* flag_var, int flag_value, char *s ) {
	if ( (*flag_var) & flag_value )
		ErrAlreadyDefined(s);
	else
		(*flag_var) += flag_value;
}

/**
  SetFlag(): IN: flag variable to set
 */
void SetFlag( int* flag_var, int flag_value ) {
	(*flag_var) += flag_value;
}

/**
  ResetFlag(): IN: flag variable to be reset
 */
void ResetFlag( int* flag_var ) {
	(*flag_var) = 0;
}

/**
  VerifyFile(): IN: fname on disk
 */
void VerifyFile( char *fname ) {
	FILE *f;

	f = fopen(fname, "r");
	if (f == NULL)
		WarnFileNotFound(fname);
	else
		fclose(f);
}

/**
  CheckIdentLen(): IN: string to be checked
	If string is greater than MAXIDENTLENGTH, error out.
 */
void CheckIdentLen(char *s) {
	if (strlen(s) >= MAXIDENTLENGTH - 1) /* -1 for null */
		ErrIdentTooLong(s);
}

/**
  VerifyIdentType(): IN: name, ident to lookup  type to verify
	Return: 0 on success, 1 if different
 */
int VerifyIdentType(char *name, char type) {
	Entry *oldentry;
	int rv = 0;

	rv = SymLookup(name, &oldentry);
	if (rv != 0)
		ErrUndefVar(name);

	if (oldentry->type == type)
		return 0;

	return 1;
}

/**
  VerifyInteger(): IN: number in string format
	Verify that Numeric is an integer 
 */
void VerifyInteger() {
	/*if ( atof(num) != (int) atof(num) )*/
	if ( Numeric != (int) Numeric )
		ErrWrongType("Floating Point", "Integer");
}

/**
  VerifyLevelNum(): GLOBAL: DDLevel
	Verify that number is a valid level number 
	Note: allowing 66,77,88 as valid levels 
 */
void VerifyLevelNum() {
	if (DDLevel == 66 || DDLevel == 77 || DDLevel == 88)
		return;
	if (DDLevel > 49)
		ErrLevel(DDLevel, "Invalid Level Number");
}

/**
  GetSymbolType(): IN: name of symbol to be looked up
	Return the type according to the returned Entry.
 */
char GetSymbolType(char *name) {
	Entry *oldentry = NULL;
	int rv=0;

	rv = SymLookup(name, &oldentry);
	if (rv != 0)
		ErrUndefVar(name);
	return oldentry->type;
}

/**
  DetermineType(): GLOBAL: PictureDefn
	Determine if the picture indicates a string or a number.
	Note: Considered String if picture has any strictly 
			non-numeric chars, like B or X.
	RETURNS: 'S' if string, 'N' if Number
 */
char DetermineType() {
	#ifdef DEBUG
		assert(PictureDefn != NULL);
	#endif
	if ( strchr(PictureDefn, 'X') != NULL
	   ||strchr(PictureDefn, 'B') != NULL
	   ||strchr(PictureDefn, '0') != NULL )
		return 'S'; /* string */
	else 
		return 'N'; /* number */
}


/**
  ExpandReps(): IN: Number of repitions to do
		GLOBAL: pc (picture count, current length of picture defn)
	Note: expand X(3) to XXX etc. in PictureDefn 
 */
void ExpandReps(int reps) {
	int i;

	reps--; /* because already appended single "typing" char */
	if (pc + reps > MAXVALUELENGTH)
		ErrPictureDefn();
	for (i=0; i< reps; i++)
		strcat(PictureDefn, &last_char);
	pc += reps;
}

/**
  ParsePicture(): IN: String containing the unprocessed picture definition
	parse the picture defn, expanding if necessary
 */
void ParsePicture(char *pdef) {
	char *p;
	char c;
	int reps = 0;
	int decimal_count = 0;

	/* not checking c != null in while, b/c if non matched open paren,
		string will never get passed from the lexer */
	void getReps() {
		char s_reps[5];
		char *t;

		p++;
		t = strchr(p, ')');
		if (t == '\0') ErrPictureDefn();
		*t = '\0';
		strncpy(s_reps, p, 4 * sizeof(char));
		s_reps[4] = '\0';
		reps = atoi(s_reps); 
		*t = ')';
		p = t;
	} /* end getReps() */

#ifdef MASSIVE_DEBUG
	fprintf(stderr,"_________________________\n");
	fprintf(stderr,"__begining ParsePicture()\n");
#endif
	CheckIdentLen(pdef);
	PictureDefn[0] = '\0';
	p=pdef;
	while ((*p) != '\0') {
		c = toupper(*p);
		switch (c) {
		case 'X':
		case '9':
		case 'Z':
		case 'B':
		case '0':
		case '*': 
		case '$': last_char = c; strcat(PictureDefn, &c); break;
		case 'V':
		case ',':
		case '.': decimal_count++; strcat(PictureDefn, "."); break;
		case '(': getReps();
			  ExpandReps(reps);
			  break;
		default: ErrPictureDefn();
		} /* end switch */
		p++;
	} /* end while */
	if (decimal_count > 1)
		ErrPictureDefn();

	pc = 0;
	#ifdef DEBUG
		fprintf(stderr, "PICTURE DEFN = %s\n", PictureDefn);
	#endif

} /* end ParsePicture() */
