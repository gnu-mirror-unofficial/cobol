#ifndef INCLUDED_SYMTABLE_H
#define INCLUDED_SYMTABLE_H
/*
 *  Layout for a symbol table to use in the
 *  Cobol to C translator.
 *
 *  Includes structure definatiosn and functions.
 *
 */

/* typedefs for easy structure use. */

typedef struct s_Number Number;
typedef struct s_String String;
typedef struct s_File   File;
typedef struct s_Entry Entry;

/*
 * Global HashTable defintion
 *
 */
#define SYMTABLESIZE  733

#ifdef  HASHTABLE_DEFINITION
	Entry* gHashTable[SYMTABLESIZE];
#else
	extern Entry* gHashTable[SYMTABLESIZE];
#endif

/* File/Record Specific */

	/* organi[zs]ation and access modes */
#define SEQUENTIAL	0
#define INDEXED		1
#define DYNAMIC		2
#define RANDOM		3


struct s_File {
	char *hostfilename;
	char *progfilename;
	int organization;
	int accessmode;
	char *primarykey;
};
	
/* String Specific */
struct s_String {
	char*	init;
	char	align; /* R-ight L-eft C-enter N-one */
};

/* Number specific */
struct s_Number {
	double		init;
	unsigned 	point; /* no point(0) ( 0-18) number of digits to 
				* the right of the point
				* -1 means a variable pt 
				*/
};

struct s_Entry {
	char*	name;
	char	type;
	int	length;
	char	fill;
	Number *num;
	String *str;
	File   *file;
	Entry  *next;
};

/* SymTableInit -
 * Initalize  global  symtable for hashing.
 *
 *  Entry*  hashtable[TABLESIZE];
 */

int SymTableInit( void );

/* 
 * SymTableCleanUp - 
 *    Delete all Entries in the Table
 *
 */
void SymTableCleanUp( void );

/*
 * SymEntryNew -
 *  Create a New Entry struct.
 *
 */

int SymEntryNew(Entry** newentry);

/*
 * SymEntryDelete -
 *  Delete a Entry struct.
 *
 */

int SymEntryDelete(Entry* newentry);

/*
 * SymNumberNew -
 *   Create a Number struct.
 */

int SymNumberNew(Number**newnumber);

/*
 * SymNumberDelete -
 *   Delete a Number struct
 */

int SymNumberDelete(Number*newnumber);

/*
 * SymStringNew -
 *  Creaete String struct.
 */

int SymStringNew(String** newstring );

/*
 * SymStringDelete -
 * Del a string struct 
 */

int SymStringDelete(String* newstring);

/*
 * SymFileNew
 *  Create a File struct.
 */
int SymFileNew(File** newfile );

/*
 * SymFileDelete -
 *  Del a file struct
 */
int SymFileDelete(File* newfile );


/*
 * SymInsert( in Entry* ) -
 *  Insert an entry into the symtable
 */

int SymInsert(Entry* newentry );


/*
 * SymLookup( in char*, out Entry* )
 *   Lookup the passed in char* and return an Entry struct
 */

int SymLookup(char*, Entry** );




#endif /* INCLUDED_SYMTABLE_H */
