/*
 *  Chad Slaughter 4/22/97
 *      The program uses a symbol table to store the values assigned to names.
 *      The symbol table is implimented as an open addressing hash table. This
 *      	 allows any number of symbols to be inserted into the list.
 */

#include <stdio.h>
#include <stdlib.h>
#include "symtypes.h"
/* Structure Definations */

#define TABLESIZE 211

#define NUL '\0'


typedef struct s_entry Entry;

struct s_entry {
	/*union {
	   numericStruct numeric;
	   recordStruct  record;
	   fileStruct	 file;
	   L88Struct	 level88;
	} value;
	*/
	int   type;
	char* symbol;
	Entry* next;
} ;


/* Function Declarations */

void Error( int );

void   SymTabInit();                            /* Function for symbol table */
int    SymTabLookup( char * );
void   SymTabInsert( char*, int );
void   SymTabCleanUp();

int    STLookupValue( char* );        /* helper function for the symbol table */
Entry* STLookupEntry( char*, int  );
int    STInsertEntry( char*, int );
int    STHashFunc( char* );

/* Global Variables */

Entry * hashtable[TABLESIZE] ;          /* Holds name values from assignments */



/*
 * Lookup:  Determine the value associated with a given symbol.
 *          Function is passed a ptr to a name to lookup in the symbol table.
 *          Return the value stored for that symbol.
 *          Free the memory associated with the passed in symbol.
 * 
 */

int SymTabLookup( char* str ){

	int temp;
#ifdef DEBUG
	printf("DEBUG: SymTabLookup: Lookup on %s\n", str );
#endif

	temp = STLookupValue( str );

	free( str ); 

	return temp;
}

/*
 * Insert: Associate the given symbol and value in the symbol table.
 *         Insert a symbol/value pair into the hash table.
 *
 */

void SymTabInsert( char* str, int value ){

#ifdef DEBUG
	printf("DEBUG: SymTabInsert: %s : %g\n", str, value );
#endif
	STInsertEntry(str, value);
}	

/*
 * InitTable:  Inital hash table values to NUL
 *
 */

void SymTabInitTable() {
	int i;

	for( i = 0; i < TABLESIZE; i++ )
		hashtable[i]=NUL;

}

/*
 * CleanUp:  Frees all memory allocated for the symbol table
 *
 */

void SymTabCleanUp(){
	int i;
	Entry* temp;

	for ( i =0; i < TABLESIZE; i++ ){
		if ( hashtable[i] == NUL)
			continue;
		temp = hashtable[i];
		while( temp != NUL ) {
			hashtable[i] = temp -> next;
			free(temp->symbol);         /* free the symbol memory */
			free(temp);                  /* Free the entry memory */
			temp = hashtable[i];
		}
	}
}

/*
 * LookupValue:  Look in the symbol table for the passed in symbol and
 *               returns the value of that symbol
 *
 *               Called by Lookup wrapper function to hash into the table,
 *               and return the value stored at a given string if it doesn't
 *               exist in the table return the default value: 0.
 *
 */

int STLookupValue( char* str ){

	int hvalue;
	Entry *e;
	
	hvalue = STHashFunc( str );

	e = STLookupEntry( str, hvalue );

	if ( e != NUL )
		return e->value;
	else
		return 0;
		
}
		
/*
 * LookupEntry: See if a symbol is in the symbol table at the give hash value.
 *
 *                This function is a helper function that depends on the
 *                hash value of the string being computed and passed to it.
 *                If symbol exists return a ptr to its entry, else NULL.
 */

Entry *STLookupEntry( char* str, int  hvalue ) {

	Entry *e = hashtable[hvalue];

	while( e != NUL ) {
		if ( strcmp( e->symbol, str ) == 0 )
 			return e;
                e = e->next;
	}

	return NUL;
}

/*
 * InsertEntry: Insert a symbol and value into the symbol table.
 *
 *              This is a helper function for use with the hash table.
 *              It checks to see if the symbol already exists, if so
 *              it sets the value of that entry to the value passed in.
 *              If an entry doesn't exist, it creates a new entry record.
 *              then attached the record at the correct hash value.
 *                   If multply entries for a given hash value then,
 *                   attach at the front of the linked list.
 *
 */

int STInsertEntry( char* str, int value ) {
	
	int hvalue;
	Entry *e;
	char* oldstr;

	hvalue = HashFunc( str );
	
	e = LookupEntry( str, hvalue );

	if ( e == NUL ) {   /* Entry not present */
						
		e = (Entry*) malloc( sizeof(Entry) );
                                             /* Alloc memory for the new node */
		if ( e == NUL )           /* If the ptr = NULL: memory problem*/
			Error( 999 );
 
		e->value = value;          /* Set the field for the new entry */
		e->symbol=str;

		e->next= hashtable[hvalue];  /* Attach the entry to the table */
		hashtable[hvalue] = e;

	} else {                       /* Entry Exists, simple replace value */
               /*
                * In the case of a duplicate entry.
                *  The memory allocated for the symbol must be freed.
                *  In order to be able to access the string at high level 
                *  function( Statement, print assignments),
                *  The newly allocated symbol string must be kept and the older
                *  symbol string freed.
                */
		oldstr = e->symbol;
		free( oldstr );

		e->symbol = str;
		e->value = value;
	}
}
/*
 *  HashFunc: Returns a hash value for a symbol
 *
 *      This is an implimentation of a hash function used by
 *      P.J. Weinberger for the symbol table in his C compiler
 *
 *      The hash value is computed by starting with a hash value of zero.
 *      For each character, in a passed in str, shift the hash value
 *      4 bits to the left.  Add in the value of the character. 
 *      If any of the four high order bits  of the hash value are  1, 
 *      then take those 4 bits and shift them to the low order bits of a 
 *      new value, then xor them back onto the hash value.
 *     	Then reset any of the four high order bits from 1 to 0. 
 *      Continue for all characters in the string.
 *      Then you have your hash value for the string.
 */

int  STHashFunc( char * s) {

	char *p;
	unsigned g, h =0;
	
	for( p = s; *p != NUL; p = p + 1) {
		h = ( h << 4 ) + (*p);
		if ( (g = h&0xf0000000) ){
			h = h ^ ( g >> 24 );
			h = h ^ g;
		}
	}

	return h % TABLESIZE;
}
