#ifndef INCLUDED_C_VARS_H
#define INCLUDED_C_VARS_H
/**
  InsertNewEntry(): GLOBAL: e, the working Entry
 */
void InsertNewEntry() ;

/**
  MakeNewEntry()
	Prepare a new "Entry" type
 */
void MakeNewEntry(char *s) ;

/**
  MakeNewString()
	Make a new "String" type for symbol table
 */
void MakeNewString() ;

/**
  MakeNewNumber()
	Make a new "Number" type for symbol table
 */
void MakeNewNumber() ;

/**
  FlushStack()
	Call emit code to close all remaining structures
 */
void FlushStack() ;

/**
  FQNStackPush()
	stack push, maintaining fully qualified name
 */
void FQNStackPush(char *name, int level) ;

/**
  FQNStackPop()
	Stack pop, maintaining fully qualified name
 */
void FQNStackPop(char *name, int level) ;

/**
  StructHandler()
	Handle emit structure begins and ends and stack operations
	for group items.
 */
void StructHandler(char *name, int level) ;

/**
  VariableHandler()
	Emit code for and handle stack operations with actual
	data members.
 */
void VariableHandler(char *name, int level) ;

/**
  InitVariable(): GLOBAL: e
	Fills e with value obtained from "value" clause
 */
void InitVariable() ;

/**
  InitFill(): GLOBAL: e->str
	Fills string with an initial value.  Used with "value spaces"
	and "value zeroes".
 */
void InitFill(char c) ;

/**
  ResetGlobal(): GLOBAL: DDIdent, DDLevel, DDValue_s, DDValue_n
	Reset to "" or 0.  Called after each data descr entry is
	processed
 */
void ResetGlobals() ;

/**
  ResetFQN()
	Make fully qualified name the null string.
	Just to make sure it's really empty.
 */
void ResetFQN() ;

/**
  RecordDescrActions()
	All actions which take place as a result of a record description
	line.
 */
void RecordDescrActions() ;

/**
  VerifyIdent()
	Lookup identifier in the table.
	Die if it's not there.
 */
void VerifyIdent(char *name) ;

/**
  MakeNewParagraph()
	Enter paragraph name into the symbol table
 */
void MakeNewParagraph(char *name) ;

/**
  VerifyParagraph()
	Lookup name in symbol table and make sure it's a paragraph.
 */
void VerifyParagraph(char *name) ;

/**
  MakeNewFD(): IN: variable name for FD
		GLOBAL: e
 */
void MakeNewFD(char *name) ;

/**
  VerifyFD(): IN: variable name for FD
 */
void VerifyFD(char *name) ;

/**
  FileControlActions(): 
	Actions to take upon matching a SELECT statement
 */
void FileControlActions() ;

/**
  PrintInfoHeader(): Gratuitously give credit to me and chad.
 */
void PrintInfoHeader() ;

/**
  InitializeAll()
	Initialize stack, symbol table, and list.
 */
void InitializeAll(char *pgmname) ;

/**
  AddCheckArgs()
	Check arguments to add verb
 */
void AddCheckArgs() ;

/**
  Add_QCreate()
 */
void Add_QCreate() ;

/**
  Enqueue()
	Create a new queue entry and enqueue it in the correct queue.
 */
void Enqueue(Queue *q, char *name) ;

/**
  VerbAddActions()
	Go thru the queues of identifiers and emit the correct C code.
 */
void VerbAddActions() ;

/**
  MakeQEntry()
	Make a new QueueEntry container at the pointer passed in.
	Make queue entry-> name = name
 */
void MakeQEntry(QueueEntry **q, char *name) ;

/**
  ExprStringInit()
	Add ExprStringDelete to atexit list.
 */
void ExprStringInit() ;

/**
  ExprStringDelete
	Free global var ExprString
 */
void ExprStringDelete() ;

/**
  ExprStringAdd()
	Cat text to end of ExprString.
 */
void ExprStringAdd(char *add) ;

/**
  ExprPow()
	deal with a pow() stmt in global CExprString.
 */
void ExprPow(char *s) ;

/**
 */
void CopyExprToCExpr();

/**
  ExprFlush()
	Flush part of a conditional upon seeing a conditional operator
	We do not assert(ExprString != NULL) because
		if string before conditional was a pow() special case,
		the ExprString has been flushed.
 */
void ExprFlush(char *rel) ;

/**
  MyRealloc()
	If dest is null, use only add for new length
 */
void MyRealloc(char **dest, char *add) ;

/**
  ExprActions()
	Handle the Expression queue
 */
void ExprActions() ;

/**
  ExprEnQ()
	Add the current "token" to the expression queue
 */
void ExprEnQ(char *string) ;

#endif
