/* #define the types of variables we will put into the symbol table */

#define ERROR	-1
#define NUMERIC	0
#define RECORD	1
#define FILE	2
#define L66	3
#define L77	4
#define L88	5
/*
typedef struct {
	int  sign;
	long value;
	int  ndecimal;
	char fill;
	} numericStruct;

typedef struct {
	char *value;
	} recordStruct;

typedef struct {
	char *fileName;
	} fileStruct;

typedef struct {
	char *text;
	int  value;
	} L88Struct;
*/
