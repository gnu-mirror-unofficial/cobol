/* Error handling routines for cobol */
#include <stdio.h>
extern int zzline;
/* all the last minute deallocing */

void FinalCleanUp() {
	SymTabCleanUp();
}

void die() {
	fprintf(stderr, ">>ABEND<<\n");
	FinalCleanUp();
	exit (0);
}

void ErrUndefVar( char *name ) {
	fprintf(stderr, "Error: Undefined Variable '%s' at line %d\n", name, zzline);
	die();
}

void ErrAlreadyDefined( char *name ) {
	fprintf(stderr, "Error: Clause beginning '%s' already defined\n", name);
	die();
}

