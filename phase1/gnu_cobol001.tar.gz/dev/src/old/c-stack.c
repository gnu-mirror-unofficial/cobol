/* a simple stack
 * Uses static memory b/c can only have 01-49 level #'s
 * plus 66,77,88. and we only care about *different* level #'s
 */

#include <stdio.h>
#include <assert.h>

#define STACKSIZE 60
int stack[STACKSIZE];
int top = 0;

int StackInit( ) {
	memset(&stack, STACKSIZE * sizeof(int), '\0');
}

int StackPush(int newitem) {
	assert( top < STACKSIZE );

	stack[top] = newitem;
	top++;

	return 0;
}

int StackPop( ) {
	assert( top > 0 );

	stack[top] = 0;
	top--;

	return stack[top];
}

int StackPeek( ) {
	assert( top < STACKSIZE );

	return stack[top-1];
}
