
int id_div_flags = 0;
int env_div_flags = 0;
int io_ctl_flags = 0;
int file_control_flags = 0;
int file_descr_flags = 0;
int sub_fd_flags = 0;
int data_descr_flags = 0; 

int currentDivision = -1;

char PictureDefn[MAXPICLENGTH];
int  pc = 0;   /* picture count: keeps track of length of PictureDefn */
char last_char; /* last type char seen in pic_defn */

/* store zzlextext in these */
char Ident[MAXIDENTLENGTH];
char StringLiteral[MAXPICLENGTH];
double  Numeric=0;

/* name right after the level number */
char DDIdent[MAXIDENTLENGTH];
int  DDLevel = 0;

