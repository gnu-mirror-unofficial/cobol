#include <stdio.h>
#include <stdlib.h>
#include <strings.h>
#include <ctype.h>
#include <assert.h>
#include <math.h>
/* the longest any one identifier can be (in chars) */
#define MAXVALUELENGTH	129
#define MAXIDENTLENGTH	41
#define MAXFQNLENGTH	1610

#ifndef INCLUDED_SYMTABLE_H
#include "symtable.h"
#endif

#ifndef INCLUDED_STACK_H
#include "stack.h"
#endif

#ifndef INCLUDED_EMIT_H
#include "emit.h"
#endif

#ifndef INCLUDED_QUEUE_H
#include "queue.h"
#endif

#ifndef INCLUDED_C_ERRORS_H
#include "c-errors.h"
#endif

#ifndef INCLUDED_C_SUPPORT_H
#include "c-support.h"
#endif

/*******************************FLAG STORAGE*****************************/
#ifdef CLAUSE_FLAGS_S
int id_div_flags = 0;
int env_div_flags = 0;
int io_ctl_flags = 0;
int file_control_flags = 0;
int file_descr_flags = 0;
int sub_fd_flags = 0;
int data_descr_flags = 0; 
int verb_flags = 0;
#else
extern int id_div_flags;
extern int env_div_flags;
extern int io_ctl_flags;
extern int file_control_flags;
extern int file_descr_flags;
extern int sub_fd_flags;
extern int data_descr_flags;
extern int verb_flags;
#endif
/*******************************FLAG STORAGE*****************************/

/*******************************PICTURE***********************************/
#ifdef PICTURE_S
char PictureDefn[MAXVALUELENGTH];
char last_char;		/* last type char seen in pic_defn */
#else
extern char PictureDefn[];
extern char last_char;
#endif
/*******************************PICTURE***********************************/

/*******************************TERMINAL GLOBALS***************************/
#ifdef TERMINAL_S
	/* store zzlextext in these */
char	Ident[MAXIDENTLENGTH];
char	StringLiteral[MAXVALUELENGTH];
double	Numeric=0;
char	Numeric_s[MAXIDENTLENGTH];
char	TerminalType;
char	ProgramId[MAXIDENTLENGTH];
#else
extern char	Ident[];
extern char	StringLiteral[];
extern double	Numeric;
extern char	Numeric_s[];
extern char	TerminalType;
extern char	ProgramId[];
#endif
/*******************************TERMINAL GLOBALS***************************/

/*******************************VERB GLOBALS*******************************/
#ifdef VERB_GLOBALS
char	move_src[MAXVALUELENGTH];
char	PerformParagraph[MAXIDENTLENGTH];
Queue	*arg1=NULL;
Queue	*arg2=NULL;
Queue	*giving = NULL;
#else
extern char	move_src[];
extern char	PerformParagraph[];
extern Queue	*arg1;
extern Queue	*arg2;
extern Queue	*giving;
#endif
/*******************************VERB GLOBALS*******************************/

/*****************************COLLECTING ARGS*****************************/
/* Variables for holding the values we will add to Entry structure */

#ifdef DDTEMP_S
char	DDIdent[MAXIDENTLENGTH];
int	DDLevel = 0;
char	DDValue_s[MAXVALUELENGTH];
double	DDValue_n = 0;
#else
extern char	DDIdent[];
extern int	DDLevel;
extern char	DDValue_s[];
extern double	DDValue_n;
#endif

#ifdef FDTEMP_S
char FDIdent[MAXIDENTLENGTH];
#else
extern char FDIdent[];
#endif

/*****************************COLLECTING ARGS*****************************/


/*****************/
/* flags for "any of this set, in any order, but only once" */
/* id div */
#define ID_AUTHOR		2
#define ID_INSTALLATION		4
#define ID_DATE_WRITTEN		8
#define ID_DATE_COMPILED	16
#define ID_SECURITY		32

/* env div */
#define ENV_SRC_COMPUTER	512
#define ENV_OBJ_COMPUTER	1024
#define ENV_SPECIAL_NAMES	2048
#define ENV_COLL_SEQUENCE	2
#define ENV_SEGMENT_LIMIT	4
#define ENV_IMPL_NAME		8
#define ENV_ALPHABET		16
#define ENV_SYMB_CHAR		32
#define ENV_CLASS		64
#define ENV_CURRENCY		128
#define ENV_DECIMAL		256

/* io control */
#define IO_CTL_SAME_AREA	2
#define IO_CTL_MULTIPLE_FILE	4

/* file control */
#define FC_RESERVE		2
#define FC_ORGANIZATION		4
#define FC_PADDING		8
#define FC_RECORD_DELIM		16
#define FC_ACCESS_MODE		32
#define FC_FILE_STATUS		64
#define FC_RECORD_KEY		128
#define FC_ALT_RECORD		256
#define FC_ASSIGN		512

/* file description */
#define FD_EXTERNAL		2
#define FD_GLOBAL		4
#define FD_BLOCK		8
#define FD_RECORD		16
#define FD_LABEL		32
#define FD_VALUE_OF		64
#define FD_DATA			128
#define FD_LINAGE		256
#define FD_CODE_SET		512

/* sub fd flags */
#define FD_LINAGE_FOOT		2
#define FD_LINAGE_TOP		4
#define FD_LINAGE_BOTTOM	8
#define FD_OCCURS_DEP		16
#define FD_OCCURS_ASC		32
#define FD_OCCURS_INDEXED	64

/* data description */
#define DD_REDEFINES		2
#define DD_EXTERNAL		4
#define DD_GLOBAL		8
#define DD_PICTURE		16
#define DD_USAGE		32
#define DD_SIGN			64
#define DD_OCCURS		128
#define DD_SYNC			256
#define DD_JUST			512
#define DD_BLANK		1024
#define DD_VALUE		2048
#define DD_SPACES		4096
#define DD_ZEROES		8192

/* verb flags */
#define RELATION_NOT		2
#define CONDITION_NOT		32
#define ADD_CORR		4
#define ROUNDED			8
#define PROC_DIV_MAIN		16

/*
#ifdef FLAGS
actual
#else
extern
#endif
in c : #define FLAGS 
	#include header
*/
