/*
 * Author: Laura Tweedy (tweedy@umr.edu)
 *
 * File: c-types.c
 *
 * Purpose: Type checking
 *
 * Notes:
 *
 * Date: Mon Dec  1 22:45:02 CST 1997
 */

#ifndef INCLUDED_C_TYPES_H
#include "c-types.h"
#endif

#include "c-global.h"

/**
  VerifyEmitMove(): IN: dest
	Valid:	string to string ident
		numeric to string ident
		numeric to numeric ident
		string ident to string ident
		numeric ident to string ident
		numeric ident to numeric ident
	Note: "source" type is stored in the flag, TerminalType
	'S' String, 'N' Numeric
	Verify and call correct emit function for statement.
 */
void VerifyEmitMove(char *name) {
	Entry *oldentry = NULL;
	int rv=0;
	int dl=0;

	rv = SymLookup(name, &oldentry);
	if (rv != 0)
		ErrUndefVar(name);
	dl = oldentry->length;

	switch (TerminalType) {
	/* src = move_src, dest = name, destlen = dl */
	/* source */
	case 'S': switch ( oldentry->type ) {
			/* destination */
			case 'S': oldentry = NULL;
				  if (SymLookup(move_src, &oldentry) == 0)
					emit_move_StringToString(move_src,
						name, dl);
				  else
					emit_move_literalToString(move_src,
						name, dl);
				  break;
			case 'N': ErrWrongType("Number", "String"); 
				  break;
			case 'F': ErrWrongType("File", "String"); 
				  break;
			default : ErrInternal("Invalid Type in Symbol Table");
		  } break;
	/* source */
	case 'N': switch ( oldentry->type ) {
			/* destination*/
			case 'S': oldentry = NULL;
				  if (SymLookup(move_src, &oldentry) == 0)
					emit_move_NumberToString(move_src,
						name, dl);
				  else
					emit_move_literalToString(move_src,
						name, dl);
				  break;
			case 'N': oldentry = NULL;
				  if (SymLookup(move_src, &oldentry) == 0)
					emit_move_NumberToNumber(move_src,
						name);
				  else
					emit_move_literalToNumber(move_src,
						name);
				  break;
			case 'F': ErrWrongType("File", "Number or String");
				  break;
			default : ErrInternal("Invalid Type in Symbol Table");
		  } break;
	default : { char a[30]; sprintf(a, "Invalid Terminal Type %c", 
			TerminalType); ErrInternal(a);
		  }
	}
}

