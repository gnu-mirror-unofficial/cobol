/*
 * A n t l r  T r a n s l a t i o n  H e a d e r
 *
 * Terence Parr, Will Cohen, and Hank Dietz: 1989-1994
 * Purdue University Electrical Engineering
 * With AHPCRC, University of Minnesota
 * ANTLR Version 1.33MR9
 */
#include <stdio.h>
#define ANTLR_VERSION	133MR9

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "charbuf.h"
#include "c-global.h"
#define ZZCAN_GUESS
#include <setjmp.h>
#define LL_K 4
#define zzSET_SIZE 48
#include "antlr.h"
#include "tokens.h"
#include "dlgdef.h"
#include "mode.h"
#ifndef PURIFY
#define PURIFY(r,s)
#endif

void
#ifdef __USE_PROTOS
io_section(void)
#else
io_section()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	zzmatch(INPUT_OUTPUT); zzCONSUME;
	zzmatch(SECTION); zzCONSUME;
	zzmatch(PERIOD); zzCONSUME;
	zzmatch(FILE_CONTROL); zzCONSUME;
	zzmatch(PERIOD); zzCONSUME;
	{
		zzBLOCK(zztasp2);
		int zzcnt=1;
		zzMake0;
		{
		do {
			file_control_clause();
			zzLOOP(zztasp2);
		} while ( (LA(1)==SELECT) );
		zzEXIT(zztasp2);
		}
	}
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==I_O_CONTROL) ) {
			io_control();
		}
		zzEXIT(zztasp2);
		}
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd6, 0x80);
	}
}

void
#ifdef __USE_PROTOS
io_control(void)
#else
io_control()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	zzmatch(I_O_CONTROL); zzCONSUME;
	zzmatch(PERIOD); zzCONSUME;
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		while ( (LA(1)==SAME)
 ) {
			area_clause();
			zzLOOP(zztasp2);
		}
		zzEXIT(zztasp2);
		}
	}
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		while ( (LA(1)==MULTIPLE) ) {
			multiple_clause();
			zzLOOP(zztasp2);
		}
		zzEXIT(zztasp2);
		}
	}
	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd7, 0x1);
	}
}

void
#ifdef __USE_PROTOS
area_clause(void)
#else
area_clause()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	zzmatch(SAME); zzCONSUME;
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==RECORD) ) {
			zzmatch(RECORD); zzCONSUME;
		}
		else {
			if ( (LA(1)==SORT) ) {
				zzmatch(SORT); zzCONSUME;
			}
			else {
				if ( (LA(1)==SORT_MERGE) ) {
					zzmatch(SORT_MERGE); zzCONSUME;
				}
			}
		}
		zzEXIT(zztasp2);
		}
	}
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==AREA)
 ) {
			zzmatch(AREA); zzCONSUME;
		}
		zzEXIT(zztasp2);
		}
	}
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==FOR_C) ) {
			zzmatch(FOR_C); zzCONSUME;
		}
		zzEXIT(zztasp2);
		}
	}
	file_name();
	{
		zzBLOCK(zztasp2);
		int zzcnt=1;
		zzMake0;
		{
		do {
			file_name();
			zzLOOP(zztasp2);
		} while ( (LA(1)==NONNUMERIC) );
		zzEXIT(zztasp2);
		}
	}
	zzmatch(PERIOD);
	zzNON_GUESS_MODE {
	WarnNotImpl("SAME ... file_name");   
	}
 zzCONSUME;

	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd7, 0x2);
	}
}

void
#ifdef __USE_PROTOS
multiple_clause(void)
#else
multiple_clause()
#endif
{
	zzRULE;
	zzBLOCK(zztasp1);
	zzMake0;
	{
	zzmatch(MULTIPLE); zzCONSUME;
	zzmatch(FILE_C); zzCONSUME;
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==TAPE) ) {
			zzmatch(TAPE); zzCONSUME;
		}
		zzEXIT(zztasp2);
		}
	}
	{
		zzBLOCK(zztasp2);
		zzMake0;
		{
		if ( (LA(1)==CONTAINS) ) {
			zzmatch(CONTAINS); zzCONSUME;
		}
		zzEXIT(zztasp2);
		}
	}
	{
		zzBLOCK(zztasp2);
		int zzcnt=1;
		zzMake0;
		{
		do {
			file_name();
			{
				zzBLOCK(zztasp3);
				zzMake0;
				{
				if ( (LA(1)==POSITION)
 ) {
					zzmatch(POSITION); zzCONSUME;
					integer();
				}
				zzEXIT(zztasp3);
				}
			}
			zzLOOP(zztasp2);
		} while ( (LA(1)==NONNUMERIC) );
		zzEXIT(zztasp2);
		}
	}
	zzmatch(PERIOD);
	zzNON_GUESS_MODE {
	WarnNotImpl("MULTIPLE FILE");   
	}
 zzCONSUME;

	zzEXIT(zztasp1);
	return;
fail:
	zzEXIT(zztasp1);
	if ( zzguessing ) zzGUESS_FAIL;
	zzsyn(zzMissText, zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk, zzBadText);
	zzresynch(setwd7, 0x4);
	}
}
