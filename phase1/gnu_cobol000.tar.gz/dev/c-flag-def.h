
/* flags for "any of this set, in any order, but only once" */

/* id div */
#define ID_AUTHOR		2
#define ID_INSTALLATION		4
#define ID_DATE_WRITTEN		8
#define ID_DATE_COMPILED	16
#define ID_SECURITY		32

/* env div */
#define ENV_SRC_COMPUTER	512
#define ENV_OBJ_COMPUTER	1024
#define ENV_SPECIAL_NAMES	2048
#define ENV_COLL_SEQUENCE	2
#define ENV_SEGMENT_LIMIT	4
#define ENV_IMPL_NAME		8
#define ENV_ALPHABET		16
#define ENV_SYMB_CHAR		32
#define ENV_CLASS		64
#define ENV_CURRENCY		128
#define ENV_DECIMAL		256

/* io control */
#define IO_CTL_SAME_AREA	2
#define IO_CTL_MULTIPLE_FILE	4

/* file control */
#define FC_RESERVE		2
#define FC_ORGANIZATION		4
#define FC_PADDING		8
#define FC_RECORD_DELIM		16
#define FC_ACCESS_MODE		32
#define FC_FILE_STATUS		64
#define FC_RECORD_KEY		128
#define FC_ALT_RECORD		256
#define FC_ASSIGN		512

/* file description */
#define FD_EXTERNAL		2
#define FD_GLOBAL		4
#define FD_BLOCK_CONTAINS	8
#define FD_RECORD		16
#define FD_LABEL		32
#define FD_VALUE_OF		64
#define FD_DATA			128
#define FD_LINAGE		256
#define FD_CODE_SET		512

/* data description */
#define DD_REDEFINES		2
#define DD_EXTERNAL		4
#define DD_GLOBAL		8
#define DD_PICTURE		16
#define DD_USAGE		32
#define DD_SIGN			64
#define DD_OCCURS		128
#define DD_SYNC			256
#define DD_JUST			512
#define DD_BLANK		1024
#define DD_VALUE		2048

