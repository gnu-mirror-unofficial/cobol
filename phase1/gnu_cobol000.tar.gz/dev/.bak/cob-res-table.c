#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <ctype.h>
#include "res-words.h"

#define HASH_TABLE_SIZE	797
#define MAX_STR_LEN	40
#define N_RES_WORDS	370
	
char HashTable[HASH_TABLE_SIZE][MAX_STR_LEN];
char ResWords[N_RES_WORDS][MAX_STR_LEN] = { 
"ACCEPT", "ACCESS", "ADD", "ADVANCING", "AFTER", "ALL", \
"ALPHABETIC-LOWER", "ALPHABETIC-UPPER", "ALPHABETIC", \
"ALPHABET", "ALPHANUMERIC-EDITED", "ALPHANUMERIC", \
"ALSO", "ALTERNATE", "ALTER", "AND", "ANY", "AREAS", "AREA", \
"ARE", "ASCENDING", "ASSIGN", "AT", "AUTHOR", \
"BEFORE", "BINARY", "BLANK", "BLOCK", "BOTTOM", "BY", \
"CALL", "CANCEL", "CD", "CF", "CHARACTERS", "CHARACTER", "CH", \
"CLASS", "CLOCK-UNITS", "CLOSE", "COBOL", "CODE-SET", "CODE", \
"COLLATING", "COLUMN", "COMMA", "COMMON", "COMMUNICATION", \
"COMPUTATIONAL", "COMPUTE", "COMP", "CONFIGURATION", "CONTAINS", \
"CONTENT", "CONTINUE", "CONTROLS", "CONTROL", "CONVERTING", \
"COPY", "CORRESPONDING", "CORR", "COUNT", "CURRENCY", \
"DATA", "DATE-COMPILED", "DATE-WRITTEN", "DATE", "DAY-OF-WEEK", \
"DAY", "DEBUG-CONTENTS", "DEBUG-ITEM", "DEBUG-LINE", \
"DEBUG-NAME", "DEBUG-SUB-1", "DEBUG-SUB-2", "DEBUG-SUB-3", \
"DEBUGGING", "DECIMAL-POINT", "DECLARITIVES", "DELETE", \
"DELIMITED", "DELIMITER", "DEPENDING", "DESCENDING", "DESTINATION", \
"DETAIL", "DE", "DISABLE", "DISPLAY", "DIVIDE", "DIVISION", \
"DOWN", "DUPLICATES", "DYNAMIC", \
"EGI", "ELSE", "EMI", "ENABLE", "END-ADD", "END-CALL", \
"END-COMPUTE", "END-DELETE", "END-DIVIDE", "END-EVALUATE", \
"END-IF", "END-MULTIPLY", "END-OF-PAGE", "END-PERFORM", "END-READ", \
"END-RECEIVE", "END-RETURN", "END-REWRITE", "END-SEARCH", "END-START", \
"END-STRING", "END-SUBTRACT", "END-UNSTRING", "END-WRITE", "END", \
"ENTER", "ENVIRONMENT", "EOP", "EQUAL", "ERROR", "ESI", "EVALUATE",
"EVERY", "EXCEPTION", "EXIT", "EXTEND", "EXTERNAL", \
"FALSE", "FD", "FILE", "FILE-CONTROL", "FILLER", "FINAL", \
"FIRST", "FOOTING", "FOR", "FROM", \
"GENERATE", "GIVING", "GLOBAL", "GO", "GREATER", "GROUP", \
"HEADING", "HIGH-VALUES", "HIGH-VALUE", \
"I-O-CONTROL", "I-O", "IDENTIFICATION", "IF", "INDEXED", \
"INDEX", "INDICATE", "INITIALIZE", "INITIAL", "INITIATE", \
"INPUT-OUTPUT", "INPUT", "INSPECT", "INSTALLATION", "INTO", \
"INVALID", "IN", "IS", \
"JUSTIFIED", "JUST", \
"KEY", \
"LABEL", "LAST", "LEADING", "LEFT", "LENGTH", "LESS", "LIMIT", \
"LIMITS", "LINAGE-COUNTER", "LINAGE", "LINE-COUNTER", "LINES", \
"LINE", "LINKAGE", "LOCK", "LOW-VALUES", "LOW-VALUE", \
"MEMORY", "MERGE", "MESSAGE", "MODE", "MODULES", "MOVE", "MULTIPLE", \
"MULTIPLY", \
"NATIVE", "NEGATIVE", "NEXT", "NOT", "NO", "NUMBER", "NUMERIC-EDITED", \
"NUMERIC", \
"OBJECT-COMPUTER", "OCCURS", "OFF", "OF", "OMITTED", "ON", "OPEN", \
"OPTIONAL", "ORDER", "ORGANIZATION", "OR", "OTHER", "OUTPUT", \
"OVERFLOW", \
"PACKED-DECIMAL", "PADDING", "PAGE-COUNTER", "PAGE", "PERFORM", \
"PF", "PH", "PICTURE", "PIC", "PLUS", "POINTER", "POSITION", \
"POSITIVE", "PRINTING", "PROCEDURES", "PROCEDURE", "PROCEED", \
"PROGRAM-ID", "PROGRAM", "PURGE", \
"QUEUE", "QUOTES", "QUOTE", \
"RANDOM", "RD", "READ", "RECEIVE", "RECORDS", "RECORD", "REDEFINES", \
"REEL", "REFERENCES", "REFERENCE", "RELATIVE", "RELEASE", \
"REMAINDER", "REMOVAL", "RENAMES", "REPLACE", "REPLACING", "REPORTING", \
"REPORTS", "REPORT", "RERUN", "RESERVE", "RESET", "RETURN", "REVERSED", \
"REWIND", "REWRITE", "RF", "RH", "RIGHT", "ROUNDED", "RUN", \
"SAME", "SD", "SEARCH", "SECTION", "SECURITY", "SEGMENT-LIMIT", \
"SEGMENT", "SELECT", "SEND", "SENTENCE", "SEPARATE", "SEQUENCE", \
"SEQUENTIAL", "SET", "SIGN", "SIZE", "SORT-MERGE", "SORT", \
"SOURCE-COMPUTER", "SOURCE", "SPACES", "SPACE", "SPECIAL-NAMES", \
"STANDARD-1", "STANDARD-2", "STANDARD", "START", "STATUS", "STOP", \
"STRING", "SUB-QUEUE-1", "SUB-QUEUE-2", "SUB-QUEUE-3", "SUBTRACT", \
"SUM", "SUPPRESS", "SYMBOLIC", "SYNCHRONIZED", "SYNC", \
"TABLE", "TALLYING", "TAPE", "TERMINAL", "TERMINATE", "TEST", \
"TEXT", "THAN", "THEN", "THROUGH", "THRU", "TIMES", "TIME", "TOP", "TO", \
"TRAILING", "TRUE", "TYPE", \
"UNIT", "UNSTRING", "UNTIL", "UPON", "UP", "USAGE", "USE", "USING", \
"VALUES", "VALUE", "VARYING", \
"WHEN", "WITH", "WORDS", "WORKING-STORAGE", "WRITE", \
"ZEROES", "ZEROS", "ZERO" };

/*
 * First, init all the HashTable entries to "".
 * Then, add all the reserved words to the table.
 */
int HashTable_init() {
	int i;

	for ( i=0; i < HASH_TABLE_SIZE; i++ ) {
		strncpy( HashTable[i], "", 1);
	}
	for ( i=0; i < N_RES_WORDS; i++ ) {
		HashTable_add( ResWords[i] );
	}

	return 0;
}

/*
 * Lookup the location where the word should be inserted.
 * If that spot is empty, add the word to the table.
 * Finding an empty spot is the responsibility of the "lookup" function.
 */
int HashTable_add(char *s) {
	int h;

	if ( s == NULL ) die("HashTable_add", "NULL string as argument");
	h = HashTable_lookup( s );
	if ( strcasecmp( HashTable[h], "" ) == 0 ) {
		strcpy( HashTable[h], s );
	}
	return 0;
}

/* 
 *  NOTE: HashTable must be less that half full to guarantee
 * 	that the string can be inserted in the table. (Weiss).
 */
int HashTable_lookup(char *s) {
	int currPos, collisionNum;

	collisionNum = 0;
	if ( s == NULL ) die("HashTable_lookup", "NULL string as argument");
	currPos = HashFn( s );

	while ( strcasecmp( HashTable[currPos], "" ) != 0 ) {

		if ( strcasecmp( HashTable[currPos], s ) == 0 ) {
			break;
		}
		else {
			collisionNum++;
				/* collision resolution */
			currPos = currPos + 2 * collisionNum - 1;
			if ( currPos >= HASH_TABLE_SIZE )
				currPos = currPos % HASH_TABLE_SIZE;

		}
	} /* end while */

	return currPos;
}

/*
 * Hash function: String to int.
 */
int  HashFn(char *s) {

	int hval, j;

	hval = toupper(*s); /* first char */
	for ( j=1; j< strlen(s); j++) {
		hval = ( hval * 32 + toupper(*(s+j)) ) % HASH_TABLE_SIZE;
	}

	return hval;
}

/*
 * Look at identifiers as recognized by the lexer and decide if they're
 * reserved words or not.
 */
int CheckIdent(char *s, char *p) {
	int i;

	if ( s == NULL || p == NULL ) 
		die("CheckIdent", "NULL string as argument");
	i = HashTable_lookup( s );

	if ( strcasecmp( HashTable[i], s ) == 0 )
		PrintToken("Reserved Word", s); 
	else
		PrintToken("Identifier", s);
	return 0;
}
int cr(char *s, char *p) {
	int i;

	if ( s == NULL || p == NULL )
		die("cr", "NULL string as argument");
	if ( strcmp( s, "" ) != 0 ) {

	i = HashTable_lookup( s );

	if ( strcasecmp( HashTable[i], s ) == 0 )
		printf("Res Word: %s\n", s);
	else
		printf("Expected Reserved Word: %s and found %s instead.\n",\
			s, p);
	}
	return 0;
}

/*
 * Generic printing, Token name then token text
 */
int PrintToken(char *n, char *t) {

	printf("%s\t%s\n", n, t);
	return 0;

}

/*
 * Bleat and die.
 */
void die(char *fn, char *err) {
	fprintf(stderr, "Internal Error:\n%s: %s\n", fn, err);
	exit(0);
}

