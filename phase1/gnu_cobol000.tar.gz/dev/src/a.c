
#include <stdio.h>

typedef struct {
	int a;
	union {
	int i;
	float j;
	} u;
} entry;

int main() {
	entry bob;

	bob.a = 0;

	if (bob.a == 0) {
		bob.u.i=5;
	}
	if (bob.a == 1) {
		bob.u.j=1.3;
	}

	if (bob.a == 0) {
		printf("%d\n", bob.u.i);
	}
	else { printf("%f\n", bob.u.j); }

	return 0;
}
