/* this file is for variable checking and interaction */
/* they will probably all return void b/c actions in the parser
   call these fns and all actions take place here */

#include <stdio.h>
static int id_div_flags;

/* check for variable name in symbol table */
/*
void VarVerifyIdent( char *name ) {
	int rv;
	rv = SymTabLookup( name );
	if ( rv == ERROR ) { 
		ErrUndefVar( name );
	}
}
*/

/* check clause flag.  If set, send an error, else, set it
   takes flag variable, flag value, and string to pass to error, if necc
*/
void CheckFlag( int flag_var, int flag_value, char *s ) {
	if ( flag_var & flag_value )
		ErrAlreadyDefined(s);
	else
		flag_var += flag_value;
printf("setting flag for %s \n");
}

/* check for variable name in symbol table and for file name on disk */
/*
void VarVerifyFile( char *name, char *fileName ) {
}
*/

/* for turning id-div stmts into comments */
void VarMakeComment( char *s ) {
	fprintf(stdout, "/* %s */\n", s);
}

void VarSetCurrency( char *currency ) {
	fprintf(stdout, "#define CURRENCY_SIGN '%c'\n", currency[0]);
}

void VarSetDecimal( ) {
	fprintf(stdout, "#define DECIMAL ','\n");
}

