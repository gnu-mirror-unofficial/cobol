/* Error handling routines for cobol */

#include <stdio.h>
extern int zzline;

void die() {
	fprintf(stderr, ">>ABEND<<\n");
	exit(0);
}

void ErrUndefVar( char *name ) {
	fprintf(stderr, "Error: Undefined Variable '%s' at line %d\n", name, zzline);
	die();
}

void ErrAlreadyDefined( char *name ) {
	fprintf(stderr, "Error: Clause beginning '%s' already defined\n", name);
	die();
}

