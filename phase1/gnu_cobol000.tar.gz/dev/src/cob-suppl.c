int id_div_flags = 0;
int env_div_flags = 0;
int io_ctl_flags = 0;
int file_control_flags = 0;
int file_descr_flags = 0;
int data_descr_flags = 0; 
