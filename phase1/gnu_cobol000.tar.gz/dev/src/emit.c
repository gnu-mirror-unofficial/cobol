void emit_fscanf( char* string );
void emit_assign_dow( char* string );

void emit_assign_time( char* string );
void emit_assign_date( char* string );
void emit_assign_day( char* string );


void emit_fscanf( char* string ){ ;}
void emit_assign_dow( char* string ){;}

void emit_assign_time( char* string ){;}
void emit_assign_date( char* string ){;}
void emit_assign_day( char* string ){;}
