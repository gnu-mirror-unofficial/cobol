void setNLA (int token) { NLA=token; return; }
